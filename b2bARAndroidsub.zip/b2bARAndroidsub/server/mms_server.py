"""
Meta MMS + NLLB serveris — pakalpo 1100+ valodu runas atpazīšanu (MMS) UN
200 valodu tulkošanu (NLLB) tīklā, lai b2bARAndroidsub Android lietotne
varētu tos izmantot valodām, kurām NAV lokāla Vosk modeļa / ML Kit atbalsta.

Šie ir TIEŠI tie paši modeļi un mehānismi, ko izmanto ARB2Btext desktop
versija (subtitres.py -> atpazit_meta_mms() un tulkot_meta_nllb()), tikai
iesaiņoti kā tīkla pakalpojums, ko var izsaukt no telefona.

═══════════════════════════════════════════════════════════════════════
SVARĪGI PIRMS PALAIŠANAS — LASI ŠO:
═══════════════════════════════════════════════════════════════════════

1. PRASĪBAS SERVERIM:
   - Python 3.9+
   - Vēlams: dators/VPS ar GPU (NVIDIA, ar CUDA) — uz CPU strādās, bet
     LĒNI (vairākas sekundes uz katru frāzi, ne reāllaikā)
   - Modelis "facebook/mms-1b-all" ir ~4-5 GB — pirmajā palaišanā
     lejupielādēsies automātiski (nepieciešams internets)
   - RAM: vismaz 8GB (CPU režīmā), GPU: vismaz 6GB VRAM (GPU režīmā)

2. INSTALĒŠANA:
   pip install fastapi uvicorn python-multipart torch transformers sentencepiece numpy soundfile

   (sentencepiece nepieciešams NLLB tokenizatoram)

3. PALAIŠANA:
   python mms_server.py
   (pēc noklusējuma klausās uz http://0.0.0.0:8765)

4. PIEEJAMĪBA NO TELEFONA:
   Telefonam jāspēj sasniegt šo serveri tīklā. Iespējas:
   - Vietējais tīkls (WiFi): telefons un serveris vienā WiFi — izmanto
     servera vietējo IP (piem. http://192.168.1.50:8765)
   - VPS/mākoņa serveris ar publisku IP + HTTPS (ieteicams produkcijai,
     piem. caur reverse proxy ar nginx + Let's Encrypt sertifikātu)
   - Tavs esošais Kurmenes servera/hostinga risinājums, ja tāds ir pieejams

5. DROŠĪBA (svarīgi, ja izvieto internetā, ne tikai vietējā tīklā):
   Šis vienkāršais servera piemērs NAV autentificēts — jebkurš, kas zina
   URL, var to izsaukt. Ja izvieto publiski pieejamā serverī, PIEVIENO
   API atslēgas pārbaudi (skat. komentāru zemāk pie check_api_key()) un
   HTTPS (nesūti audio nešifrētā veidā internetā).
═══════════════════════════════════════════════════════════════════════
"""

import io
import logging

import numpy as np
import torch
from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from transformers import AutoModelForSeq2SeqLM, AutoProcessor, AutoTokenizer, Wav2Vec2ForCTC

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("mms_server")

app = FastAPI(title="b2bARAndroidsub Meta MMS ASR serveris")

# ─────────────────────────────────────────────────────────────
# Konfigurācija — nomaini pēc vajadzības
# ─────────────────────────────────────────────────────────────

# Ja gribi vienkāršu API atslēgas aizsardzību (ieteicams, ja serveris
# pieejams internetā, ne tikai vietējā tīklā), iestati šeit nepustu vērtību
# un pievieno to pašu atslēgu Android lietotnes iestatījumos.
API_KEY = ""  # piem. "mans-noslepums-2026" — tukšs = bez aizsardzības

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MODEL_ID = "facebook/mms-1b-all"

# ISO-639-3 valodu kodi — tie paši, ko izmanto desktop ARB2Btext.
# Papildini pēc vajadzības (Meta MMS atbalsta 1100+ kodu sarakstu,
# pilns saraksts: https://dl.fbaipublicfiles.com/mms/misc/language_coverage_mms.html)
LANG_ISO_MAP = {
    "lv": "lav", "ru": "rus", "en": "eng", "lt": "lit", "et": "est",
    "de": "deu", "fi": "fin", "sv": "swe", "no": "nor", "fr": "fra",
    "es": "spa", "it": "ita", "pl": "pol",
    # ... pievieno papildu kodus šeit pēc vajadzības, piem.:
    # "uk": "ukr", "ar": "ara", "zh": "cmn", "ja": "jpn", "ko": "kor",
}

_model: Wav2Vec2ForCTC | None = None
_processors: dict[str, AutoProcessor] = {}

# ─────────────────────────────────────────────────────────────
# Meta NLLB-200 — tulkošana, 200 valodas, tā pati loģika, kas
# desktop ARB2Btext (subtitres.py -> tulkot_meta_nllb())
# ─────────────────────────────────────────────────────────────
_nllb_model: AutoModelForSeq2SeqLM | None = None
_nllb_tokenizer: AutoTokenizer | None = None
NLLB_MODEL_ID = "facebook/nllb-200-distilled-600M"

# NLLB izmanto savu valodu kodu formātu (piem. "lvs_Latn"). PILNS FLORES-200
# saraksts (visas ~204 valodas/skripta varianti, ko atbalsta NLLB-200
# modelis) — ģenerēts no https://github.com/facebookresearch/flores/blob/main/flores200/README.md
#
# Atslēgas: 13 standarta valodām saglabāti ērtie 2-burtu kodi (lv, ru, en...),
# pārējām izmantots FLORES-200 koda prefikss (3 burti, ISO 639-3), un, ja
# tai pašai valodai ir vairāki rakstības varianti, pievienots skripta
# sufikss (piem. "zho" = vienkāršotā ķīniešu, "zho_hant" = tradicionālā).
NLLB_LANG_CODES = {
    "ace": "ace_Arab",
    "ace_latn": "ace_Latn",
    "acm": "acm_Arab",
    "acq": "acq_Arab",
    "aeb": "aeb_Arab",
    "afr": "afr_Latn",
    "ajp": "ajp_Arab",
    "aka": "aka_Latn",
    "als": "als_Latn",
    "amh": "amh_Ethi",
    "apc": "apc_Arab",
    "arb": "arb_Arab",
    "arb_latn": "arb_Latn",
    "ars": "ars_Arab",
    "ary": "ary_Arab",
    "arz": "arz_Arab",
    "asm": "asm_Beng",
    "ast": "ast_Latn",
    "awa": "awa_Deva",
    "ayr": "ayr_Latn",
    "azb": "azb_Arab",
    "azj": "azj_Latn",
    "bak": "bak_Cyrl",
    "bam": "bam_Latn",
    "ban": "ban_Latn",
    "bel": "bel_Cyrl",
    "bem": "bem_Latn",
    "ben": "ben_Beng",
    "bho": "bho_Deva",
    "bjn": "bjn_Arab",
    "bjn_latn": "bjn_Latn",
    "bod": "bod_Tibt",
    "bos": "bos_Latn",
    "bug": "bug_Latn",
    "bul": "bul_Cyrl",
    "cat": "cat_Latn",
    "ceb": "ceb_Latn",
    "ces": "ces_Latn",
    "cjk": "cjk_Latn",
    "ckb": "ckb_Arab",
    "crh": "crh_Latn",
    "cym": "cym_Latn",
    "dan": "dan_Latn",
    "de": "deu_Latn",
    "dik": "dik_Latn",
    "dyu": "dyu_Latn",
    "dzo": "dzo_Tibt",
    "ell": "ell_Grek",
    "en": "eng_Latn",
    "epo": "epo_Latn",
    "et": "est_Latn",
    "eus": "eus_Latn",
    "ewe": "ewe_Latn",
    "fao": "fao_Latn",
    "fij": "fij_Latn",
    "fi": "fin_Latn",
    "fon": "fon_Latn",
    "fr": "fra_Latn",
    "fur": "fur_Latn",
    "fuv": "fuv_Latn",
    "gla": "gla_Latn",
    "gle": "gle_Latn",
    "glg": "glg_Latn",
    "grn": "grn_Latn",
    "guj": "guj_Gujr",
    "hat": "hat_Latn",
    "hau": "hau_Latn",
    "heb": "heb_Hebr",
    "hin": "hin_Deva",
    "hne": "hne_Deva",
    "hrv": "hrv_Latn",
    "hun": "hun_Latn",
    "hye": "hye_Armn",
    "ibo": "ibo_Latn",
    "ilo": "ilo_Latn",
    "ind": "ind_Latn",
    "isl": "isl_Latn",
    "it": "ita_Latn",
    "jav": "jav_Latn",
    "ja": "jpn_Jpan",
    "kab": "kab_Latn",
    "kac": "kac_Latn",
    "kam": "kam_Latn",
    "kan": "kan_Knda",
    "kas": "kas_Arab",
    "kas_deva": "kas_Deva",
    "kat": "kat_Geor",
    "knc": "knc_Arab",
    "knc_latn": "knc_Latn",
    "kaz": "kaz_Cyrl",
    "kbp": "kbp_Latn",
    "kea": "kea_Latn",
    "khm": "khm_Khmr",
    "kik": "kik_Latn",
    "kin": "kin_Latn",
    "kir": "kir_Cyrl",
    "kmb": "kmb_Latn",
    "kmr": "kmr_Latn",
    "kon": "kon_Latn",
    "ko": "kor_Hang",
    "lao": "lao_Laoo",
    "lij": "lij_Latn",
    "lim": "lim_Latn",
    "lin": "lin_Latn",
    "lt": "lit_Latn",
    "lmo": "lmo_Latn",
    "ltg": "ltg_Latn",
    "ltz": "ltz_Latn",
    "lua": "lua_Latn",
    "lug": "lug_Latn",
    "luo": "luo_Latn",
    "lus": "lus_Latn",
    "lv": "lvs_Latn",
    "mag": "mag_Deva",
    "mai": "mai_Deva",
    "mal": "mal_Mlym",
    "mar": "mar_Deva",
    "min": "min_Arab",
    "min_latn": "min_Latn",
    "mkd": "mkd_Cyrl",
    "plt": "plt_Latn",
    "mlt": "mlt_Latn",
    "mni": "mni_Beng",
    "khk": "khk_Cyrl",
    "mos": "mos_Latn",
    "mri": "mri_Latn",
    "mya": "mya_Mymr",
    "nld": "nld_Latn",
    "nno": "nno_Latn",
    "no": "nob_Latn",
    "npi": "npi_Deva",
    "nso": "nso_Latn",
    "nus": "nus_Latn",
    "nya": "nya_Latn",
    "oci": "oci_Latn",
    "gaz": "gaz_Latn",
    "ory": "ory_Orya",
    "pag": "pag_Latn",
    "pan": "pan_Guru",
    "pap": "pap_Latn",
    "pes": "pes_Arab",
    "pl": "pol_Latn",
    "por": "por_Latn",
    "prs": "prs_Arab",
    "pbt": "pbt_Arab",
    "quy": "quy_Latn",
    "ron": "ron_Latn",
    "run": "run_Latn",
    "ru": "rus_Cyrl",
    "sag": "sag_Latn",
    "san": "san_Deva",
    "sat": "sat_Olck",
    "scn": "scn_Latn",
    "shn": "shn_Mymr",
    "sin": "sin_Sinh",
    "slk": "slk_Latn",
    "slv": "slv_Latn",
    "smo": "smo_Latn",
    "sna": "sna_Latn",
    "snd": "snd_Arab",
    "som": "som_Latn",
    "sot": "sot_Latn",
    "es": "spa_Latn",
    "srd": "srd_Latn",
    "srp": "srp_Cyrl",
    "ssw": "ssw_Latn",
    "sun": "sun_Latn",
    "sv": "swe_Latn",
    "swh": "swh_Latn",
    "szl": "szl_Latn",
    "tam": "tam_Taml",
    "tat": "tat_Cyrl",
    "tel": "tel_Telu",
    "tgk": "tgk_Cyrl",
    "tgl": "tgl_Latn",
    "tha": "tha_Thai",
    "tir": "tir_Ethi",
    "taq": "taq_Latn",
    "taq_tfng": "taq_Tfng",
    "tpi": "tpi_Latn",
    "tsn": "tsn_Latn",
    "tso": "tso_Latn",
    "tuk": "tuk_Latn",
    "tum": "tum_Latn",
    "tur": "tur_Latn",
    "twi": "twi_Latn",
    "tzm": "tzm_Tfng",
    "uig": "uig_Arab",
    "uk": "ukr_Cyrl",
    "umb": "umb_Latn",
    "urd": "urd_Arab",
    "uzn": "uzn_Latn",
    "vec": "vec_Latn",
    "vie": "vie_Latn",
    "war": "war_Latn",
    "wol": "wol_Latn",
    "xho": "xho_Latn",
    "ydd": "ydd_Hebr",
    "yor": "yor_Latn",
    "yue": "yue_Hant",
    "zh": "zho_Hans",
    "zho_hant": "zho_Hant",
    "zsm": "zsm_Latn",
    "zul": "zul_Latn",
    # Papildu ērts alias Modern Standard Arabic
    "ar": "arb_Arab",
}


def get_nllb_model():
    global _nllb_model, _nllb_tokenizer
    if _nllb_model is None:
        log.info("Ielādē Meta NLLB modeli (%s)...", NLLB_MODEL_ID)
        _nllb_tokenizer = AutoTokenizer.from_pretrained(NLLB_MODEL_ID)
        _nllb_model = AutoModelForSeq2SeqLM.from_pretrained(NLLB_MODEL_ID).to(DEVICE)
        log.info("NLLB modelis gatavs uz ierīces: %s", DEVICE)
    return _nllb_model, _nllb_tokenizer


def check_api_key(x_api_key: str | None):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Nederīga API atslēga")


def get_model() -> Wav2Vec2ForCTC:
    global _model
    if _model is None:
        log.info("Ielādē Meta MMS modeli (%s)... tas var aizņemt vairākas minūtes pirmoreiz.", MODEL_ID)
        _model = Wav2Vec2ForCTC.from_pretrained(MODEL_ID).to(DEVICE)
        log.info("Modelis gatavs uz ierīces: %s", DEVICE)
    return _model


def get_processor(iso_code: str) -> AutoProcessor:
    if iso_code not in _processors:
        _processors[iso_code] = AutoProcessor.from_pretrained(MODEL_ID, target_lang=iso_code)
    return _processors[iso_code]


@app.get("/health")
def health():
    return {
        "status": "ok",
        "device": DEVICE,
        "mms_model_loaded": _model is not None,
        "nllb_model_loaded": _nllb_model is not None,
    }


@app.post("/recognize")
async def recognize(
    audio: UploadFile = File(..., description="PCM16 16kHz mono WAV fails"),
    lang: str = Form(..., description="Valodas kods (piem. 'lv', 'de', vai jebkurš atbalstītais)"),
    x_api_key: str | None = Header(default=None),
):
    """
    Pieņem WAV audio failu (16kHz, mono, 16-bit PCM) un valodas kodu,
    atgriež atpazīto tekstu. Izmanto to pašu adapteru mehānismu, ko
    ARB2Btext desktop versija.
    """
    check_api_key(x_api_key)

    iso_code = LANG_ISO_MAP.get(lang.lower(), lang.lower())

    try:
        import soundfile as sf

        raw = await audio.read()
        audio_f32, sample_rate = sf.read(io.BytesIO(raw), dtype="float32")

        if sample_rate != 16000:
            raise HTTPException(status_code=400, detail=f"Sagaidīts 16000 Hz, saņemts {sample_rate} Hz")

        model = get_model()
        processor = get_processor(iso_code)
        model.load_adapter(iso_code)

        inputs = processor(audio_f32, sampling_rate=16000, return_tensors="pt").to(DEVICE)
        with torch.no_grad():
            logits = model(**inputs).logits
        ids = torch.argmax(logits, dim=-1)[0]
        text = processor.decode(ids).strip()

        log.info("[%s] Atpazīts: %s", iso_code, text[:80])
        return {"text": text, "lang": lang, "iso_code": iso_code}

    except HTTPException:
        raise
    except Exception as e:
        log.exception("Atpazīšanas kļūda")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/translate")
async def translate(
    text: str = Form(..., description="Tulkojamais teksts"),
    src_lang: str = Form(..., description="Avota valodas kods (piem. 'de')"),
    tgt_lang: str = Form(..., description="Mērķa valodas kods (piem. 'lv')"),
    x_api_key: str | None = Header(default=None),
):
    """
    Tulko tekstu ar Meta NLLB-200 (200 valodas). Izmanto TIKAI valodām,
    kurām ML Kit Translation (telefonā) neder — parasti retākām valodām.
    """
    check_api_key(x_api_key)

    if not text.strip() or src_lang == tgt_lang:
        return {"translation": text}

    src_code = NLLB_LANG_CODES.get(src_lang.lower())
    tgt_code = NLLB_LANG_CODES.get(tgt_lang.lower())
    if not src_code or not tgt_code:
        raise HTTPException(
            status_code=400,
            detail=f"Nezināms valodas kods NLLB kartē: '{src_lang}' vai '{tgt_lang}'. "
                   f"Pievieno to NLLB_LANG_CODES sarakstā mms_server.py failā.",
        )

    try:
        model, tokenizer = get_nllb_model()
        tokenizer.src_lang = src_code
        inputs = tokenizer(text, return_tensors="pt", padding=True).to(DEVICE)
        forced_bos_id = tokenizer.lang_code_to_id[tgt_code]
        output = model.generate(**inputs, forced_bos_token_id=forced_bos_id, max_length=256)
        result = tokenizer.batch_decode(output, skip_special_tokens=True)[0]

        log.info("[NLLB %s->%s] %s -> %s", src_lang, tgt_lang, text[:40], result[:40])
        return {"translation": result}

    except HTTPException:
        raise
    except Exception as e:
        log.exception("Tulkošanas kļūda")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8765)
