# b2bARAndroidsub

Android versija tavam ARB2Btext tulkošanas risinājumam — reāllaika balss tulkošana
tieši uz Nokia (HMD Skyline) telefona, ar izvadi caur ASHA/Bluetooth dzirdes aparātiem.

## Kā tas strādā

**Ieslēgšana/izslēgšana ar balsi:**
Papildus manuālai "Sākt klausīties" pogai, vari ieslēgt lietotnē **"Ieslēgt
balss komandas"** — tad neliels, vienmēr aktīvs klausītājs (`HotwordListenerService`)
gaida frāzes **"translator on"** un **"translator off"**. Pasakot "translator on",
galvenais tulkošanas serviss palaižas automātiski, bez telefona pieskaršanās.
Pasakot "translator off", tas apstājas. Šis klausītājs pats turpina darboties
nepārtraukti (ir ļoti viegls — izmanto tikai nelielu angļu Vosk modeli), lai
vienmēr būtu gatavs nākamajai komandai.

**Automātiska avota valodas noteikšana:**
Kad sākas klausīšanās avota pusē (LISTENING_SOURCE), lietotne vispirms
ievāc īsu (~1.8 sek.) audio paraugu un palaiž to caur VISIEM lejupielādētajiem
Vosk valodu modeļiem paralēli (skat. `LanguageDetector.kt`), izvēloties to,
kurš dod visaugstāko atpazīšanas pārliecību. Tikai pēc tam sākas reālā
klausīšanās un tulkošana ar atrasto valodu. Tas notiek katru reizi, kad
sistēma atgriežas avota klausīšanās stāvoklī (arī pēc "punkts" cikla).

Ja gribi šo izslēgt un atgriezties pie manuālas valodas izvēles (ātrāk,
mazāk RAM), to var iestatīt `ConfigManager.autoDetectSourceLang = false`.

**Noklusējuma stāvoklis (LISTENING_SOURCE):**
Telefons klausās avota valodu (automātiski noteiktu, skat. augstāk), straumējoši
(pa frāzēm, kad dabiska pauze) tulko un runā mērķa valodā (noklusēti latviešu).

**Atslēgvārds "punkts":**
Kad tu pasaki "punkts", sistēma pilnībā apstājas klausīties avota valodu un
sāk klausīties tevi (noklusēti angļu valodā — pēc tavas prasības tā ir primārā).
Kad atkal pasaki "punkts", pēdējā teiktā daļa tiek iztulkota un pateikta
**vienmēr angliski**, un sistēma automātiski atgriežas avota valodas klausīšanā
(ar jaunu valodas detekcijas ciklu).

Tas ir vienkāršs 2-stāvokļu pārslēgs (state machine), nevis trīs stāvokļi —
tā ir uzticamāka un vieglāk paredzama lietošanā.

## Svarīgs tehnisks ierobežojums

Vosk (runas atpazīšana) katrai sesijai strādā ar VIENU ielādētu valodas
modeli — nav "automātiskas jebkuras valodas" noteikšanas reāllaikā. Tāpēc:
- Avota valoda (ko klausās pēc noklusējuma) ir iestatāma lietotnē — noklusēti `de`.
- Tavas atbildes klausīšanās valoda ir iestatāma — noklusēti `en` (kā tu lūdzi).

## Bezmaksas dzinēji (bez API atslēgām)

Šī versija vairs NEPRASA nekādas maksas API atslēgas:
- **Tulkošana**: Google ML Kit Translation — strādā tieši telefonā, bez maksas.
  Valodu pakas lejupielādējas automātiski PIRMAJĀ reizē (ieteicams caur WiFi,
  katra paka ir ~30-40 MB) un pēc tam strādā pilnīgi offline.
- **Runas atpazīšana**: Vosk — atvērtā koda, bez maksas, pilnībā offline.
  Modeļi JĀLEJUPIELĀDĒ MANUĀLI (skat. zemāk) — tie ir par lielu, lai tos
  iekļautu APK failā.

## Vosk modeļu uzstādīšana (VAJADZĪGS PIRMS PIRMĀS PALAIŠANAS)

Lietotne tagad atbalsta VISAS valodas, kas ir tavā desktop `ARB2Btext`
programmā: latviešu, krievu, angļu, lietuviešu, igauņu, vācu, somu, zviedru,
norvēģu, franču, spāņu, itāļu, poļu.

**Svarīgi**: Vosk modelis jālejupielādē TIKAI tām valodām, ko reāli izmantosi
(avota valoda + angļu valoda tavām atbildēm) — nevis visām 13 uzreiz. Ja
nomaini avota valodu iestatījumos, tad vienkārši lejupielādē arī tās valodas
modeli pēc tās pašas shēmas.

1. Atver **https://alphacephei.com/vosk/models** savā telefonā vai datorā
2. Lejupielādē mazo modeli (~50 MB, pietiekami precīzs mobilajai lietošanai)
   TAI valodai, ko klausīsies (piem. `vosk-model-small-de-0.15` vācu
   valodai), UN angļu modeli atbildēm (`vosk-model-small-en-us-0.15`):

   | Valoda | Vosk modeļa nosaukums (piemērs) |
   |---|---|
   | Vācu | `vosk-model-small-de-0.15` |
   | Angļu | `vosk-model-small-en-us-0.15` |
   | Krievu | `vosk-model-small-ru-0.22` |
   | Lietuviešu | `vosk-model-small-lt-0.22` (skat. lapā, ja mainījies) |
   | Igauņu | oficiāla maza modeļa var nebūt — pārbaudi lapā |
   | Somu | `vosk-model-small-fi-0.22` |
   | Zviedru | `vosk-model-small-sv-rhasspy-0.15` |
   | Norvēģu | `vosk-model-small-no-0.15` |
   | Franču | `vosk-model-small-fr-0.22` |
   | Spāņu | `vosk-model-small-es-0.42` |
   | Itāļu | `vosk-model-small-it-0.22` |
   | Poļu | `vosk-model-small-pl-0.22` |

   (Precīzi failu nosaukumi laiku pa laikam mainās — vienmēr pārbaudi
   aktuālo sarakstu tieši lapā, iepriekš minētie ir orientējoši.)

3. Izpako katru `.zip` failu — iekšā būs mape (piem. `vosk-model-small-de-0.15`)
4. Telefonā, caur failu pārvaldnieku, izveido (ja vēl nav) un ievieto modeļus šeit:
   ```
   Android/data/com.ardecoderar.b2bandroidsub/files/vosk_models/de/   <- valodas koda apakšmape
   Android/data/com.ardecoderar.b2bandroidsub/files/vosk_models/en/   <- angļu modeļa saturs
   ```
   Valodas kods apakšmapē atbilst tam pašam kodam, ko redzi lietotnes
   valodu izvēlnē (`de`, `lv`, `ru`, `lt`, `et`, `fi`, `sv`, `no`, `fr`, `es`, `it`, `pl`).
   (Precīzs ceļš: iekšējā krātuve → tā, kā to redz `getExternalFilesDir()` — lietotne
   pati parāda pilno ceļu ekrānā "Vosk modeļi" sadaļā, ar pogu "Pārbaudīt modeļus".)
5. **Svarīgi**: apakšmapes saturam jābūt TIEŠI izpakotā modeļa saturam
   (t.i., mapē uzreiz jāredz apakšmapes `am/`, `conf/`, `graph/` u.c. —
   NEVIS vēl vienu ietvertu `vosk-model-small-xx-0.15/` apakšmapi).
6. Atver lietotni → nospied **"Pārbaudīt modeļus"** → jāredz ✓ pie abām
   pašlaik izvēlētajām valodām.

## Meta MMS + NLLB — 1100+ valodu runas atpazīšana UN 200 valodu tulkošana (papildu, prasa serveri)

Papildus 13 iebūvētajām Vosk/ML Kit valodām, lietotne var izmantot **Meta
MMS** (runas atpazīšanai, ~1100 valodas) un **Meta NLLB-200** (tulkošanai,
200 valodas) — abi ir tie paši modeļi, kas jau ir tavā desktop `ARB2Btext`
(`facebook/mms-1b-all` un `facebook/nllb-200-distilled-600M`). **Šie
NESTRĀDĀ tieši telefonā** — abi modeļi kopā ir vairāki GB un prasa GPU
vai spēcīgu CPU, tāpēc tie jāpalaiž SERVERĪ, ko telefons sasniedz caur tīklu.

### 1. Palaid serveri (savā datorā, mājas serverī, vai VPS)

Projektā ir iekļauts `server/mms_server.py` — pilns, gatavs palaišanai
Python serveris ar DIVIEM endpointiem: `/recognize` (MMS runas atpazīšana)
un `/translate` (NLLB tulkošana).

```
pip install fastapi uvicorn python-multipart torch transformers sentencepiece numpy soundfile
python server/mms_server.py
```

Katrs modelis ielādējas TIKAI TAD, kad pirmo reizi tiek izmantots (ne
uzreiz palaižot serveri) — ja izmantosi tikai atpazīšanu, NLLB nemaz
neielādēsies, un otrādi. Pirmajā izmantošanas reizē attiecīgais modelis
automātiski lejupielādēsies (MMS ~4-5 GB, NLLB ~2.4 GB — vajag internetu).

**Ātrums**: ar GPU — gandrīz reāllaikā. Uz CPU — vairākas sekundes uz
katru pieprasījumu (lietojams, bet nav "uzreiz").

### 2. Savieno telefonu ar serveri

Lietotnē, sadaļā "Paplašinātais atbalsts":
- **MMS servera URL**: ja serveris tavā WiFi tīklā, izmanto tā vietējo IP
  (piem. `http://192.168.1.50:8765`); ja VPS ar publisku IP — izmanto to
  (šis pats URL kalpo gan atpazīšanai, gan tulkošanai)
- **API atslēga**: pēc izvēles (aizsardzībai, ja serveris pieejams internetā)
- **Pielāgots valodas kods**: ieraksti jebkuru valodu ĀRPUS standarta 13
  (piem. `uk` ukraiņu, `ar` arābu, `zh` ķīniešu) — kad šis lauks aizpildīts,
  lietotne automātiski izmanto MMS serveri atpazīšanai

**Tulkošana pati par sevi izšķiras automātiski**: ja avota VAI mērķa valoda
nav ML Kit standarta 13 sarakstā, lietotne pati pāriet uz NLLB serveri
tulkošanai — nekas papildu jākonfigurē, ja MMS servera URL jau ir iestatīts.

### Valodu kodu saraksts (JAU PILNS — 204 ieraksti)

`NLLB_LANG_CODES` vārdnīca `mms_server.py` failā tagad satur **visu FLORES-200
sarakstu** (204 ieraksti — dažām valodām ir vairāki rakstības varianti, piem.
ķīniešu vienkāršotā/tradicionālā, tāpēc skaits pārsniedz "200"). Standarta 13
valodām saglabāti ērtie 2-burtu kodi (`lv`, `de`, `en`...), pārējām izmantots
FLORES-200 koda prefikss (3 burti, piem. `yor` jorubu, `arb` standarta arābu,
`zho` ķīniešu vienkāršotā). Pilns kodu saraksts ar valodu nosaukumiem:
https://github.com/facebookresearch/flores/blob/main/flores200/README.md

Ja ievadi lietotnē "Pielāgots valodas kods" lauciņā jebkuru no šiem kodiem
(piem. `yor`, `hau`, `swh`, `tam`, `vie`, `tha` u.c.), tulkošana caur NLLB
serveri nostrādās uzreiz, bez papildu koda rakstīšanas.

## Prasības tavam telefonam

Tavs HMD Skyline (8 kodolu Cortex-A78+A55, 12GB RAM) ir vairāk nekā pietiekams
šim uzdevumam. Gan Vosk (mazie modeļi ~50MB), gan ML Kit tulkošana ir viegli
optimizēti mobilajām ierīcēm, tāpēc slodze uz CPU/RAM ir saprātīga.

## Uzstādīšana / APK iegūšana (BEZ Android Studio, caur GitHub)

Tev jau ir pieredze ar GitHub Pages, tāpēc šis ceļš būs pazīstams. Projektā ir
iekļauta GitHub Actions darbplūsma (`.github/workflows/build-apk.yml`), kas
GitHub serverī pati sabūvē instalējamu APK failu — tev nekas jālejupielādē
vai jāinstalē uz sava datora.

1. Izveido jaunu **privātu** GitHub repozitoriju (piem. `b2bARAndroidsub`).
2. Augšupielādē šīs mapes saturu tajā (var vilkt-un-mest caur GitHub web
   saskarni, vai `git push`, tāpat kā ar saviem citiem projektiem).
3. Atver repozitorija cilni **Actions** — būvēšana sāksies automātiski pēc
   augšupielādes (aizņem ~2-4 minūtes).
4. Kad zaļš ✓ — atver to darbplūsmas palaidumu, ritini uz leju līdz
   **Artifacts** sadaļai, lejupielādē `b2bARAndroidsub-debug-apk` (tas ir
   `.zip`, kurā iekšā ir `app-debug.apk`).
5. Pārsūti `app-debug.apk` uz telefonu (pa e-pastu sev, caur Google Drive,
   vai USB kabeli) un atver to failu pārvaldniekā, lai instalētu.
6. Telefons pirmoreiz prasīs atļauju **"Instalēt no nezināma avota"** —
   tas ir normāli pašbūvētam APK (tas nav no Google Play). Atļauj un
   instalē.

Šī ir **debug** versija (nav parakstīta ar publicēšanas atslēgu) — tas ir
pilnīgi pietiekami tavai personīgai lietošanai un testēšanai. Ja vēlāk gribi
to izplatīt citiem vai publicēt Google Play, vajadzēs papildu parakstīšanas
soli — pasaki, ja tas kļūst aktuāli.

### Alternatīva: Android Studio (ja tomēr vēlies lokāli)

1. Atver šo mapi ar **Android Studio** (Hedgehog vai jaunāku).
2. Ļauj Gradle sinhronizēties (lejupielādēs atkarības — nepieciešams internets).
3. Pievieno telefonu caur USB ar ieslēgtu USB atkļūdošanu (Developer Options ->
   USB debugging), vai uzbūvē APK: `Build -> Build Bundle(s) / APK(s) -> Build APK(s)`.
4. Uzinstalē uz telefona.

## Iestatīšana lietotnē

1. Atver lietotni → pārliecinies, ka Vosk modeļi ir uzstādīti (skat. augstāk) —
   nospied **"Pārbaudīt modeļus"**, jāredz ✓ pie abām valodām.
2. Pārbaudi/maini valodas (avota, mērķa, atbilžu izvades).
3. Nospied **"Sākt klausīties"** — piešķir mikrofona un paziņojumu atļaujas.
4. Serviss turpina darboties fonā (foreground service ar pastāvīgu paziņojumu),
   pat ja telefona ekrāns izslēgts vai lietotne minimizēta.
5. Pirmajā tulkošanas reizē ML Kit klusi lejupielādēs vajadzīgo valodu pāra
   modeli (ja vēl nav) — ieteicams pirmoreiz to darīt ar WiFi.

## Dzirdes aparātu savienošana un mikrofona ievade

**Apstiprināts tavam modelim (Phonak Naída Lumity L90-PR)**: tas atbalsta
handsfree zvanus caur klasisko Bluetooth (SCO/HFP) — TAS NOZĪMĒ, ka lietotne
var izmantot tā mikrofonu kā audio ievadi, nevis telefona mikrofonu. Kods to
jau atbalsta (`BluetoothAudioRouter.kt` → `startClassicScoAndWait()`).

**Savienošana:**
1. Telefonā: **Iestatījumi → Savienotās ierīces → Pievienot ierīci**, savieno
   Naída L90-PR parastā Bluetooth pārī savienošanas veidā.
2. Kad savienots un lietotne palaista, tā automātiski aktivizē SCO
   audio maršrutu (aizņem ~1-2 sekundes) — lietotnes statusa rindā redzēsi
   "Dzirdes aparāts (klasiskais Bluetooth handsfree)".
3. Ja SCO savienojums neizdodas (retos gadījumos, atkarībā no telefona
   ražotāja Bluetooth steka), lietotne automātiski turpina ar telefona
   mikrofonu — statusa rindā redzēsi "SCO savienojums neizdevās".

Kods atbalsta arī jaunāko LE Audio/HAP standartu (dažiem 2025-2026 gada
modeļiem, piem. Phonak Infinio) — tas notiek automātiski, ja ierīce to
paziņo, un neprasa SCO aktivizēšanu.

Ja tavi dzirdes aparāti NAV ASHA/Bluetooth LE Audio saderīgi (vecāki modeļi ar
tikai analogo/telecoil savienojumu), tad nepieciešams starpnieks (piem., MFi
straumētājs vai FM/telecoil raidītājs) — pasaki modeli, un pameklēšu, kas der.

## Publicēšana Play Store — TAGAD (izstrādes fāze, tikai tev)

**Ikona**: lietotnes ikona (dzirdes aparāts + skaņas viļņi + "ARsub") jau ir
ievietota visos vajadzīgajos izmēros (`app/src/main/res/mipmap-*/`) —
telefona palaidējā tā parādīsies automātiski. Play Store veikala lapai
(nevis pašai app) vajadzīgs ATSEVIŠĶS 512×512 PNG — tas ir sagatavots
`store_assets/play_store_icon_512.png`, augšupielādē to Play Console
sadaļā "Store settings" → "App icon".


Kamēr izstrādā, izmanto Play Console **"Internal testing"** joslu — tā:
- **Nekad nav publiska/aktīva** — neviens to neatrod meklējot Play Store
- Redzama TIKAI tiem e-pastiem, ko pats pievieno testeru sarakstam (t.i., tev)
- Atjauninājumi parādās uzreiz (bez Google pārskatīšanas kavēšanās, kas
  "Closed"/"Production" joslām var aizņemt stundas/dienas)

**Soļi:**
1. Tev jau ir Play Developer konts → [play.google.com/console](https://play.google.com/console)
2. **Create app** → aizpildi pamata info (var vēlāk mainīt)
3. **Testing → Internal testing → Create new release**
4. Augšupielādē `app-release.aab` (sk. "Parakstīšana" zemāk, kā to sabūvēt)
5. **Testers** cilnē pievieno TIKAI savu Google konta e-pastu
6. Play Console iedos tev opt-in saiti — atver to savā telefonā, apstiprini,
   un lietotne parādīsies tavā Play Store kā parasta instalējama app

Kad vēlāk būsi gatavs rādīt to klientiem, vienkārši pārvieto to pašu izlaidumu
uz **"Closed testing"** joslu un pievieno klientu e-pastus — kods nemainās,
mainās tikai tas, kam Play Console to rāda.

### Parakstīšana (nepieciešama jebkurai Play Store augšupielādei, arī Internal testing)

1. Vienreiz sagatavo atslēgu savā datorā:
   ```
   keytool -genkeypair -v -keystore release.jks -alias b2bARAndroidsub ^
     -keyalg RSA -keysize 2048 -validity 10000 -storetype JKS
   ```
   Saglabā `release.jks` un abas paroles droši — pazaudējot tās, nevarēsi
   vairs atjaunināt šo app zem tās pašas identitātes.

2. Repozitorijā: **Settings → Secrets and variables → Actions**, pievieno
   4 Secrets: `KEYSTORE_BASE64` (palaid `base64 -i release.jks` un ielīmē),
   `KEYSTORE_PASSWORD`, `KEY_ALIAS` (`b2bARAndroidsub`), `KEY_PASSWORD`.
   Un 1 Variable: `ENABLE_RELEASE_BUILD` = `true`.

3. Nākamā GitHub Actions būvēšana automātiski izveidos parakstītu
   `app-release.aab` — lejupielādē to no Artifacts un augšupielādē
   Play Console Internal testing izlaidumā (solis 4 augstāk).

## Kur atrodas kods

- `TranslationService.kt` — galvenā loģika: klausīšanās cikls, "punkts"
  atslēgvārda noteikšana, stāvokļu pārslēgšana, tulkošana, TTS.
- `VoskAsrClient.kt` — bezmaksas offline runas atpazīšana (Vosk).
- `MLKitTranslator.kt` — bezmaksas offline tulkošana (Google ML Kit).
- `AudioCapture.kt` — zemā līmeņa mikrofona/Bluetooth audio ieraksts.
- `BluetoothAudioRouter.kt` — dzirdes aparāta mikrofona maršrutēšana (LE Audio un klasiskais SCO).
- `ConfigManager.kt` — iestatījumu glabāšana un Vosk modeļu ceļu pārvaldība.
- `MainActivity.kt` — lietotnes UI, atļauju pieprasīšana, servisa vadība.

## Nākamie soļi / iespējamie uzlabojumi

- Fusion/Guardian daudz-dzinēju balsošana (kā desktop versijā) — pievienot
  Deepgram/AssemblyAI kā rezerves ASR, ja Android atpazīšana kļūdās trokšņainā
  vidē (piem., pasākumā ar fona troksni).
- Pielāgojams klusuma taimauts (pašlaik 900ms/600ms) atkarībā no situācijas.
- Vēsture/log ekrānā (redzēt pēdējās 10 frāzes un tulkojumus).
- Fiziska poga (piem., austiņu poga) kā alternatīva "punkts" balss komandai,
  ja trokšņainā vidē atslēgvārdu grūti atpazīt droši.
