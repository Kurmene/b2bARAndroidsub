pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Vosk (bezmaksas offline runas atpazīšana) tiek publicēts caur JitPack
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "b2bARAndroidsub"
include(":app")
