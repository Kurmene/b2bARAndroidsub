import java.io.FileInputStream
import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ardecoderar.b2bandroidsub"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ardecoderar.b2bandroidsub"
        // HMD Skyline (Nokia) ar Cortex-A78+A55 astoņkodolu čipu atbalsta Android 13/14 —
        // minSdk 26 nodrošina plašu saderību, targetSdk 34 izmanto jaunāko API.
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Parakstīšanas konfigurācija Play Store izlaidumam. Atslēgas dati NEKAD
    // netiek rakstīti tieši šajā failā (kas nonāk Git/GitHub) — tie nāk vai
    // nu no lokāla "keystore.properties" faila (tavā datorā, git-ignorēts),
    // vai no GitHub Secrets (CI būvēšanai). Skat. README "Publicēšana Play Store".
    val keystorePropsFile = rootProject.file("keystore.properties")
    val keystoreProps = Properties()
    if (keystorePropsFile.exists()) {
        keystoreProps.load(FileInputStream(keystorePropsFile))
    }

    fun cfg(key: String, envName: String): String =
        keystoreProps.getProperty(key) ?: System.getenv(envName) ?: ""

    signingConfigs {
        create("release") {
            val storeFilePath = cfg("storeFile", "KEYSTORE_PATH")
            if (storeFilePath.isNotBlank()) {
                storeFile = file(storeFilePath)
                storePassword = cfg("storePassword", "KEYSTORE_PASSWORD")
                keyAlias = cfg("keyAlias", "KEY_ALIAS")
                keyPassword = cfg("keyPassword", "KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (keystorePropsFile.exists() || System.getenv("KEYSTORE_PATH") != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Bezmaksas tulkošana tieši telefonā (bez API atslēgas, bez maksas, bez interneta pēc
    // pirmās valodas pakas lejupielādes) — aizstāj Tilde MT API.
    implementation("com.google.mlkit:translate:17.0.3")

    // Bezmaksas runas atpazīšana tieši telefonā (bez API atslēgas, bez maksas, pilnībā
    // offline pēc modeļa lejupielādes) — aizstāj Deepgram.
    implementation("com.alphacephei:vosk-android:0.3.70")
    implementation("net.java.dev.jna:jna:5.14.0@aar")
}
