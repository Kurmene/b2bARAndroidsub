package com.ardecoderar.b2bandroidsub

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

/**
 * Klients Meta MMS ASR serverim (skat. server/mms_server.py) — izmanto
 * TIKAI tām valodām, kurām NAV lokāla Vosk modeļa. Vajag internetu un
 * paša uzstādītu serveri (skat. README "Meta MMS 1100+ valodu atbalsts").
 *
 * Atšķirībā no VoskAsrClient (kas straumē un strādā offline), šis klients
 * strādā ar PILNIEM audio fragmentiem (WAV) un prasa tīkla savienojumu —
 * tāpēc tas ir "lēnāks" (gaida servera atbildi), bet atbalsta jebkuru no
 * Meta MMS 1100+ valodām, ne tikai tās, kam ir lejupielādēts Vosk modelis.
 */
class MetaMmsAsrClient(
    private val serverUrl: String,
    private val apiKey: String
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS) // CPU serverim atpazīšana var aizņemt vairākas sekundes
        .build()

    /**
     * Nosūta PCM16 16kHz mono audio uz serveri, saņem atpazīto tekstu.
     * Ja serveris nav sasniedzams vai kļūdojas, atgriež tukšu virkni
     * (fail-soft — audio vienkārši netiek atpazīts, sistēma turpina).
     */
    fun recognize(pcmAudio: ByteArray, langCode: String): String {
        if (serverUrl.isBlank() || pcmAudio.isEmpty()) return ""

        return try {
            val wavBytes = pcmToWav(pcmAudio, sampleRate = AudioCapture.SAMPLE_RATE)
            val wavBody = wavBytes.toRequestBody("audio/wav".toMediaType())

            val multipart = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("audio", "sample.wav", wavBody)
                .addFormDataPart("lang", langCode)
                .build()

            val requestBuilder = Request.Builder()
                .url("${serverUrl.trimEnd('/')}/recognize")
                .post(multipart)

            if (apiKey.isNotBlank()) {
                requestBuilder.addHeader("x-api-key", apiKey)
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                if (!response.isSuccessful) return ""
                val json = JSONObject(response.body?.string() ?: return "")
                json.optString("text", "")
            }
        } catch (e: Exception) {
            ""
        }
    }

    fun isServerReachable(): Boolean {
        if (serverUrl.isBlank()) return false
        return try {
            val request = Request.Builder().url("${serverUrl.trimEnd('/')}/health").get().build()
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            false
        }
    }

    /** Iesaiņo raw PCM16 baitus derīgā WAV failā (44 baitu galvene). */
    private fun pcmToWav(pcm: ByteArray, sampleRate: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val totalDataLen = pcm.size + 36
        val byteRate = sampleRate * 2 // 16-bit mono

        fun writeInt(v: Int) {
            out.write(v and 0xff)
            out.write((v shr 8) and 0xff)
            out.write((v shr 16) and 0xff)
            out.write((v shr 24) and 0xff)
        }
        fun writeShort(v: Int) {
            out.write(v and 0xff)
            out.write((v shr 8) and 0xff)
        }

        out.write("RIFF".toByteArray())
        writeInt(totalDataLen)
        out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray())
        writeInt(16)          // fmt chunk size
        writeShort(1)         // PCM
        writeShort(1)         // mono
        writeInt(sampleRate)
        writeInt(byteRate)
        writeShort(2)         // block align
        writeShort(16)        // bits per sample
        out.write("data".toByteArray())
        writeInt(pcm.size)
        out.write(pcm)

        return out.toByteArray()
    }
}
