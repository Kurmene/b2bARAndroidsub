package com.ardecoderar.b2bandroidsub

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Bezmaksas tulkošana tieši telefonā (Google ML Kit) — aizstāj Tilde MT API.
 * Nav vajadzīga API atslēga. Valodu pakas lejupielādējas VIENREIZ (ieteicams
 * caur WiFi) un pēc tam strādā pilnīgi offline.
 */
class MLKitTranslator {

    private val translatorCache = mutableMapOf<String, Translator>()

    private fun mlkitCode(langCode: String): String = when (langCode.lowercase()) {
        "lv" -> TranslateLanguage.LATVIAN
        "ru" -> TranslateLanguage.RUSSIAN
        "en" -> TranslateLanguage.ENGLISH
        "lt" -> TranslateLanguage.LITHUANIAN
        "et" -> TranslateLanguage.ESTONIAN
        "de" -> TranslateLanguage.GERMAN
        "fi" -> TranslateLanguage.FINNISH
        "sv" -> TranslateLanguage.SWEDISH
        "no" -> TranslateLanguage.NORWEGIAN
        "fr" -> TranslateLanguage.FRENCH
        "es" -> TranslateLanguage.SPANISH
        "it" -> TranslateLanguage.ITALIAN
        "pl" -> TranslateLanguage.POLISH
        else -> TranslateLanguage.ENGLISH
    }

    /** Standarta 13 valodas, ko ML Kit šeit konfigurēts atbalstīt. Ārpus šī
     * saraksta esošas valodas jātulko ar NLLB serveri (skat. NllbTranslatorClient). */
    private val supportedCodes = setOf("lv", "ru", "en", "lt", "et", "de", "fi", "sv", "no", "fr", "es", "it", "pl")

    fun supports(langCode: String): Boolean = langCode.lowercase() in supportedCodes

    private fun getTranslator(srcLang: String, trgLang: String): Translator {
        val key = "$srcLang-$trgLang"
        return translatorCache.getOrPut(key) {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(mlkitCode(srcLang))
                .setTargetLanguage(mlkitCode(trgLang))
                .build()
            Translation.getClient(options)
        }
    }

    /**
     * Pārliecinās, ka valodu paka lejupielādēta (jāsauc VIENREIZ pirms
     * pirmās izmantošanas, ieteicams ar WiFi savienojumu).
     */
    suspend fun ensureModelDownloaded(srcLang: String, trgLang: String, wifiOnly: Boolean = true): Boolean {
        val translator = getTranslator(srcLang, trgLang)
        val conditions = DownloadConditions.Builder().apply {
            if (wifiOnly) requireWifi()
        }.build()

        return suspendCancellableCoroutine { cont ->
            translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener { if (cont.isActive) cont.resume(true) }
                .addOnFailureListener { e -> if (cont.isActive) cont.resumeWithException(e) }
        }
    }

    /**
     * Iztulko tekstu. Ja modelis vēl nav lejupielādēts, atgriež oriģinālo
     * tekstu (fail-soft, tāpat kā desktop versijā).
     */
    suspend fun translate(text: String, srcLang: String, trgLang: String): String {
        if (srcLang == trgLang || text.isBlank()) return text
        return try {
            val translator = getTranslator(srcLang, trgLang)
            suspendCancellableCoroutine { cont ->
                translator.translate(text)
                    .addOnSuccessListener { result -> if (cont.isActive) cont.resume(result) }
                    .addOnFailureListener { if (cont.isActive) cont.resume(text) }
            }
        } catch (e: Exception) {
            text
        }
    }

    fun close() {
        translatorCache.values.forEach { it.close() }
        translatorCache.clear()
    }
}
