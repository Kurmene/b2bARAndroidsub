package com.ardecoderar.b2bandroidsub

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle

/**
 * Caurspīdīga (neredzama) darbība, kas parāda Android sistēmas piekrišanas
 * dialogu, lai "noklausītos" citu lietotņu (YouTube, TikTok, Instagram u.c.)
 * atskaņoto skaņu — nevis mikrofonu.
 *
 * SVARĪGI, KAS JĀZINA: Android šai funkcijai izmanto TO PAŠU atļauju
 * mehānismu, ko lieto ekrāna ierakstīšanai (MediaProjection), tāpēc
 * sistēmas dialogs var pieminēt "ierakstīt ekrānu" — tas ir normāli, mēs
 * izmantojam TIKAI audio daļu, ne ekrānu.
 *
 * DAŽAS APP (īpaši YouTube, TikTok, Instagram) var TĪŠI BLOĶĒT šo
 * iespēju autortiesību/licencēšanas apsvērumu dēļ — tas nav kaut kas,
 * ko var apiet ar kodu, tā ir pašas app izvēle.
 */
class MediaProjectionRequestActivity : Activity() {

    private val projectionManager by lazy {
        getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                AppAudioCaptureHolder.resultCode = resultCode
                AppAudioCaptureHolder.resultData = data
                // Palaižam ATSEVIŠĶU servisu citu app skaņas uztveršanai —
                // pilnīgi nodalītu no galvenā tulkošanas servisa.
                startForegroundService(Intent(this, AppAudioCaptureService::class.java))
            } else {
                AppAudioCaptureHolder.resultCode = null
                AppAudioCaptureHolder.resultData = null
            }
        }
        finish()
    }

    companion object {
        private const val REQUEST_CODE = 4321
    }
}

/**
 * Vienkāršs statisks turētājs MediaProjection atļaujas datiem — tie
 * jānodod servisam, un Android neatļauj tos vienkārši ielikt Intent
 * papildu datos droši, tāpēc glabājam procesa atmiņā (derīgs tikai
 * līdz nākamajai app pilnīgai aizvēršanai — tad jāprasa vēlreiz, kas
 * ir arī paša Android drošības prasība šai funkcijai).
 */
object AppAudioCaptureHolder {
    var resultCode: Int? = null
    var resultData: Intent? = null
}
