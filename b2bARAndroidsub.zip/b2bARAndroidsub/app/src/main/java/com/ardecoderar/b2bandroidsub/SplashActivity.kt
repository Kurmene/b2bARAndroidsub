package com.ardecoderar.b2bandroidsub

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Pirmais ekrāns, ko lietotne atver. Ja lietotājs pamācību vēl nav redzējis
 * (pirmā palaišana jebkurā valstī/valodā), rāda to automātiski. Pretējā
 * gadījumā dodas tieši uz galveno ekrānu. Šis Activity pats nekad neko
 * nerāda — tas uzreiz pāradresē tālāk.
 */
class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val config = ConfigManager(this)
        val next = if (config.hasSeenHelp) MainActivity::class.java else HelpActivity::class.java
        startActivity(Intent(this, next))
        finish()
    }
}
