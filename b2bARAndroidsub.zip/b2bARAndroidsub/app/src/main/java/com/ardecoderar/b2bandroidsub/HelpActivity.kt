package com.ardecoderar.b2bandroidsub

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

/**
 * Palīdzības/pamācības ekrāns. Valoda tiek noteikta AUTOMĀTISKI pēc
 * telefona sistēmas valodas — lietotājam nekas nav jāizvēlas. Instrukcija
 * tiek rādīta soli pa solim ar "Tālāk" pogu (lokalizēts nosaukums).
 */
class HelpActivity : AppCompatActivity() {

    private lateinit var titleView: TextView
    private lateinit var stepView: TextView
    private lateinit var progressView: TextView
    private lateinit var nextButton: Button

    private lateinit var content: HelpTexts.HelpContent
    private var stepIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val deviceLang = Locale.getDefault().language
        content = HelpTexts.forDeviceLocale(deviceLang)

        // Vienkārša programmatiska izkārtojums — nav vajadzīgs atsevišķs XML,
        // jo saturs ir dinamisks (mainās atkarībā no soļa).
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(64, 96, 64, 64)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        titleView = TextView(this).apply {
            textSize = 24f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }

        progressView = TextView(this).apply {
            textSize = 14f
            alpha = 0.6f
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 48)
        }

        stepView = TextView(this).apply {
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 96)
        }

        nextButton = Button(this).apply {
            setOnClickListener { onNextClicked() }
        }

        root.addView(titleView)
        root.addView(progressView)
        root.addView(stepView)
        root.addView(nextButton)
        setContentView(root)

        renderStep()
    }

    private fun renderStep() {
        titleView.text = content.title
        progressView.text = "${stepIndex + 1} / ${content.steps.size}"
        stepView.text = content.steps[stepIndex]
        val isLast = stepIndex == content.steps.size - 1
        nextButton.text = if (isLast) content.doneLabel else content.nextLabel
    }

    private fun onNextClicked() {
        val isLast = stepIndex == content.steps.size - 1
        if (isLast) {
            ConfigManager(this).hasSeenHelp = true
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        } else {
            stepIndex++
            renderStep()
        }
    }
}
