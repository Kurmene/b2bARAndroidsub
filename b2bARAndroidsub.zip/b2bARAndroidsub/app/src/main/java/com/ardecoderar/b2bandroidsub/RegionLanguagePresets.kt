package com.ardecoderar.b2bandroidsub

/**
 * Reģionālas valodu kopas — nosaka, kuras valodas visticamāk dzirdēs
 * konkrētā reģionā, lai auto-detekcijas kopums būtu jēdzīgs, nevis
 * jāizvēlas manuāli. Piemēram, Latvijā visticamākās "svešās" valodas
 * ir krievu, angļu, vācu, poļu, lietuviešu, igauņu.
 *
 * PIEZĪME: ne visām šeit minētajām valodām ir pieejams Vosk modelis
 * (piem. lietuviešu un igauņu Vosk NEATBALSTA vispār — tas ir pašas
 * Vosk projekta ierobežojums, ne šī koda). Tās vienkārši tiek izlaistas
 * no automātiskās lejupielādes, un pārējās (kas IR pieejamas) strādā.
 */
object RegionLanguagePresets {

    private val presets: Map<String, List<String>> = mapOf(
        "LV" to listOf("ru", "en", "de", "pl", "lt", "et"),
        "LT" to listOf("ru", "en", "de", "pl", "lv", "et"),
        "EE" to listOf("ru", "en", "de", "fi", "lv", "lt"),
        "DE" to listOf("en", "fr", "pl", "ru", "it"),
        "PL" to listOf("en", "de", "ru", "uk"),
        "FI" to listOf("en", "sv", "ru", "et"),
        "SE" to listOf("en", "de", "fi", "no"),
        "NO" to listOf("en", "sv", "de"),
        "DK" to listOf("en", "de", "sv"),
        "RU" to listOf("en", "de", "fr"),
        "GB" to listOf("fr", "de", "es", "pl"),
        "US" to listOf("es", "fr", "de")
    )

    private val default = listOf("en", "de", "ru")

    fun languagesFor(regionCode: String?): List<String> {
        if (regionCode.isNullOrBlank()) return default
        return presets[regionCode.uppercase()] ?: default
    }
}
