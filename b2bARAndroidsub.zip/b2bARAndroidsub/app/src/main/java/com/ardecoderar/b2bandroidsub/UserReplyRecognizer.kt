package com.ardecoderar.b2bandroidsub

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Klausās LIETOTĀJA latviešu runu, izmantojot Android iebūvēto (Google)
 * runas atpazīšanu — TIKAI šim mērķim, jo Vosk oficiāli NEATBALSTA
 * latviešu valodu (tas atbalsta ap 20 valodām, latviešu to vidū nav).
 *
 * Audio ievade: Android sistēma pati izvēlas mikrofonu pēc AKTĪVĀS
 * komunikācijas ierīces (skat. BluetoothAudioRouter.forcePreferredCommunicationDeviceToHearingAid()).
 * Ja dzirdes aparāts ir savienots un iestatīts kā komunikācijas ierīce,
 * tas tiek izmantots — tāpat kā jebkuras bezvadu austiņas jebkurā citā
 * app. Ja tāda nav, izmanto telefona iebūvēto mikrofonu kā rezervi.
 * Prasa internetu (Google mākoņa atpazīšana).
 */
class UserReplyRecognizer(
    private val context: Context,
    private val onFinal: (String) -> Unit
) {
    private var recognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var active = false

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) return
        active = true
        mainHandler.post {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer?.setRecognitionListener(buildListener())
            launchListening()
        }
    }

    fun stop() {
        active = false
        mainHandler.post {
            recognizer?.stopListening()
            recognizer?.destroy()
            recognizer = null
        }
    }

    private fun launchListening() {
        if (!active) return
        val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "lv-LV")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900)
        }
        recognizer?.startListening(intent)
    }

    private fun buildListener() = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull() ?: return
            if (containsStopWord(text)) onFinal(text)
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!text.isNullOrBlank()) onFinal(text)
            if (active) mainHandler.postDelayed({ launchListening() }, 150)
        }

        override fun onError(error: Int) {
            if (active) mainHandler.postDelayed({ launchListening() }, 150)
        }
    }

    private fun containsStopWord(text: String): Boolean {
        // Ātra pārbaude arī daļējos rezultātos, lai "stop" nostrādātu
        // nekavējoties, negaidot pilnu teikuma pauzi.
        return text.trim().lowercase().contains("stop")
    }
}
