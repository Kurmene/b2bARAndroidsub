package com.ardecoderar.b2bandroidsub

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/**
 * Pēc telefona pārstartēšanas Android automātiski aptur visus fona
 * servisus. Šis saņēmējs tos atsāk — TIKAI balss komandu klausītāju
 * (HotwordListenerService), ne pašu tulkošanu (to sāk "translator on").
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return

        val config = ConfigManager(context)
        if (!config.hotwordEnabled) return
        if (!config.isVoskModelAvailable("en")) return // nav modeļa — nevar klausīties

        ContextCompat.startForegroundService(
            context,
            Intent(context, HotwordListenerService::class.java)
        )
    }
}
