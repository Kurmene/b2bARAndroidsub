package com.ardecoderar.b2bandroidsub

import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File

/**
 * Automātiska valodas noteikšana — palaiž ĪSU audio fragmentu (~1.5-2 sek.)
 * caur VISIEM pieejamiem Vosk modeļiem paralēli un izvēlas to, kuram ir
 * augstākā vidējā vārdu atpazīšanas pārliecība (confidence). Tas ir smagāks
 * process (vairāki modeļi vienlaicīgi RAM), tāpēc izmantojam to TIKAI īsam
 * detekcijas fragmentam katras klausīšanās sesijas sākumā — nevis nepārtraukti.
 */
class LanguageDetector(private val modelsRootDir: File) {

    data class Result(val langCode: String, val confidence: Double)

    /**
     * @param candidateLangCodes valodas, kurām jāmeklē lejupielādēts Vosk modelis
     * @param sampleAudio PCM16 16kHz audio paraugs (ieteicams ~1.5-2 sek.)
     */
    fun detect(candidateLangCodes: List<String>, sampleAudio: ByteArray): Result? {
        var best: Result? = null

        for (lang in candidateLangCodes) {
            val dir = File(modelsRootDir, lang.lowercase())
            if (!dir.exists()) continue // modelis nav lejupielādēts šai valodai — izlaižam

            var model: Model? = null
            var recognizer: Recognizer? = null
            try {
                model = Model(dir.absolutePath)
                recognizer = Recognizer(model, AudioCapture.SAMPLE_RATE.toFloat())
                recognizer.setWords(true)

                recognizer.acceptWaveForm(sampleAudio, sampleAudio.size)
                val json = JSONObject(recognizer.finalResult)
                val score = scoreResult(json)

                if (best == null || score > best!!.confidence) {
                    best = Result(lang, score)
                }
            } catch (e: Exception) {
                // Šis modelis neielādējās vai kļūdojās — vienkārši izlaižam,
                // detekcija turpinās ar pārējiem kandidātiem.
            } finally {
                // KRITISKI: aizver ABUS objektus VIENMĒR, arī ja augšā bija
                // izņēmums — citādi modeļa objekts (liels, native resurss)
                // paliek noplūdis katru reizi, kad kāda valoda kļūdojas.
                try { recognizer?.close() } catch (e: Exception) { }
                try { model?.close() } catch (e: Exception) { }
            }
        }
        return best
    }

    /**
     * Novērtē, cik "pārliecinošs" ir atpazīšanas rezultāts — kombinē vārdu
     * skaitu ar vidējo katra vārda pārliecību. Modelis, kas patiešām atbilst
     * runātajai valodai, parasti dod garāku, augstākas pārliecības rezultātu;
     * nepareizas valodas modelis bieži dod tukšu vai zemas pārliecības tekstu.
     */
    private fun scoreResult(json: JSONObject): Double {
        val text = json.optString("text", "")
        if (text.isBlank()) return 0.0

        val words = json.optJSONArray("result") ?: return text.split(" ").size * 0.3
        var totalConf = 0.0
        for (i in 0 until words.length()) {
            totalConf += words.getJSONObject(i).optDouble("conf", 0.5)
        }
        val avgConf = if (words.length() > 0) totalConf / words.length() else 0.3
        return avgConf * words.length() // garāks + pārliecinošāks = labāks
    }
}
