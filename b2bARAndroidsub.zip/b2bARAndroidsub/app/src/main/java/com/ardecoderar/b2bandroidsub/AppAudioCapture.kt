package com.ardecoderar.b2bandroidsub

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import kotlin.concurrent.thread

/**
 * Uztver CITU lietotņu (YouTube, TikTok, Instagram u.c.) atskaņoto skaņu —
 * NEVIS mikrofonu. Izmanto Android AudioPlaybackCapture API (Android 10+).
 *
 * Prasa MediaProjection atļauju (skat. MediaProjectionRequestActivity) —
 * tā ir sistēmas prasība šai konkrētajai iespējai, ne kaut kas, ko var apiet.
 *
 * IEROBEŽOJUMS: dažas app (bieži tieši YouTube, TikTok, Instagram) var
 * iestatīt savu audio kā "nesagūstamu" (setAllowedCapturePolicy), un tad
 * šis vienkārši neko neuztvers no TĀS konkrētās app — tā ir pašas app
 * izvēle, ne šī koda kļūda.
 */
@SuppressLint("MissingPermission")
class AppAudioCapture(
    private val context: Context,
    private val resultCode: Int,
    private val resultData: Intent,
    private val onAudioChunk: (ByteArray) -> Unit
) {
    companion object {
        const val SAMPLE_RATE = 16000
    }

    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    @Volatile private var running = false

    fun start(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false

        val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = projectionManager.getMediaProjection(resultCode, resultData) ?: return false
        mediaProjection = projection

        val captureConfig = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        val minBufSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )

        val record = try {
            AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(minBufSize * 2)
                .setAudioPlaybackCaptureConfig(captureConfig)
                .build()
        } catch (e: Exception) {
            return false
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            return false
        }

        audioRecord = record
        running = true
        record.startRecording()

        thread(name = "AppAudioCaptureThread") {
            val buffer = ShortArray(minBufSize / 2)
            while (running) {
                val read = record.read(buffer, 0, buffer.size)
                if (read > 0) {
                    val bytes = ByteArray(read * 2)
                    for (i in 0 until read) {
                        val v = buffer[i].toInt()
                        bytes[i * 2] = (v and 0xFF).toByte()
                        bytes[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
                    }
                    onAudioChunk(bytes)
                }
            }
        }
        return true
    }

    fun stop() {
        running = false
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
        mediaProjection?.stop()
        mediaProjection = null
    }
}
