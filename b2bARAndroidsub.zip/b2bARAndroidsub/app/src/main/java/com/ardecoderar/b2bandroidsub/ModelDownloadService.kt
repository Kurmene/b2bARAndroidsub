package com.ardecoderar.b2bandroidsub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Lejupielādē lielos (augstas precizitātes, ~1.8GB) un reģiona valodu
 * modeļus FONA SERVISĀ, nevis piesaistot to pašam ekrānam (Activity).
 *
 * KĀPĒC TAS SVARĪGI: ja lejupielāde piesaistīta Activity (kā tas bija
 * iepriekš), Android to AUTOMĀTISKI PĀRTRAUC, tiklīdz ekrāns izslēdzas,
 * lietotājs pārslēdzas uz citu app, vai sistēma "atbrīvo atmiņu" —
 * tieši tas, kas izskaidro "lādējās, tad pārtrauca" uzvedību lieliem
 * failiem, kas prasa vairākas minūtes. Fona serviss (ar pastāvīgu
 * paziņojumu) NETIEK pārtraukts šādi — tas turpinās, kamēr lejupielāde
 * nav pabeigta.
 */
class ModelDownloadService : Service() {

    companion object {
        const val CHANNEL_ID = "b2b_download_channel"
        const val NOTIF_ID = 4
        const val ACTION_DOWNLOAD_UPDATE = "com.ardecoderar.b2bandroidsub.DOWNLOAD_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_DONE = "done"
        const val EXTRA_LANGS = "langs"
        const val EXTRA_HIGH_ACCURACY = "high_accuracy"
    }

    private var job: Job? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification("Sagatavo lejupielādi..."))

        val highAccuracy = intent?.getBooleanExtra(EXTRA_HIGH_ACCURACY, false) ?: false
        val langsExtra = intent?.getStringArrayExtra(EXTRA_LANGS)?.toList()

        job?.cancel()
        job = CoroutineScope(Dispatchers.IO).launch {
            val config = ConfigManager(this@ModelDownloadService)
            val destRoot = config.voskModelsRootDir()

            val langsToDownload: List<String> = if (highAccuracy) {
                ModelDownloader.highAccuracyModels.keys.toList()
            } else {
                langsExtra ?: emptyList()
            }

            for (lang in langsToDownload) {
                updateNotification("Lejupielādē '$lang'... 0%")
                broadcastStatus("Lejupielādē '$lang'... 0%", false)

                val ok = if (highAccuracy) {
                    ModelDownloader.downloadHighAccuracy(lang, destRoot) { percent ->
                        val text = "Augsta precizitāte '$lang'... $percent%"
                        updateNotification(text)
                        broadcastStatus(text, false)
                    }
                } else {
                    ModelDownloader.downloadAndInstall(lang, destRoot) { percent ->
                        val text = "Lejupielādē '$lang'... $percent%"
                        updateNotification(text)
                        broadcastStatus(text, false)
                    }
                }

                if (!ok) {
                    broadcastStatus("Neizdevās lejupielādēt '$lang'", false)
                }
            }

            updateNotification("Lejupielāde pabeigta")
            broadcastStatus("Visas valodas gatavas", true)
            stopSelf()
        }

        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "b2bARAndroidsub — modeļu lejupielāde", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("b2bARAndroidsub — lejupielāde")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun broadcastStatus(status: String, done: Boolean) {
        val intent = Intent(ACTION_DOWNLOAD_UPDATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_DONE, done)
        }
        sendBroadcast(intent)
    }
}
