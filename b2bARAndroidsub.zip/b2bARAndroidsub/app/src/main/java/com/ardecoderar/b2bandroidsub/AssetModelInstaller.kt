package com.ardecoderar.b2bandroidsub

import android.content.Context
import java.io.File

/**
 * Uzstāda Vosk valodu modeļus, kas ir IEBŪVĒTI pašā APK failā (assets
 * mapē), uz iekšējo krātuvi — TAS NOTIEK PIRMAJĀ PALAIŠANAS REIZĒ,
 * BEZ INTERNETA, jo faili jau ir paša APK iekšā.
 *
 * KĀ ŠO IZMANTOT (viens vienreizējs solis TEV, pirms būvē app):
 * 1. Lejupielādē vajadzīgos Vosk modeļus (piem. no
 *    https://alphacephei.com/vosk/models) savā datorā.
 * 2. Izpako katru — iekšā būs mape ar failiem (am/, conf/, graph/ utt.).
 * 3. Šo IZPAKOTO SATURU ievieto projektā:
 *    app/src/main/assets/vosk_models/de/   <- vācu modeļa saturs
 *    app/src/main/assets/vosk_models/en/   <- angļu modeļa saturs
 *    (un tā tālāk citām valodām, ko vēlies iebūvēt)
 * 4. Augšupielādē visu projektu (ieskaitot jaunos assets failus) uz
 *    GitHub un sabūvē kā parasti.
 *
 * PĒC TAM: katra jauna instalēšana strādās UZREIZ, bez lejupielādes —
 * šī klase automātiski atrod un izkopē failus no APK uz iekšējo krātuvi
 * pirmajā palaišanas reizē.
 *
 * SVARĪGI: šis PALIELINA APK failu par tik, cik sver iebūvētie modeļi
 * (piem. +170MB, ja iebūvē vācu+angļu lgraph modeļus). Tas ir
 * nepieciešams kompromiss, lai sasniegtu "strādā uzreiz bez lejupielādes".
 */
object AssetModelInstaller {

    /**
     * Pārbauda, vai APK assets satur kādus iebūvētus modeļus, un, ja jā,
     * izkopē tos uz iekšējo krātuvi (TIKAI ja tur vēl nav). Atgriež
     * izkopēto valodu kodu sarakstu.
     */
    fun installBundledModelsIfPresent(context: Context, destRootDir: File): List<String> {
        val installed = mutableListOf<String>()
        val assetManager = context.assets

        val bundledLangs = try {
            assetManager.list("vosk_models") ?: return installed
        } catch (e: Exception) {
            return installed
        }

        for (lang in bundledLangs) {
            // Izlaižam failus (piem. instrukciju .txt), apstrādājam TIKAI mapes.
            val childEntries = assetManager.list("vosk_models/$lang")
            if (childEntries == null || childEntries.isEmpty()) continue

            val destDir = File(destRootDir, lang)
            // Ja modelis JAU uzstādīts (piem. lietotājs to lejupielādēja
            // manuāli agrāk), nepārrakstām — netērējam laiku/vietu.
            if (destDir.exists() && (File(destDir, "conf").exists() || File(destDir, "am").exists())) {
                continue
            }

            try {
                copyAssetFolder(assetManager, "vosk_models/$lang", destDir)
                installed.add(lang)
            } catch (e: Exception) {
                // Ja kopēšana neizdodas kādai valodai, turpinām ar pārējām —
                // lietotājs vienmēr var lejupielādēt to manuāli/automātiski vēlāk.
            }
        }
        return installed
    }

    private fun copyAssetFolder(assetManager: android.content.res.AssetManager, assetPath: String, destDir: File) {
        val files = assetManager.list(assetPath) ?: return
        destDir.mkdirs()

        if (files.isEmpty()) {
            // Tas ir fails, ne mape
            copyAssetFile(assetManager, assetPath, destDir)
            return
        }

        for (fileName in files) {
            val childAssetPath = "$assetPath/$fileName"
            val childFiles = assetManager.list(childAssetPath)
            if (childFiles != null && childFiles.isNotEmpty()) {
                copyAssetFolder(assetManager, childAssetPath, File(destDir, fileName))
            } else {
                copyAssetFileTo(assetManager, childAssetPath, File(destDir, fileName))
            }
        }
    }

    private fun copyAssetFile(assetManager: android.content.res.AssetManager, assetPath: String, destDir: File) {
        val fileName = assetPath.substringAfterLast('/')
        copyAssetFileTo(assetManager, assetPath, File(destDir, fileName))
    }

    private fun copyAssetFileTo(assetManager: android.content.res.AssetManager, assetPath: String, destFile: File) {
        destFile.parentFile?.mkdirs()
        assetManager.open(assetPath).use { input ->
            destFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }
    }
}
