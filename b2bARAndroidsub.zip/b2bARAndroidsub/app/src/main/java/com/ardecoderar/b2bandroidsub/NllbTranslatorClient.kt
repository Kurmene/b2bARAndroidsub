package com.ardecoderar.b2bandroidsub

import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Klients Meta NLLB tulkošanas serverim (skat. server/mms_server.py,
 * endpoint /translate) — izmanto TIKAI valodām, kurām ML Kit Translation
 * neder. Vajag to pašu serveri, ko izmanto MetaMmsAsrClient.
 */
class NllbTranslatorClient(
    private val serverUrl: String,
    private val apiKey: String
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    /** Iztulko tekstu. Ja serveris nav pieejams, atgriež oriģinālo tekstu (fail-soft). */
    fun translate(text: String, srcLang: String, tgtLang: String): String {
        if (serverUrl.isBlank() || text.isBlank() || srcLang == tgtLang) return text

        return try {
            val multipart = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("text", text)
                .addFormDataPart("src_lang", srcLang)
                .addFormDataPart("tgt_lang", tgtLang)
                .build()

            val requestBuilder = Request.Builder()
                .url("${serverUrl.trimEnd('/')}/translate")
                .post(multipart)

            if (apiKey.isNotBlank()) {
                requestBuilder.addHeader("x-api-key", apiKey)
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                if (!response.isSuccessful) return text
                val json = JSONObject(response.body?.string() ?: return text)
                json.optString("translation", text)
            }
        } catch (e: Exception) {
            text
        }
    }
}
