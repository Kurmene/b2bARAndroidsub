package com.ardecoderar.b2bandroidsub

import android.content.Context
import java.io.File

/**
 * Iestatījumu pārvaldnieks. Vairs nav vajadzīgas maksas API atslēgas —
 * tulkošana (ML Kit) un runas atpazīšana (Vosk) strādā tieši telefonā,
 * bez maksas. Vienīgais priekšnoteikums: Vosk valodu modeļi jābūt
 * lejupielādētiem un izpakotiem telefonā (skat. README).
 */
class ConfigManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("b2b_config", Context.MODE_PRIVATE)

    // Avota valoda, ko klausās pēc noklusējuma (piem. vācu)
    var sourceLang: String
        get() = prefs.getString("source_lang", "de") ?: "de"
        set(value) = prefs.edit().putString("source_lang", value).apply()

    // Mērķa valoda avota tulkojumam (tev dzirdamā izvade)
    var targetLang: String
        get() = prefs.getString("target_lang", "lv") ?: "lv"
        set(value) = prefs.edit().putString("target_lang", value).apply()

    // Valoda, kādā vienmēr runā tavas atbildes tulkojumu (angliski, pēc pieprasījuma)
    var replyOutputLang: String
        get() = prefs.getString("reply_output_lang", "en") ?: "en"
        set(value) = prefs.edit().putString("reply_output_lang", value).apply()

    // Atslēgvārds stāvokļu pārslēgšanai
    var wakeWord: String
        get() = prefs.getString("wake_word", "stop") ?: "stop"
        set(value) = prefs.edit().putString("wake_word", value).apply()

    /**
     * Vosk modeļu mape — apakšmapes nosauktas pēc valodas koda, piem.
     * .../vosk_models/de/  un  .../vosk_models/en/
     * Lietotājs tur ievieto izpakotos modeļus caur failu pārvaldnieku.
     */
    fun voskModelsRootDir(): File {
        val dir = File(context.getExternalFilesDir(null), "vosk_models")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun voskModelDirFor(langCode: String): File = File(voskModelsRootDir(), langCode.lowercase())

    fun isVoskModelAvailable(langCode: String): Boolean {
        val dir = voskModelDirFor(langCode)
        // Derīgs Vosk modelis satur "am/final.mdl" vai vismaz "conf" apakšmapi
        return dir.exists() && (File(dir, "conf").exists() || File(dir, "am").exists())
    }

    // Automātiska avota valodas noteikšana (starp visām lejupielādētajām
    // Vosk valodām) — noklusēti IESLĒGTA pēc pieprasījuma.
    var autoDetectSourceLang: Boolean
        get() = prefs.getBoolean("auto_detect_source", true)
        set(value) = prefs.edit().putBoolean("auto_detect_source", value).apply()

    /** Atgriež visu valodu kodu sarakstu, kurām ir lejupielādēts Vosk modelis. */
    fun availableVoskLanguages(): List<String> {
        val root = voskModelsRootDir()
        return root.listFiles { f -> f.isDirectory }
            ?.map { it.name }
            ?.filter { isVoskModelAvailable(it) }
            ?: emptyList()
    }

    // Meta MMS servera iestatījumi (1100+ valodu atbalsts, prasa internetu
    // un paša uzstādītu serveri — skat. server/mms_server.py)
    var mmsServerUrl: String
        get() = prefs.getString("mms_server_url", "") ?: ""
        set(value) = prefs.edit().putString("mms_server_url", value).apply()

    var mmsApiKey: String
        get() = prefs.getString("mms_api_key", "") ?: ""
        set(value) = prefs.edit().putString("mms_api_key", value).apply()

    // ElevenLabs API atslēga — dabiskāka balss sintēze nekā Android TTS.
    // Tukšs = izmanto Android iebūvēto TTS (bezmaksas rezerve).
    var elevenLabsApiKey: String
        get() = prefs.getString("elevenlabs_api_key", "") ?: ""
        set(value) = prefs.edit().putString("elevenlabs_api_key", value.trim()).apply()

    fun isElevenLabsConfigured(): Boolean = elevenLabsApiKey.isNotBlank()

    // Pielāgota valoda ārpus standarta 13 valodu saraksta (ISO kods, piem.
    // "uk", "ar", "zh") — ja aizpildīts, izmanto MMS serveri šai valodai.
    var customSourceLangCode: String
        get() = prefs.getString("custom_source_lang", "") ?: ""
        set(value) = prefs.edit().putString("custom_source_lang", value.trim()).apply()

    fun isMmsConfigured(): Boolean = mmsServerUrl.isNotBlank()

    fun isConfigured(): Boolean =
        isVoskModelAvailable("en") &&
            (isVoskModelAvailable(sourceLang) ||
                (autoDetectSourceLang && availableVoskLanguages().isNotEmpty()) ||
                (customSourceLangCode.isNotBlank() && isMmsConfigured()))

    // Vai balss komandu klausītājs ("translator on/off") jāpatur ieslēgts
    // pastāvīgi — noklusēti IESLĒGTS, lai viss darbotos automātiski bez
    // pogu spiešanas, arī pēc telefona pārstartēšanas.
    var hotwordEnabled: Boolean
        get() = prefs.getBoolean("hotword_enabled", true)
        set(value) = prefs.edit().putBoolean("hotword_enabled", value).apply()

    // Vai izmantot dzirdes aparāta mikrofonu (Bluetooth SCO). NOKLUSĒTI
    // IZSLĒGTS — jo nepārtraukts SCO savienojums liek dzirdes aparātam
    // domāt, ka notiek telefona zvans, kas SAMAZINA normālo apkārtējās
    // vides skaņas pastiprināšanu (zvana laikā dzirdes aparāts prioritizē
    // zvanu, ne istabas skaņas). Telefona mikrofons šo blakusefektu
    // nerada, tāpēc tas ir drošāks noklusējums ikdienas lietošanai.
    var useHearingAidMic: Boolean
        get() = prefs.getBoolean("use_hearing_aid_mic", false)
        set(value) = prefs.edit().putBoolean("use_hearing_aid_mic", value).apply()

    // Vai lietotājs jau redzējis pamācību (rāda tikai vienreiz pirmajā palaišanā)
    var hasSeenHelp: Boolean
        get() = prefs.getBoolean("has_seen_help", false)
        set(value) = prefs.edit().putBoolean("has_seen_help", value).apply()
}
