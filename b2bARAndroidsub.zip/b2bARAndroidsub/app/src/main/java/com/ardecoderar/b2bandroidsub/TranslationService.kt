package com.ardecoderar.b2bandroidsub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * b2bARAndroidsub — galvenais fona serviss.
 *
 * Audio ievade (avota pusei): dzirdes aparāta mikrofons — atbalsta gan
 * LE Audio/HAP, gan klasisko Bluetooth SCO/HFP (piem. Phonak Naída
 * Lumity L90-PR) — skat. BluetoothAudioRouter. Ja nekas nav pieejams,
 * telefona mikrofons kalpo kā rezerve.
 *
 * ASR (avota pusei): Vosk — bezmaksas, offline, tieši telefonā.
 * ASR (lietotāja atbildēm latviski): Android/Google runas atpazīšana —
 *   izmantota TIKAI šai daļai, jo Vosk latviešu valodu neatbalsta.
 * MT: Google ML Kit Translation (bezmaksas, offline) + Meta NLLB serveris
 *   (rezervei retākām valodām, ja konfigurēts).
 * Izvade: Android TextToSpeech (plūst uz dzirdes aparātu automātiski).
 *
 * DIVVIRZIENU SARUNA, "stop" pārslēdz:
 *  - LISTENING_SOURCE: klausās otru pusi (auto-noteikta valoda) -> tulko -> runā LV
 *  - LISTENING_USER: klausās TEVI latviski -> tulko -> runā EN (otrai pusei)
 *
 * Servisu var arī ieslēgt/izslēgt ar balss komandām "translator on" /
 * "translator off" — skat. HotwordListenerService.
 */
class TranslationService : Service() {

    companion object {
        const val CHANNEL_ID = "b2b_translation_channel"
        const val NOTIF_ID = 1
        const val ACTION_STATE_UPDATE = "com.ardecoderar.b2bandroidsub.STATE_UPDATE"
        const val EXTRA_STATE = "state"
        const val EXTRA_LAST_TEXT = "last_text"
        const val EXTRA_LAST_TRANSLATION = "last_translation"
        const val EXTRA_MIC_SOURCE = "mic_source"
        const val ACTION_APP_AUDIO_GRANTED = "com.ardecoderar.b2bandroidsub.APP_AUDIO_GRANTED"

        // ~1.8 sekundes PCM16 16kHz audio parauga valodas detekcijai
        private const val DETECTION_SAMPLE_BYTES = (AudioCapture.SAMPLE_RATE * 2 * 1.8).toInt()
    }

    private lateinit var config: ConfigManager
    private lateinit var translator: MLKitTranslator
    private lateinit var micRouter: BluetoothAudioRouter
    private lateinit var languageDetector: LanguageDetector
    private lateinit var mmsClient: MetaMmsAsrClient
    private lateinit var nllbClient: NllbTranslatorClient

    private var audioCapture: AudioCapture? = null
    private var asrClient: VoskAsrClient? = null
    private var userReplyRecognizer: UserReplyRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wakeLock: PowerManager.WakeLock? = null

    private var state = ConversationState.LISTENING_SOURCE
    private var isRunning = false
    @Volatile private var usingClassicSco = false
    // Faktiski konstatētā/izmantotā avota valoda šajā klausīšanās sesijā
    @Volatile private var activeSourceLang: String = "de"
    @Volatile private var lastSuccessfulRecognitionAt: Long = System.currentTimeMillis()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        config = ConfigManager(this)
        translator = MLKitTranslator()
        micRouter = BluetoothAudioRouter(this)
        languageDetector = LanguageDetector(config.voskModelsRootDir())
        mmsClient = MetaMmsAsrClient(config.mmsServerUrl, config.mmsApiKey)
        nllbClient = NllbTranslatorClient(config.mmsServerUrl, config.mmsApiKey)
        activeSourceLang = config.sourceLang
        createNotificationChannel()
        setupTts()
        prefetchCommonTranslationModels()
    }

    /**
     * KRITISKI SVARĪGI: ML Kit tulkošanas modeļi (piem. "angļu→latviešu")
     * jālejupielādē VIENREIZ, PIRMS tos var izmantot — citādi translate()
     * klusi neizdodas un atgriež oriģinālo (netulkoto) tekstu, kas
     * TTS izvadē izklausās pēc "runā svešvalodā, ne latviski".
     *
     * Šeit proaktīvi lejupielādējam biežāk vajadzīgos pārus servisa
     * sākumā (fonā, neaptur klausīšanos), lai tie jau būtu gatavi, kad
     * pienāk pirmā reālā frāze.
     */
    private fun prefetchCommonTranslationModels() {
        val commonPairs = listOf(
            "de" to "lv", "en" to "lv", "ru" to "lv", "lt" to "lv",
            "lv" to "en" // lietotāja atbilžu virziens
        )
        CoroutineScope(Dispatchers.IO).launch {
            for ((src, trg) in commonPairs) {
                try {
                    translator.ensureModelDownloaded(src, trg, wifiOnly = false)
                } catch (e: Exception) {
                    // Klusi turpinām — ja šis pāris neizdodas (piem. nav interneta),
                    // ensureModelDownloadedForPair() to mēģinās vēlreiz vajadzības brīdī.
                }
            }
        }
    }

    /**
     * Pārliecinās, ka konkrētais valodu pāris ir lejupielādēts TIEŠI PIRMS
     * lietošanas — drošības tīkls gadījumā, ja proaktīvā lejupielāde
     * (prefetchCommonTranslationModels) vēl nebija paspējusi pabeigt vai
     * valoda nebija iepriekš zināmajā sarakstā (piem. auto-noteikta reta valoda).
     */
    private suspend fun ensureModelDownloadedForPair(srcLang: String, trgLang: String) {
        if (!translator.supports(srcLang) || !translator.supports(trgLang)) return
        try {
            translator.ensureModelDownloaded(srcLang, trgLang, wifiOnly = false)
        } catch (e: Exception) {
            // Ja lejupielāde neizdodas (piem. nav interneta), translate()
            // vienalga mēģinās un fail-soft atgriezīs oriģinālo tekstu.
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        var micLabel: String

        if (!config.useHearingAidMic) {
            // Noklusējums: telefona mikrofons — dzirdes aparāts turpina
            // strādāt NORMĀLI, bez samazinātas apkārtējās skaņas.
            usingClassicSco = false
            micLabel = "Telefona mikrofons (dzirdes aparāts strādā normāli)"
        } else {
            val leAudioDevice = micRouter.findHearingAidInputDevice()
            if (leAudioDevice != null) {
                usingClassicSco = false
                micLabel = micRouter.describeDevice(leAudioDevice)
            } else if (micRouter.hasClassicBluetoothHeadset()) {
                usingClassicSco = micRouter.startClassicScoAndWait()
                micLabel = if (usingClassicSco) {
                    micRouter.describeDevice(null) + " — UZMANĪBU: samazina apkārtējās skaņas skaļumu"
                } else {
                    "Telefona mikrofons (SCO savienojums neizdevās)"
                }
            } else {
                usingClassicSco = false
                micLabel = "Telefona mikrofons (dzirdes aparāta mikrofons nav pieejams)"
            }
        }

        startForeground(NOTIF_ID, buildNotification("Klausās ($micLabel)"))

        // Drošības atiestatīšana: ja iepriekšējā sesijā bija aktivizēts SCO
        // (dzirdes aparāta mikrofons), audio sistēma var būt "iestrēgusi"
        // zvana režīmā (MODE_IN_COMMUNICATION), kas padara TTS runu klusu.
        // Ja tagad NEizmantojam dzirdes aparāta mikrofonu, piespiedu kārtā
        // atiestatām uz normālu režīmu.
        if (!config.useHearingAidMic) {
            val audioManager = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
            audioManager.mode = android.media.AudioManager.MODE_NORMAL
            @Suppress("DEPRECATION")
            audioManager.isBluetoothScoOn = false
        }

        if (wakeLock == null) {
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "b2bARAndroidsub::TranslationWakeLock"
            ).apply {
                setReferenceCounted(false)
                acquire(12 * 60 * 60 * 1000L)
            }
        }

        if (!isRunning) {
            isRunning = true
            state = ConversationState.LISTENING_SOURCE
            broadcastMicSource(micLabel)
            startPipelineForCurrentState()
        }
        return START_STICKY
    }

    /**
     * Ja lietotājs jau piešķīris MediaProjection atļauju (skat.
     * MediaProjectionRequestActivity), palaiž ATSEVIŠĶU servisu
     * (AppAudioCaptureService), kas uztver citu app skaņu — PILNĪGI
     * nodalīts no šī servisa, lai nekad neietekmētu pamata mikrofona
     * klausīšanos.
     */
    private fun startAppAudioPipelineIfGranted() {
        val code = AppAudioCaptureHolder.resultCode
        val data = AppAudioCaptureHolder.resultData
        if (code == null || data == null) return
        androidx.core.content.ContextCompat.startForegroundService(
            this, Intent(this, AppAudioCaptureService::class.java)
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /** Atgriež dzirdes aparāta ierīci TIKAI tad, ja lietotājs to izvēlējies (useHearingAidMic=true). */
    private fun currentInputDevice() = if (config.useHearingAidMic) micRouter.findHearingAidInputDevice() else null

    override fun onDestroy() {
        isRunning = false
        mainHandler.removeCallbacks(languageRecheckRunnable)
        audioCapture?.stop()
        asrClient?.close()
        userReplyRecognizer?.stop()
        translator.close()
        micRouter.release()
        tts?.stop()
        tts?.shutdown()
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }

    // ─────────────────────────────────────────────
    // Pipeline: mikrofons -> ASR -> ("stop" pārbaude / tulkošana)
    // ─────────────────────────────────────────────

    private fun startPipelineForCurrentState() {
        audioCapture?.stop()
        asrClient?.close()
        userReplyRecognizer?.stop()
        mainHandler.removeCallbacks(languageRecheckRunnable)

        when (state) {
            ConversationState.LISTENING_USER -> startUserReplyPipeline()
            ConversationState.LISTENING_SOURCE -> {
                if (config.customSourceLangCode.isNotBlank() && config.isMmsConfigured()) {
                    activeSourceLang = config.customSourceLangCode
                    startMmsPipeline(activeSourceLang)
                } else if (config.autoDetectSourceLang) {
                    runDetectionThenListen()
                } else {
                    activeSourceLang = config.sourceLang
                    startAsrPipeline(activeSourceLang)
                }
            }
        }
        updateStatusLabel()
    }

    /**
     * Klausās PAŠU LIETOTĀJU latviski (Android/Google runas atpazīšana,
     * jo Vosk latviešu valodu neatbalsta). Kad dzird "stop", pārslēdzas
     * atpakaļ uz LISTENING_SOURCE.
     */
    private fun startUserReplyPipeline() {
        if (!isRunning) return
        // Piespiež sistēmas runas atpazīšanai izmantot dzirdes aparāta
        // mikrofonu (nevis telefona iebūvēto) — tāpat kā jebkuras bezvadu
        // austiņas jebkurā citā app.
        micRouter.forcePreferredCommunicationDeviceToHearingAid()
        userReplyRecognizer = UserReplyRecognizer(this) { text ->
            mainHandler.post { handleUserReplyResult(text) }
        }
        userReplyRecognizer?.start()
    }

    private fun handleUserReplyResult(text: String) {
        if (containsWakeWord(text)) {
            val before = stripWakeWord(text)
            if (before.isNotBlank()) {
                translateUserReplyAndSpeak(before)
            }
            performSwitch()
        } else if (text.isNotBlank()) {
            translateUserReplyAndSpeak(text)
        }
    }

    private fun translateUserReplyAndSpeak(text: String) {
        CoroutineScope(Dispatchers.IO).launch {
            ensureModelDownloadedForPair("lv", "en")
            val translated = translator.translate(text, "lv", "en")
            mainHandler.post {
                speak(translated, "en")
                broadcastState(null, text, translated)
            }
        }
    }

    /**
     * MMS servera pipeline (skat. MetaMmsAsrClient) — izmanto FIKSĒTA LOGA
     * pieeju (~3 sek. fragmenti), nevis Vosk straumēšanu.
     */
    private fun startMmsPipeline(langCode: String) {
        if (!isRunning || state != ConversationState.LISTENING_SOURCE) return
        if (!mmsClient.isServerReachable()) {
            updateStatusLabel(extra = " — MMS serveris nav sasniedzams ($langCode)")
        }

        val windowBytes = AudioCapture.SAMPLE_RATE * 2 * 3
        val buffer = java.io.ByteArrayOutputStream()

        val device = currentInputDevice()
        audioCapture = AudioCapture(device, usingClassicSco) { bytes ->
            synchronized(buffer) {
                buffer.write(bytes)
                if (buffer.size() >= windowBytes) {
                    val chunk = buffer.toByteArray()
                    buffer.reset()
                    CoroutineScope(Dispatchers.IO).launch {
                        val text = mmsClient.recognize(chunk, langCode)
                        if (text.isNotBlank()) {
                            mainHandler.post { handleFinal(text) }
                        }
                    }
                }
            }
        }
        audioCapture?.start()
    }

    /**
     * Ievāc īsu (~1.8s) audio paraugu, palaiž to caur visiem lejupielādētajiem
     * Vosk modeļiem (LanguageDetector), un tad turpina klausīšanos ar
     * atpazīto valodu.
     */
    private fun runDetectionThenListen() {
        updateStatusLabel(extra = " — nosaka valodu...")

        val candidates = config.availableVoskLanguages()
        if (candidates.isEmpty()) {
            activeSourceLang = config.sourceLang
            startAsrPipeline(activeSourceLang)
            return
        }

        val sampleBuffer = java.io.ByteArrayOutputStream()
        var sampleCapture: AudioCapture? = null
        val device = currentInputDevice()

        sampleCapture = AudioCapture(device, usingClassicSco) { bytes ->
            synchronized(sampleBuffer) {
                if (sampleBuffer.size() < DETECTION_SAMPLE_BYTES) {
                    sampleBuffer.write(bytes)
                }
                if (sampleBuffer.size() >= DETECTION_SAMPLE_BYTES) {
                    sampleCapture?.stop()
                    val sample = sampleBuffer.toByteArray()
                    CoroutineScope(Dispatchers.Default).launch {
                        val result = languageDetector.detect(candidates, sample)
                        activeSourceLang = result?.langCode ?: config.sourceLang
                        mainHandler.post {
                            if (state == ConversationState.LISTENING_SOURCE) startAsrPipeline(activeSourceLang)
                        }
                    }
                }
            }
        }
        audioCapture = sampleCapture
        sampleCapture.start()
    }

    private fun startAsrPipeline(langCode: String) {
        if (!isRunning || state != ConversationState.LISTENING_SOURCE) return

        val modelDir = config.voskModelDirFor(langCode)
        if (!config.isVoskModelAvailable(langCode)) {
            updateStatusLabel(extra = " — TRŪKST Vosk modeļa priekš '$langCode'")
            return
        }

        // Atiestata "klusuma" taimeri TIEŠI TAGAD — citādi tas varētu
        // uzkrāties no senāka brīža un izraisīt NEPĀRTRAUKTU restartēšanos
        // ik pa 20 sekundēm, pat ja atpazīšana vienkārši vēl nav paspējusi
        // "noslēgt" pirmo teikumu.
        lastSuccessfulRecognitionAt = System.currentTimeMillis()

        asrClient = VoskAsrClient(
            modelDir = modelDir,
            onInterim = { text -> handleInterim(text) },
            onFinal = { text -> handleFinal(text) },
            onError = { /* klusi turpina */ }
        )
        asrClient?.connect()

        val device = currentInputDevice()
        audioCapture = AudioCapture(device, usingClassicSco) { bytes ->
            asrClient?.sendAudio(bytes)
        }
        audioCapture?.start()

        // Periodiski PĀRBAUDA valodu no jauna (ne tikai vienreiz sesijas
        // sākumā) — ja runātājs PĒKŠŅI pāriet uz citu valodu, sistēma to
        // pati pamana un pielāgojas, negaidot "stop" komandu.
        scheduleLanguageRecheck()
    }

    private val languageRecheckRunnable = Runnable {
        // Pārbaudam VALODU NO JAUNA TIKAI TAD, ja pēdējā laikā NAV bijis
        // veiksmīgu atpazīšanas rezultātu (t.i., pašreizējā valoda,
        // iespējams, ir nepareiza). Ja atpazīšana strādā labi, NEpārtraucam
        // to katras 15 sekundes — tas pasliktināja kvalitāti.
        val quietFor = System.currentTimeMillis() - lastSuccessfulRecognitionAt
        if (isRunning && state == ConversationState.LISTENING_SOURCE && config.autoDetectSourceLang && quietFor > 12_000) {
            runDetectionThenListen()
        } else {
            scheduleLanguageRecheck()
        }
    }

    private fun scheduleLanguageRecheck() {
        mainHandler.removeCallbacks(languageRecheckRunnable)
        mainHandler.postDelayed(languageRecheckRunnable, 20_000) // pārbauda ik pa ~20 sekundēm, tikai ja klusums
    }

    private fun handleInterim(text: String) {
        if (text.isNotBlank()) lastSuccessfulRecognitionAt = System.currentTimeMillis()
        if (containsWakeWord(text)) {
            performSwitch()
        }
    }

    private fun handleFinal(text: String) {
        if (text.isBlank()) return
        lastSuccessfulRecognitionAt = System.currentTimeMillis()
        if (containsWakeWord(text)) {
            performSwitch()
            return
        }
        translateAndSpeak(text)
    }

    // ─────────────────────────────────────────────
    // "Stop" apstrāde
    // ─────────────────────────────────────────────

    private fun containsWakeWord(text: String): Boolean {
        val word = config.wakeWord.trim()
        if (word.isEmpty()) return false
        return text.trim().lowercase(Locale.getDefault())
            .contains(word.lowercase(Locale.getDefault()))
    }

    private fun stripWakeWord(text: String): String {
        val word = config.wakeWord.trim()
        if (word.isEmpty()) return text
        return text.replace(Regex("(?i)${Regex.escape(word)}"), "").trim()
    }

    @Volatile private var switching = false

    /** "stop" pasaukts -> pilnībā pārslēdz LISTENING_SOURCE <-> LISTENING_USER. */
    private fun performSwitch() {
        if (switching) return
        switching = true

        state = when (state) {
            ConversationState.LISTENING_SOURCE -> ConversationState.LISTENING_USER
            ConversationState.LISTENING_USER -> ConversationState.LISTENING_SOURCE
        }

        mainHandler.post {
            startPipelineForCurrentState()
            switching = false
        }
    }

    // ─────────────────────────────────────────────
    // Tulkošana un runa (avota puse -> vienmēr latviski)
    // ─────────────────────────────────────────────

    private fun translateAndSpeak(text: String) {
        val srcLang = activeSourceLang
        val outLang = "lv"
        CoroutineScope(Dispatchers.IO).launch {
            val translated = if (translator.supports(srcLang) && translator.supports(outLang)) {
                ensureModelDownloadedForPair(srcLang, outLang)
                translator.translate(text, srcLang, outLang)
            } else {
                nllbClient.translate(text, srcLang, outLang)
            }
            mainHandler.post {
                speak(translated, outLang)
                broadcastState(null, text, translated)
            }
        }
    }

    private fun setupTts() {
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                // Piespiež TTS runu VIENMĒR iet caur standarta multivides
                // skaļuma kanālu (USAGE_MEDIA), NEATKARĪGI no jebkāda cita
                // audio režīma stāvokļa (piem. ja kaut kur palicis
                // "zvana režīms" no Bluetooth SCO) — tas ir daudz spēcīgāks
                // labojums par vienkāršu AudioManager.mode atiestatīšanu.
                val attrs = android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                tts?.setAudioAttributes(attrs)
            } else {
                updateStatusLabel(extra = " — UZMANĪBU: TTS dzinējs neielādējās, runa nestrādās")
            }
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {}
                override fun onError(utteranceId: String?) {}
            })
        }
    }

    private fun speak(text: String, langCode: String) {
        if (text.isBlank()) return

        // Ja ir ievadīta ElevenLabs API atslēga, izmanto TO (dabiskāka
        // balss). Fail-soft: ja izsaukums neizdodas, automātiski pāriet
        // uz Android TTS kā rezervi, lai runa nekad nepaliktu klusa.
        if (config.isElevenLabsConfigured()) {
            CoroutineScope(Dispatchers.IO).launch {
                val client = ElevenLabsClient(config.elevenLabsApiKey)
                client.synthesizeAndPlay(text, cacheDir) { success ->
                    if (!success) {
                        mainHandler.post { speakWithAndroidTts(text, langCode) }
                    }
                }
            }
            return
        }

        speakWithAndroidTts(text, langCode)
    }

    private fun speakWithAndroidTts(text: String, langCode: String) {
        if (!ttsReady) {
            updateStatusLabel(extra = " — TTS nav gatavs, runa izlaista")
            return
        }
        if (text.isBlank()) return

        // Piespiedu kārtā pieprasa audio fokusu tieši pirms runāšanas —
        // dažām ierīcēm bez tā TTS skaņa var palikt klusa, pat ja pati
        // funkcija "veiksmīgi" izpildās.
        val audioManager = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        @Suppress("DEPRECATION")
        audioManager.requestAudioFocus(
            null,
            android.media.AudioManager.STREAM_MUSIC,
            android.media.AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
        )

        val locale = when (langCode.lowercase()) {
            "lv" -> Locale("lv", "LV")
            "ru" -> Locale("ru", "RU")
            "en" -> Locale.US
            "lt" -> Locale("lt", "LT")
            "et" -> Locale("et", "EE")
            "de" -> Locale.GERMAN
            "fi" -> Locale("fi", "FI")
            "sv" -> Locale("sv", "SE")
            "no" -> Locale("no", "NO")
            "fr" -> Locale.FRENCH
            "es" -> Locale("es", "ES")
            "it" -> Locale.ITALIAN
            "pl" -> Locale("pl", "PL")
            else -> Locale.US
        }
        val result = tts?.setLanguage(locale)
        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, android.media.AudioManager.STREAM_MUSIC)
        }
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.language = Locale.getDefault()
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "b2b_utterance_fallback")
            return
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "b2b_utterance")
    }

    // ─────────────────────────────────────────────
    // Paziņojumi (foreground service)
    // ─────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "b2bARAndroidsub tulkošana",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("b2bARAndroidsub")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    private fun updateStatusLabel(extra: String = "") {
        val label = when (state) {
            ConversationState.LISTENING_SOURCE ->
                "Klausās: $activeSourceLang -> runā latviski$extra"
            ConversationState.LISTENING_USER ->
                "Klausās TEVI latviski -> runā angliski$extra"
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(label))
        broadcastState(label, "", "")
    }

    private fun broadcastState(state: String?, lastText: String, lastTranslation: String) {
        val intent = Intent(ACTION_STATE_UPDATE).apply {
            setPackage(packageName)
            state?.let { putExtra(EXTRA_STATE, it) }
            putExtra(EXTRA_LAST_TEXT, lastText)
            putExtra(EXTRA_LAST_TRANSLATION, lastTranslation)
        }
        sendBroadcast(intent)
    }

    private fun broadcastMicSource(label: String) {
        val intent = Intent(ACTION_STATE_UPDATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_MIC_SOURCE, label)
        }
        sendBroadcast(intent)
    }
}
