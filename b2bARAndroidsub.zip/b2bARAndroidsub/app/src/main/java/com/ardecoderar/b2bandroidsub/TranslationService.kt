package com.ardecoderar.b2bandroidsub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * b2bARAndroidsub — galvenais fona serviss.
 *
 * Audio ievade: dzirdes aparāta mikrofons — atbalsta gan LE Audio/HAP
 * (jaunākie modeļi), gan klasisko Bluetooth SCO/HFP (piem. Phonak Naída
 * Lumity L90-PR) — skat. BluetoothAudioRouter. Ja nekas nav pieejams,
 * telefona mikrofons kalpo kā rezerve.
 *
 * ASR: Vosk — bezmaksas, offline, tieši telefonā (bez API atslēgas).
 * MT: Google ML Kit Translation — bezmaksas, offline, tieši telefonā.
 * Izvade: Android TextToSpeech (plūst uz dzirdes aparātu automātiski,
 * ja tas savienots kā audio izvades ierīce).
 *
 * Stāvokļi ("punkts" pilnībā pārslēdz starp tiem):
 *  - LISTENING_SOURCE: klausās avota valodu (AUTOMĀTISKI noteikta starp visām
 *    lejupielādētajām Vosk valodām, ja config.autoDetectSourceLang=true) -> tulko -> runā LV
 *  - LISTENING_USER: klausās tevi (noklusēti EN) -> tulko -> VIENMĒR runā angliski
 *
 * Servisu var arī ieslēgt/izslēgt ar balss komandām "translator on" /
 * "translator off" — skat. HotwordListenerService, kas šo servisu palaiž/aptur.
 */
class TranslationService : Service() {

    companion object {
        const val CHANNEL_ID = "b2b_translation_channel"
        const val NOTIF_ID = 1
        const val ACTION_STATE_UPDATE = "com.ardecoderar.b2bandroidsub.STATE_UPDATE"
        const val EXTRA_STATE = "state"
        const val EXTRA_LAST_TEXT = "last_text"
        const val EXTRA_LAST_TRANSLATION = "last_translation"
        const val EXTRA_MIC_SOURCE = "mic_source"

        // ~1.8 sekundes PCM16 16kHz audio parauga valodas detekcijai
        private const val DETECTION_SAMPLE_BYTES = (AudioCapture.SAMPLE_RATE * 2 * 1.8).toInt()
    }

    private lateinit var config: ConfigManager
    private lateinit var translator: MLKitTranslator
    private lateinit var micRouter: BluetoothAudioRouter
    private lateinit var languageDetector: LanguageDetector
    private lateinit var mmsClient: MetaMmsAsrClient
    private lateinit var nllbClient: NllbTranslatorClient

    private var audioCapture: AudioCapture? = null
    private var asrClient: VoskAsrClient? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var state = ConversationState.LISTENING_SOURCE
    private var isRunning = false
    @Volatile private var usingClassicSco = false
    // Faktiski konstatētā/izmantotā avota valoda šajā klausīšanās sesijā
    @Volatile private var activeSourceLang: String = "de"
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        config = ConfigManager(this)
        translator = MLKitTranslator()
        micRouter = BluetoothAudioRouter(this)
        languageDetector = LanguageDetector(config.voskModelsRootDir())
        mmsClient = MetaMmsAsrClient(config.mmsServerUrl, config.mmsApiKey)
        nllbClient = NllbTranslatorClient(config.mmsServerUrl, config.mmsApiKey)
        activeSourceLang = config.sourceLang
        createNotificationChannel()
        setupTts()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val leAudioDevice = micRouter.findHearingAidInputDevice()
        var micLabel: String

        if (leAudioDevice != null) {
            usingClassicSco = false
            micLabel = micRouter.describeDevice(leAudioDevice)
        } else if (micRouter.hasClassicBluetoothHeadset()) {
            usingClassicSco = micRouter.startClassicScoAndWait()
            micLabel = if (usingClassicSco) {
                micRouter.describeDevice(null)
            } else {
                "Telefona mikrofons (SCO savienojums neizdevās)"
            }
        } else {
            usingClassicSco = false
            micLabel = "Telefona mikrofons (dzirdes aparāta mikrofons nav pieejams)"
        }

        startForeground(NOTIF_ID, buildNotification("Klausās ($micLabel)"))

        if (!isRunning) {
            isRunning = true
            state = ConversationState.LISTENING_SOURCE
            broadcastMicSource(micLabel)
            startPipelineForCurrentState()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        audioCapture?.stop()
        asrClient?.close()
        translator.close()
        micRouter.release()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    // ─────────────────────────────────────────────
    // Pipeline: mikrofons -> Vosk -> (punkts pārbaude / tulkošana)
    // ─────────────────────────────────────────────

    private fun startPipelineForCurrentState() {
        audioCapture?.stop()
        asrClient?.close()

        if (state == ConversationState.LISTENING_SOURCE && config.customSourceLangCode.isNotBlank() && config.isMmsConfigured()) {
            // Pielāgota valoda ārpus standarta 13 — iet caur Meta MMS serveri.
            activeSourceLang = config.customSourceLangCode
            startMmsPipeline(activeSourceLang)
        } else if (state == ConversationState.LISTENING_SOURCE && config.autoDetectSourceLang) {
            runDetectionThenListen()
        } else {
            val langCode = when (state) {
                ConversationState.LISTENING_SOURCE -> config.sourceLang
                ConversationState.LISTENING_USER -> "en"
            }
            activeSourceLang = langCode
            startAsrPipeline(langCode)
        }
    }

    /**
     * MMS servera pipeline (skat. MetaMmsAsrClient) — izmanto FIKSĒTA LOGA
     * pieeju (~3 sek. fragmenti), nevis Vosk straumēšanu, jo MMS strādā ar
     * pilniem audio fragmentiem, ne straumi. Katrs fragments tiek nosūtīts
     * serverim un rezultāts apstrādāts kā "final" teksts.
     */
    private fun startMmsPipeline(langCode: String) {
        if (!isRunning) return
        if (!mmsClient.isServerReachable()) {
            updateStatusLabel(extra = " — MMS serveris nav sasniedzams ($langCode)")
        }

        val windowBytes = AudioCapture.SAMPLE_RATE * 2 * 3 // ~3 sekundes PCM16
        val buffer = java.io.ByteArrayOutputStream()

        val device = micRouter.findHearingAidInputDevice()
        audioCapture = AudioCapture(device, usingClassicSco) { bytes ->
            synchronized(buffer) {
                buffer.write(bytes)
                if (buffer.size() >= windowBytes) {
                    val chunk = buffer.toByteArray()
                    buffer.reset()
                    CoroutineScope(Dispatchers.IO).launch {
                        val text = mmsClient.recognize(chunk, langCode)
                        if (text.isNotBlank()) {
                            mainHandler.post { handleFinal(text) }
                        }
                    }
                }
            }
        }
        audioCapture?.start()
        updateStatusLabel()
    }

    /**
     * Ievāc īsu (~1.8s) audio paraugu, palaiž to caur visiem lejupielādētajiem
     * Vosk modeļiem (LanguageDetector), un tad turpina klausīšanos ar
     * atpazīto valodu. Ja detekcija neizdodas (nav modeļu vai klusums),
     * izmanto config.sourceLang kā rezervi.
     */
    private fun runDetectionThenListen() {
        updateStatusLabel(extra = " — nosaka valodu...")

        val candidates = config.availableVoskLanguages()
        if (candidates.isEmpty()) {
            activeSourceLang = config.sourceLang
            startAsrPipeline(activeSourceLang)
            return
        }

        val sampleBuffer = java.io.ByteArrayOutputStream()
        var sampleCapture: AudioCapture? = null
        val device = micRouter.findHearingAidInputDevice()

        sampleCapture = AudioCapture(device, usingClassicSco) { bytes ->
            synchronized(sampleBuffer) {
                if (sampleBuffer.size() < DETECTION_SAMPLE_BYTES) {
                    sampleBuffer.write(bytes)
                }
                if (sampleBuffer.size() >= DETECTION_SAMPLE_BYTES) {
                    sampleCapture?.stop()
                    val sample = sampleBuffer.toByteArray()
                    CoroutineScope(Dispatchers.Default).launch {
                        val result = languageDetector.detect(candidates, sample)
                        activeSourceLang = result?.langCode ?: config.sourceLang
                        mainHandler.post { startAsrPipeline(activeSourceLang) }
                    }
                }
            }
        }
        audioCapture = sampleCapture
        sampleCapture.start()
    }

    private fun startAsrPipeline(langCode: String) {
        if (!isRunning) return

        val modelDir = config.voskModelDirFor(langCode)
        if (!config.isVoskModelAvailable(langCode)) {
            updateStatusLabel(extra = " — TRŪKST Vosk modeļa priekš '$langCode' (skat. README)")
            return
        }

        asrClient = VoskAsrClient(
            modelDir = modelDir,
            onInterim = { text -> handleInterim(text) },
            onFinal = { text -> handleFinal(text) },
            onError = { /* klusi turpina; nākamais audio chunk mēģinās vēlreiz */ }
        )
        asrClient?.connect()

        val device = micRouter.findHearingAidInputDevice()
        audioCapture = AudioCapture(device, usingClassicSco) { bytes ->
            asrClient?.sendAudio(bytes)
        }
        audioCapture?.start()

        updateStatusLabel()
    }

    private fun handleInterim(text: String) {
        if (containsWakeWord(text)) {
            performSwitch(text)
        }
    }

    private fun handleFinal(text: String) {
        if (text.isBlank()) return
        if (containsWakeWord(text)) {
            performSwitch(text)
            return
        }
        translateAndSpeak(text)
    }

    // ─────────────────────────────────────────────
    // "Punkts" apstrāde un stāvokļu pārslēgšana
    // ─────────────────────────────────────────────

    private fun containsWakeWord(text: String): Boolean {
        val word = config.wakeWord.trim()
        if (word.isEmpty()) return false
        return text.trim().lowercase(Locale.getDefault())
            .contains(word.lowercase(Locale.getDefault()))
    }

    private fun stripWakeWord(text: String): String {
        val word = config.wakeWord.trim()
        if (word.isEmpty()) return text
        return text.replace(Regex("(?i)${Regex.escape(word)}"), "").trim()
    }

    @Volatile private var switching = false

    private fun performSwitch(rawText: String) {
        if (switching) return
        switching = true

        val before = stripWakeWord(rawText)

        if (state == ConversationState.LISTENING_USER && before.isNotBlank()) {
            translateAndSpeak(before)
        }

        state = when (state) {
            ConversationState.LISTENING_SOURCE -> ConversationState.LISTENING_USER
            ConversationState.LISTENING_USER -> ConversationState.LISTENING_SOURCE
        }

        mainHandler.post {
            startPipelineForCurrentState()
            switching = false
        }
    }

    // ─────────────────────────────────────────────
    // Tulkošana un runa
    // ─────────────────────────────────────────────

    private fun translateAndSpeak(text: String) {
        val (srcLang, outLang) = when (state) {
            ConversationState.LISTENING_SOURCE -> activeSourceLang to config.targetLang
            ConversationState.LISTENING_USER -> "en" to config.replyOutputLang
        }
        CoroutineScope(Dispatchers.IO).launch {
            val translated = if (translator.supports(srcLang) && translator.supports(outLang)) {
                translator.translate(text, srcLang, outLang)
            } else {
                // Kāda no valodām ir ārpus ML Kit standarta 13 — izmanto
                // Meta NLLB serveri (ja konfigurēts), citādi atgriež oriģinālu.
                nllbClient.translate(text, srcLang, outLang)
            }
            mainHandler.post {
                speak(translated, outLang)
                broadcastState(null, text, translated)
            }
        }
    }

    private fun setupTts() {
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {}
                override fun onError(utteranceId: String?) {}
            })
        }
    }

    private fun speak(text: String, langCode: String) {
        if (!ttsReady || text.isBlank()) return
        val locale = when (langCode.lowercase()) {
            "lv" -> Locale("lv", "LV")
            "ru" -> Locale("ru", "RU")
            "en" -> Locale.US
            "lt" -> Locale("lt", "LT")
            "et" -> Locale("et", "EE")
            "de" -> Locale.GERMAN
            "fi" -> Locale("fi", "FI")
            "sv" -> Locale("sv", "SE")
            "no" -> Locale("no", "NO")
            "fr" -> Locale.FRENCH
            "es" -> Locale("es", "ES")
            "it" -> Locale.ITALIAN
            "pl" -> Locale("pl", "PL")
            else -> Locale.US
        }
        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            return
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "b2b_utterance")
    }

    // ─────────────────────────────────────────────
    // Paziņojumi (foreground service)
    // ─────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "b2bARAndroidsub tulkošana",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("b2bARAndroidsub")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    private fun updateStatusLabel(extra: String = "") {
        val label = when (state) {
            ConversationState.LISTENING_SOURCE ->
                "Klausās: $activeSourceLang -> runā ${config.targetLang}$extra"
            ConversationState.LISTENING_USER ->
                "Klausās tevi -> runās angliski$extra"
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(label))
        broadcastState(label, "", "")
    }

    private fun broadcastState(state: String?, lastText: String, lastTranslation: String) {
        val intent = Intent(ACTION_STATE_UPDATE).apply {
            setPackage(packageName)
            state?.let { putExtra(EXTRA_STATE, it) }
            putExtra(EXTRA_LAST_TEXT, lastText)
            putExtra(EXTRA_LAST_TRANSLATION, lastTranslation)
        }
        sendBroadcast(intent)
    }

    private fun broadcastMicSource(label: String) {
        val intent = Intent(ACTION_STATE_UPDATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_MIC_SOURCE, label)
        }
        sendBroadcast(intent)
    }
}
