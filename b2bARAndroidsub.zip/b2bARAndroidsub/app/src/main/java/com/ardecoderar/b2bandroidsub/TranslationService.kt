package com.ardecoderar.b2bandroidsub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * b2bARAndroidsub — galvenais fona serviss.
 *
 * Audio ievade (avota pusei): dzirdes aparāta mikrofons — atbalsta gan
 * LE Audio/HAP, gan klasisko Bluetooth SCO/HFP (piem. Phonak Naída
 * Lumity L90-PR) — skat. BluetoothAudioRouter. Ja nekas nav pieejams,
 * telefona mikrofons kalpo kā rezerve.
 *
 * ASR (avota pusei): Vosk — bezmaksas, offline, tieši telefonā.
 * ASR (lietotāja atbildēm latviski): Android/Google runas atpazīšana —
 *   izmantota TIKAI šai daļai, jo Vosk latviešu valodu neatbalsta.
 * MT: Google ML Kit Translation (bezmaksas, offline) + Meta NLLB serveris
 *   (rezervei retākām valodām, ja konfigurēts).
 * Izvade: Android TextToSpeech (plūst uz dzirdes aparātu automātiski).
 *
 * DIVVIRZIENU SARUNA, "stop" pārslēdz:
 *  - LISTENING_SOURCE: klausās otru pusi (auto-noteikta valoda) -> tulko -> runā LV
 *  - LISTENING_USER: klausās TEVI latviski -> tulko -> runā EN (otrai pusei)
 *
 * Servisu var arī ieslēgt/izslēgt ar balss komandām "translator on" /
 * "translator off" — skat. HotwordListenerService.
 */
class TranslationService : Service() {

    companion object {
        const val CHANNEL_ID = "b2b_translation_channel"
        const val NOTIF_ID = 1
        const val ACTION_STATE_UPDATE = "com.ardecoderar.b2bandroidsub.STATE_UPDATE"
        const val EXTRA_STATE = "state"
        const val EXTRA_LAST_TEXT = "last_text"
        const val EXTRA_LAST_TRANSLATION = "last_translation"
        const val EXTRA_MIC_SOURCE = "mic_source"

        // ~1.8 sekundes PCM16 16kHz audio parauga valodas detekcijai
        private const val DETECTION_SAMPLE_BYTES = (AudioCapture.SAMPLE_RATE * 2 * 1.8).toInt()
    }

    private lateinit var config: ConfigManager
    private lateinit var translator: MLKitTranslator
    private lateinit var micRouter: BluetoothAudioRouter
    private lateinit var languageDetector: LanguageDetector
    private lateinit var mmsClient: MetaMmsAsrClient
    private lateinit var nllbClient: NllbTranslatorClient

    private var audioCapture: AudioCapture? = null
    private var asrClient: VoskAsrClient? = null
    private var userReplyRecognizer: UserReplyRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wakeLock: PowerManager.WakeLock? = null

    private var state = ConversationState.LISTENING_SOURCE
    private var isRunning = false
    @Volatile private var usingClassicSco = false
    // Faktiski konstatētā/izmantotā avota valoda šajā klausīšanās sesijā
    @Volatile private var activeSourceLang: String = "de"
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        config = ConfigManager(this)
        translator = MLKitTranslator()
        micRouter = BluetoothAudioRouter(this)
        languageDetector = LanguageDetector(config.voskModelsRootDir())
        mmsClient = MetaMmsAsrClient(config.mmsServerUrl, config.mmsApiKey)
        nllbClient = NllbTranslatorClient(config.mmsServerUrl, config.mmsApiKey)
        activeSourceLang = config.sourceLang
        createNotificationChannel()
        setupTts()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val leAudioDevice = micRouter.findHearingAidInputDevice()
        var micLabel: String

        if (leAudioDevice != null) {
            usingClassicSco = false
            micLabel = micRouter.describeDevice(leAudioDevice)
        } else if (micRouter.hasClassicBluetoothHeadset()) {
            usingClassicSco = micRouter.startClassicScoAndWait()
            micLabel = if (usingClassicSco) {
                micRouter.describeDevice(null)
            } else {
                "Telefona mikrofons (SCO savienojums neizdevās)"
            }
        } else {
            usingClassicSco = false
            micLabel = "Telefona mikrofons (dzirdes aparāta mikrofons nav pieejams)"
        }

        startForeground(NOTIF_ID, buildNotification("Klausās ($micLabel)"))

        if (wakeLock == null) {
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "b2bARAndroidsub::TranslationWakeLock"
            ).apply {
                setReferenceCounted(false)
                acquire(12 * 60 * 60 * 1000L)
            }
        }

        if (!isRunning) {
            isRunning = true
            state = ConversationState.LISTENING_SOURCE
            broadcastMicSource(micLabel)
            startPipelineForCurrentState()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        audioCapture?.stop()
        asrClient?.close()
        userReplyRecognizer?.stop()
        translator.close()
        micRouter.release()
        tts?.stop()
        tts?.shutdown()
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }

    // ─────────────────────────────────────────────
    // Pipeline: mikrofons -> ASR -> ("stop" pārbaude / tulkošana)
    // ─────────────────────────────────────────────

    private fun startPipelineForCurrentState() {
        audioCapture?.stop()
        asrClient?.close()
        userReplyRecognizer?.stop()

        when (state) {
            ConversationState.LISTENING_USER -> startUserReplyPipeline()
            ConversationState.LISTENING_SOURCE -> {
                if (config.customSourceLangCode.isNotBlank() && config.isMmsConfigured()) {
                    activeSourceLang = config.customSourceLangCode
                    startMmsPipeline(activeSourceLang)
                } else if (config.autoDetectSourceLang) {
                    runDetectionThenListen()
                } else {
                    activeSourceLang = config.sourceLang
                    startAsrPipeline(activeSourceLang)
                }
            }
        }
        updateStatusLabel()
    }

    /**
     * Klausās PAŠU LIETOTĀJU latviski (Android/Google runas atpazīšana,
     * jo Vosk latviešu valodu neatbalsta). Kad dzird "stop", pārslēdzas
     * atpakaļ uz LISTENING_SOURCE.
     */
    private fun startUserReplyPipeline() {
        if (!isRunning) return
        // Piespiež sistēmas runas atpazīšanai izmantot dzirdes aparāta
        // mikrofonu (nevis telefona iebūvēto) — tāpat kā jebkuras bezvadu
        // austiņas jebkurā citā app.
        micRouter.forcePreferredCommunicationDeviceToHearingAid()
        userReplyRecognizer = UserReplyRecognizer(this) { text ->
            mainHandler.post { handleUserReplyResult(text) }
        }
        userReplyRecognizer?.start()
    }

    private fun handleUserReplyResult(text: String) {
        if (containsWakeWord(text)) {
            val before = stripWakeWord(text)
            if (before.isNotBlank()) {
                translateUserReplyAndSpeak(before)
            }
            performSwitch()
        } else if (text.isNotBlank()) {
            translateUserReplyAndSpeak(text)
        }
    }

    private fun translateUserReplyAndSpeak(text: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val translated = translator.translate(text, "lv", "en")
            mainHandler.post {
                speak(translated, "en")
                broadcastState(null, text, translated)
            }
        }
    }

    /**
     * MMS servera pipeline (skat. MetaMmsAsrClient) — izmanto FIKSĒTA LOGA
     * pieeju (~3 sek. fragmenti), nevis Vosk straumēšanu.
     */
    private fun startMmsPipeline(langCode: String) {
        if (!isRunning || state != ConversationState.LISTENING_SOURCE) return
        if (!mmsClient.isServerReachable()) {
            updateStatusLabel(extra = " — MMS serveris nav sasniedzams ($langCode)")
        }

        val windowBytes = AudioCapture.SAMPLE_RATE * 2 * 3
        val buffer = java.io.ByteArrayOutputStream()

        val device = micRouter.findHearingAidInputDevice()
        audioCapture = AudioCapture(device, usingClassicSco) { bytes ->
            synchronized(buffer) {
                buffer.write(bytes)
                if (buffer.size() >= windowBytes) {
                    val chunk = buffer.toByteArray()
                    buffer.reset()
                    CoroutineScope(Dispatchers.IO).launch {
                        val text = mmsClient.recognize(chunk, langCode)
                        if (text.isNotBlank()) {
                            mainHandler.post { handleFinal(text) }
                        }
                    }
                }
            }
        }
        audioCapture?.start()
    }

    /**
     * Ievāc īsu (~1.8s) audio paraugu, palaiž to caur visiem lejupielādētajiem
     * Vosk modeļiem (LanguageDetector), un tad turpina klausīšanos ar
     * atpazīto valodu.
     */
    private fun runDetectionThenListen() {
        updateStatusLabel(extra = " — nosaka valodu...")

        val candidates = config.availableVoskLanguages()
        if (candidates.isEmpty()) {
            activeSourceLang = config.sourceLang
            startAsrPipeline(activeSourceLang)
            return
        }

        val sampleBuffer = java.io.ByteArrayOutputStream()
        var sampleCapture: AudioCapture? = null
        val device = micRouter.findHearingAidInputDevice()

        sampleCapture = AudioCapture(device, usingClassicSco) { bytes ->
            synchronized(sampleBuffer) {
                if (sampleBuffer.size() < DETECTION_SAMPLE_BYTES) {
                    sampleBuffer.write(bytes)
                }
                if (sampleBuffer.size() >= DETECTION_SAMPLE_BYTES) {
                    sampleCapture?.stop()
                    val sample = sampleBuffer.toByteArray()
                    CoroutineScope(Dispatchers.Default).launch {
                        val result = languageDetector.detect(candidates, sample)
                        activeSourceLang = result?.langCode ?: config.sourceLang
                        mainHandler.post {
                            if (state == ConversationState.LISTENING_SOURCE) startAsrPipeline(activeSourceLang)
                        }
                    }
                }
            }
        }
        audioCapture = sampleCapture
        sampleCapture.start()
    }

    private fun startAsrPipeline(langCode: String) {
        if (!isRunning || state != ConversationState.LISTENING_SOURCE) return

        val modelDir = config.voskModelDirFor(langCode)
        if (!config.isVoskModelAvailable(langCode)) {
            updateStatusLabel(extra = " — TRŪKST Vosk modeļa priekš '$langCode'")
            return
        }

        asrClient = VoskAsrClient(
            modelDir = modelDir,
            onInterim = { text -> handleInterim(text) },
            onFinal = { text -> handleFinal(text) },
            onError = { /* klusi turpina */ }
        )
        asrClient?.connect()

        val device = micRouter.findHearingAidInputDevice()
        audioCapture = AudioCapture(device, usingClassicSco) { bytes ->
            asrClient?.sendAudio(bytes)
        }
        audioCapture?.start()
    }

    private fun handleInterim(text: String) {
        if (containsWakeWord(text)) {
            performSwitch()
        }
    }

    private fun handleFinal(text: String) {
        if (text.isBlank()) return
        if (containsWakeWord(text)) {
            performSwitch()
            return
        }
        translateAndSpeak(text)
    }

    // ─────────────────────────────────────────────
    // "Stop" apstrāde
    // ─────────────────────────────────────────────

    private fun containsWakeWord(text: String): Boolean {
        val word = config.wakeWord.trim()
        if (word.isEmpty()) return false
        return text.trim().lowercase(Locale.getDefault())
            .contains(word.lowercase(Locale.getDefault()))
    }

    private fun stripWakeWord(text: String): String {
        val word = config.wakeWord.trim()
        if (word.isEmpty()) return text
        return text.replace(Regex("(?i)${Regex.escape(word)}"), "").trim()
    }

    @Volatile private var switching = false

    /** "stop" pasaukts -> pilnībā pārslēdz LISTENING_SOURCE <-> LISTENING_USER. */
    private fun performSwitch() {
        if (switching) return
        switching = true

        state = when (state) {
            ConversationState.LISTENING_SOURCE -> ConversationState.LISTENING_USER
            ConversationState.LISTENING_USER -> ConversationState.LISTENING_SOURCE
        }

        mainHandler.post {
            startPipelineForCurrentState()
            switching = false
        }
    }

    // ─────────────────────────────────────────────
    // Tulkošana un runa (avota puse -> vienmēr latviski)
    // ─────────────────────────────────────────────

    private fun translateAndSpeak(text: String) {
        val srcLang = activeSourceLang
        val outLang = "lv"
        CoroutineScope(Dispatchers.IO).launch {
            val translated = if (translator.supports(srcLang) && translator.supports(outLang)) {
                translator.translate(text, srcLang, outLang)
            } else {
                nllbClient.translate(text, srcLang, outLang)
            }
            mainHandler.post {
                speak(translated, outLang)
                broadcastState(null, text, translated)
            }
        }
    }

    private fun setupTts() {
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {}
                override fun onError(utteranceId: String?) {}
            })
        }
    }

    private fun speak(text: String, langCode: String) {
        if (!ttsReady || text.isBlank()) return
        val locale = when (langCode.lowercase()) {
            "lv" -> Locale("lv", "LV")
            "ru" -> Locale("ru", "RU")
            "en" -> Locale.US
            "lt" -> Locale("lt", "LT")
            "et" -> Locale("et", "EE")
            "de" -> Locale.GERMAN
            "fi" -> Locale("fi", "FI")
            "sv" -> Locale("sv", "SE")
            "no" -> Locale("no", "NO")
            "fr" -> Locale.FRENCH
            "es" -> Locale("es", "ES")
            "it" -> Locale.ITALIAN
            "pl" -> Locale("pl", "PL")
            else -> Locale.US
        }
        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            return
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "b2b_utterance")
    }

    // ─────────────────────────────────────────────
    // Paziņojumi (foreground service)
    // ─────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "b2bARAndroidsub tulkošana",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("b2bARAndroidsub")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    private fun updateStatusLabel(extra: String = "") {
        val label = when (state) {
            ConversationState.LISTENING_SOURCE ->
                "Klausās: $activeSourceLang -> runā latviski$extra"
            ConversationState.LISTENING_USER ->
                "Klausās TEVI latviski -> runā angliski$extra"
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(label))
        broadcastState(label, "", "")
    }

    private fun broadcastState(state: String?, lastText: String, lastTranslation: String) {
        val intent = Intent(ACTION_STATE_UPDATE).apply {
            setPackage(packageName)
            state?.let { putExtra(EXTRA_STATE, it) }
            putExtra(EXTRA_LAST_TEXT, lastText)
            putExtra(EXTRA_LAST_TRANSLATION, lastTranslation)
        }
        sendBroadcast(intent)
    }

    private fun broadcastMicSource(label: String) {
        val intent = Intent(ACTION_STATE_UPDATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_MIC_SOURCE, label)
        }
        sendBroadcast(intent)
    }
}
