package com.ardecoderar.b2bandroidsub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Atsevišķs, mazs serviss TIKAI citu app (YouTube, TikTok, Instagram u.c.)
 * skaņas uztveršanai. Apzināti NODALĪTS no TranslationService — lai šī
 * papildu (izvēles) funkcija nekad nevarētu ietekmēt pamata mikrofona
 * klausīšanos, pat ja rodas kāda problēma ar MediaProjection atļauju.
 */
class AppAudioCaptureService : Service() {

    companion object {
        const val CHANNEL_ID = "b2b_app_audio_channel"
        const val NOTIF_ID = 3
    }

    private lateinit var config: ConfigManager
    private lateinit var translator: MLKitTranslator
    private var appAudioCapture: AppAudioCapture? = null
    private var appAudioAsrClient: VoskAsrClient? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        config = ConfigManager(this)
        translator = MLKitTranslator()
        createNotificationChannel()
        tts = TextToSpeech(this) { status -> ttsReady = status == TextToSpeech.SUCCESS }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification("Klausās citu app skaņu..."))

        // Vienmēr VISPIRMS aizver iepriekšējos objektus (ja serviss tiek
        // palaists atkārtoti) — citādi vecais AudioRecord/VoskAsrClient
        // paliktu aktīvs paralēli jaunajam, radot resursu konfliktu.
        appAudioCapture?.stop()
        appAudioAsrClient?.close()
        appAudioCapture = null
        appAudioAsrClient = null

        val code = AppAudioCaptureHolder.resultCode
        val data = AppAudioCaptureHolder.resultData
        if (code == null || data == null) {
            updateNotification("Nav piešķirta atļauja — mēģini vēlreiz no galvenā ekrāna")
            return START_NOT_STICKY
        }
        if (!config.isVoskModelAvailable("en")) {
            updateNotification("TRŪKST angļu Vosk modeļa")
            return START_NOT_STICKY
        }

        appAudioAsrClient = VoskAsrClient(
            modelDir = config.voskModelDirFor("en"),
            onInterim = { },
            onFinal = { text -> if (text.isNotBlank()) mainHandler.post { translateAndSpeak(text) } },
            onError = { }
        )
        appAudioAsrClient?.connect()

        appAudioCapture = AppAudioCapture(this, code, data) { bytes ->
            appAudioAsrClient?.sendAudio(bytes)
        }
        val started = appAudioCapture?.start() ?: false
        if (!started) {
            updateNotification("Neizdevās sākt — šī app var bloķēt skaņas uztveršanu")
        }

        return START_STICKY
    }

    private fun translateAndSpeak(text: String) {
        CoroutineScope(Dispatchers.IO).launch {
            translator.ensureModelDownloaded("en", "lv", wifiOnly = false)
            val translated = translator.translate(text, "en", "lv")
            mainHandler.post {
                if (ttsReady) {
                    tts?.setLanguage(Locale("lv", "LV"))
                    tts?.speak(translated, TextToSpeech.QUEUE_FLUSH, null, "app_audio_utterance")
                }
                updateNotification("Dzirdēts: $text\nTulkots: $translated")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        appAudioCapture?.stop()
        appAudioAsrClient?.close()
        translator.close()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "b2bARAndroidsub — citu app skaņa", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("b2bARAndroidsub — app skaņa")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }
}
