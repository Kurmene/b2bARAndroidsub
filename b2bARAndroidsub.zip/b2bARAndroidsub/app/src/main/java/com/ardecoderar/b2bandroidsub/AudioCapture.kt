package com.ardecoderar.b2bandroidsub

import android.annotation.SuppressLint
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Nepārtraukti ieraksta 16kHz mono PCM16 audio no norādītās ievades ierīces
 * (dzirdes aparāta mikrofona, ja pieejams — citādi telefona mikrofona) un
 * caur [onAudioChunk] sūta to tālāk (Deepgram straumēšanai).
 */
class AudioCapture(
    private val preferredDevice: AudioDeviceInfo?,
    private val useClassicBluetoothSco: Boolean = false,
    private val onAudioChunk: (ByteArray) -> Unit
) {
    companion object {
        const val SAMPLE_RATE = 16000
    }

    private var audioRecord: AudioRecord? = null
    private var captureJob: Job? = null
    @Volatile private var isCapturing = false

    @SuppressLint("MissingPermission")
    fun start() {
        if (isCapturing) return

        val minBufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = maxOf(minBufferSize, SAMPLE_RATE / 2) // ~0.5s buferis minimums

        // VOICE_COMMUNICATION avots pareizi seko aktīvajam Bluetooth SCO
        // maršrutam (klasiskais handsfree, piem. Phonak Naída Lumity).
        // VOICE_RECOGNITION avots to bieži ignorē un paliek pie telefona mikrofona.
        val audioSource = if (useClassicBluetoothSco) {
            MediaRecorder.AudioSource.VOICE_COMMUNICATION
        } else {
            MediaRecorder.AudioSource.VOICE_RECOGNITION
        }

        val record = AudioRecord(
            audioSource,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        preferredDevice?.let { record.setPreferredDevice(it) }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            return
        }

        audioRecord = record
        isCapturing = true
        record.startRecording()

        captureJob = CoroutineScope(Dispatchers.IO).launch {
            val chunkSize = SAMPLE_RATE / 5 // ~200ms fragmenti straumēšanai
            val buffer = ShortArray(chunkSize)
            while (isCapturing) {
                val read = record.read(buffer, 0, chunkSize)
                if (read > 0) {
                    val bytes = ByteArray(read * 2)
                    for (i in 0 until read) {
                        val sample = buffer[i].toInt()
                        bytes[i * 2] = (sample and 0xFF).toByte()
                        bytes[i * 2 + 1] = ((sample shr 8) and 0xFF).toByte()
                    }
                    onAudioChunk(bytes)
                }
            }
        }
    }

    fun stop() {
        isCapturing = false
        captureJob?.cancel()
        captureJob = null
        runCatching {
            audioRecord?.stop()
            audioRecord?.release()
        }
        audioRecord = null
    }
}
