package com.ardecoderar.b2bandroidsub

/**
 * Lietošanas instrukcijas visās 13 atbalstītajās valodās — iebūvētas
 * pašā lietotnē. Ekrāns automātiski izvēlas valodu pēc telefona sistēmas
 * valodas (nekas jāizvēlas manuāli), un soļi tiek rādīti pa vienam ar
 * "Tālāk" pogu.
 */
object HelpTexts {

    data class HelpContent(
        val title: String,
        val steps: List<String>,
        val nextLabel: String,
        val doneLabel: String
    )

    val content: Map<String, HelpContent> = mapOf(
        "lv" to HelpContent(
            title = "Kā lietot",
            steps = listOf(
                "Savieno savu dzirdes aparātu ar telefonu\n(Iestatījumi → Bluetooth).",
                "Atver lietotni un nospied\n\"Sākt klausīties\".",
                "Otra puse runā jebkurā valodā — lietotne\npati to nosaka un iztulko latviski.",
                "Pasaki vārdu \"stop\" — lietotne pārslēgsies\nuz TEVI. Runā latviski, un tas tiks pateikts angliski.",
                "Pasaki \"stop\" vēlreiz — lietotne atgriežas\npie otras puses klausīšanās un tulko latviski.\n\nTulkojums tiek atskaņots tieši tavā\ndzirdes aparātā."
            ),
            nextLabel = "Tālāk",
            doneLabel = "Sākt lietot"
        ),
        "en" to HelpContent(
            title = "How to use",
            steps = listOf(
                "Connect your hearing aid to the phone\n(Settings → Bluetooth).",
                "Open the app and tap\n\"Start listening\".",
                "The other person speaks any language —\nthe app detects it and translates into Latvian.",
                "Say the word \"stop\" — the app switches to\nYOU. Speak Latvian, and it will be said in English.",
                "Say \"stop\" again — the app goes back to\nlistening to the other person, translating into Latvian.\n\nThe translation is played directly\nthrough your hearing aid."
            ),
            nextLabel = "Next",
            doneLabel = "Get started"
        ),
        "de" to HelpContent(
            title = "Anleitung",
            steps = listOf(
                "Verbinde dein Hörgerät mit dem Telefon\n(Einstellungen → Bluetooth).",
                "Öffne die App und tippe auf\n\"Zuhören starten\".",
                "Die andere Person spricht in beliebiger Sprache —\ndie App erkennt sie und übersetzt ins Lettische.",
                "Sage \"stop\" — die App wechselt zu DIR.\nSprich Lettisch, es wird auf Englisch ausgegeben.",
                "Sage erneut \"stop\" — die App hört wieder\nder anderen Person zu und übersetzt ins Lettische.\n\nDie Übersetzung wird direkt über\ndein Hörgerät wiedergegeben."
            ),
            nextLabel = "Weiter",
            doneLabel = "Loslegen"
        ),
        "ru" to HelpContent(
            title = "Как использовать",
            steps = listOf(
                "Подключите слуховой аппарат к телефону\n(Настройки → Bluetooth).",
                "Откройте приложение и нажмите\n«Начать прослушивание».",
                "Собеседник говорит на любом языке —\nприложение определит его и переведёт на латышский.",
                "Скажите слово «стоп» — приложение переключится\nна ВАС. Говорите по-латышски, это прозвучит на английском.",
                "Скажите «стоп» ещё раз — приложение снова\nслушает собеседника и переводит на латышский.\n\nПеревод воспроизводится прямо\nчерез ваш слуховой аппарат."
            ),
            nextLabel = "Далее",
            doneLabel = "Начать"
        ),
        "lt" to HelpContent(
            title = "Kaip naudoti",
            steps = listOf(
                "Prijunkite klausos aparatą prie telefono\n(Nustatymai → Bluetooth).",
                "Atidarykite programėlę ir paspauskite\n„Pradėti klausytis“.",
                "Pašnekovas kalba bet kuria kalba — programėlė\nją atpažins ir išvers į latvių kalbą.",
                "Pasakykite žodį „stop“ — programėlė persijungs\nant JŪSŲ. Kalbėkite latviškai, tai bus pasakyta angliškai.",
                "Pasakykite „stop“ dar kartą — programėlė vėl\nklausosi pašnekovo ir verčia į latvių kalbą.\n\nVertimas atkuriamas tiesiai\nper jūsų klausos aparatą."
            ),
            nextLabel = "Toliau",
            doneLabel = "Pradėti"
        ),
        "et" to HelpContent(
            title = "Kasutamine",
            steps = listOf(
                "Ühenda oma kuuldeaparaat telefoniga\n(Seaded → Bluetooth).",
                "Ava rakendus ja vajuta\n\"Alusta kuulamist\".",
                "Vestluskaaslane räägib mis tahes keeles —\nrakendus tuvastab selle ja tõlgib läti keelde.",
                "Ütle sõna \"stop\" — rakendus lülitub SINU\npeale. Räägi läti keelt, see öeldakse inglise keeles.",
                "Ütle uuesti \"stop\" — rakendus kuulab jälle\nvestluskaaslast ja tõlgib läti keelde.\n\nTõlge esitatakse otse\nsinu kuuldeaparaadi kaudu."
            ),
            nextLabel = "Edasi",
            doneLabel = "Alusta"
        ),
        "fi" to HelpContent(
            title = "Käyttöohje",
            steps = listOf(
                "Yhdistä kuulolaitteesi puhelimeen\n(Asetukset → Bluetooth).",
                "Avaa sovellus ja napauta\n\"Aloita kuuntelu\".",
                "Keskustelukumppani puhuu mitä tahansa kieltä —\nsovellus tunnistaa sen ja kääntää latviaksi.",
                "Sano sana \"stop\" — sovellus vaihtaa SINUUN.\nPuhu latviaa, se sanotaan englanniksi.",
                "Sano \"stop\" uudelleen — sovellus kuuntelee\njälleen kumppania ja kääntää latviaksi.\n\nKäännös toistetaan suoraan\nkuulolaitteesi kautta."
            ),
            nextLabel = "Seuraava",
            doneLabel = "Aloita"
        ),
        "sv" to HelpContent(
            title = "Bruksanvisning",
            steps = listOf(
                "Anslut din hörapparat till telefonen\n(Inställningar → Bluetooth).",
                "Öppna appen och tryck på\n\"Starta lyssning\".",
                "Den andra personen talar vilket språk\nsom helst — appen känner av det och översätter till lettiska.",
                "Säg ordet \"stop\" — appen växlar till DIG.\nTala lettiska, det sägs på engelska.",
                "Säg \"stop\" igen — appen lyssnar igen på\nden andra personen och översätter till lettiska.\n\nÖversättningen spelas upp direkt\ngenom din hörapparat."
            ),
            nextLabel = "Nästa",
            doneLabel = "Kom igång"
        ),
        "no" to HelpContent(
            title = "Bruksanvisning",
            steps = listOf(
                "Koble høreapparatet til telefonen\n(Innstillinger → Bluetooth).",
                "Åpne appen og trykk på\n\"Start lytting\".",
                "Den andre personen snakker et hvilket som\nhelst språk — appen oppdager det og oversetter til latvisk.",
                "Si ordet \"stop\" — appen bytter til DEG.\nSnakk latvisk, det sies på engelsk.",
                "Si \"stop\" igjen — appen lytter igjen til\nden andre personen og oversetter til latvisk.\n\nOversettelsen spilles av direkte\ngjennom høreapparatet ditt."
            ),
            nextLabel = "Neste",
            doneLabel = "Kom i gang"
        ),
        "fr" to HelpContent(
            title = "Mode d'emploi",
            steps = listOf(
                "Connectez votre appareil auditif au téléphone\n(Paramètres → Bluetooth).",
                "Ouvrez l'application et appuyez sur\n« Démarrer l'écoute ».",
                "L'autre personne parle n'importe quelle langue —\nl'application la détecte et traduit en letton.",
                "Dites le mot « stop » — l'application passe\nà VOUS. Parlez letton, ce sera dit en anglais.",
                "Dites « stop » à nouveau — l'application\nécoute de nouveau l'autre personne et traduit en letton.\n\nLa traduction est diffusée directement\nvia votre appareil auditif."
            ),
            nextLabel = "Suivant",
            doneLabel = "Commencer"
        ),
        "es" to HelpContent(
            title = "Cómo usar",
            steps = listOf(
                "Conecta tu audífono al teléfono\n(Ajustes → Bluetooth).",
                "Abre la aplicación y toca\n\"Empezar a escuchar\".",
                "La otra persona habla en cualquier idioma —\nla aplicación lo detecta y traduce al letón.",
                "Di la palabra \"stop\" — la aplicación cambia\na TI. Habla en letón, se dirá en inglés.",
                "Di \"stop\" de nuevo — la aplicación vuelve a\nescuchar a la otra persona y traduce al letón.\n\nLa traducción se reproduce directamente\na través de tu audífono."
            ),
            nextLabel = "Siguiente",
            doneLabel = "Empezar"
        ),
        "it" to HelpContent(
            title = "Come si usa",
            steps = listOf(
                "Collega il tuo apparecchio acustico al telefono\n(Impostazioni → Bluetooth).",
                "Apri l'app e tocca\n\"Avvia ascolto\".",
                "L'altra persona parla in qualsiasi lingua —\nl'app la rileva e la traduce in lettone.",
                "Di' la parola \"stop\" — l'app passa a TE.\nParla in lettone, verrà detto in inglese.",
                "Di' di nuovo \"stop\" — l'app torna ad\nascoltare l'altra persona e traduce in lettone.\n\nLa traduzione viene riprodotta\ndirettamente tramite il tuo apparecchio acustico."
            ),
            nextLabel = "Avanti",
            doneLabel = "Inizia"
        ),
        "pl" to HelpContent(
            title = "Jak korzystać",
            steps = listOf(
                "Połącz aparat słuchowy z telefonem\n(Ustawienia → Bluetooth).",
                "Otwórz aplikację i naciśnij\n\"Rozpocznij słuchanie\".",
                "Rozmówca mówi w dowolnym języku —\naplikacja go rozpozna i przetłumaczy na łotewski.",
                "Powiedz słowo \"stop\" — aplikacja przełączy się\nna CIEBIE. Mów po łotewsku, zostanie to powiedziane po angielsku.",
                "Powiedz \"stop\" ponownie — aplikacja znów\nsłucha rozmówcy i tłumaczy na łotewski.\n\nTłumaczenie jest odtwarzane\nbezpośrednio przez aparat słuchowy."
            ),
            nextLabel = "Dalej",
            doneLabel = "Rozpocznij"
        )
    )

    /**
     * Izvēlas instrukciju valodu pēc telefona SISTĒMAS valodas — lietotājam
     * nekas nav jāizvēlas manuāli. Ja telefona valoda nav atbalstīta,
     * izmanto angļu kā rezervi (visplašāk saprotamā).
     */
    fun forDeviceLocale(deviceLangCode: String): HelpContent {
        return content[deviceLangCode.lowercase()] ?: content["en"]!!
    }
}
