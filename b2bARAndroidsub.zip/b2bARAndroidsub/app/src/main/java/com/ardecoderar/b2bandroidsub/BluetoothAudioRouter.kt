package com.ardecoderar.b2bandroidsub

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Atrod un savieno dzirdes aparāta mikrofona ievadi, izmantojot Android
 * standarta (zīmola-neatkarīgo) AudioManager API. Atbalsta DIVUS iespējamos
 * ceļus, jo dzirdes aparāti tos izmanto atkarībā no modeļa/paaudzes:
 *
 * 1. LE Audio / HAP (Hearing Aid Profile) — jaunākais standarts, ko izmanto
 *    daļa 2024-2026 gada modeļu (piem. Phonak Infinio). Parādās kā
 *    TYPE_BLE_HEADSET, maršrutējas automātiski caur setPreferredDevice().
 *
 * 2. Klasiskais Bluetooth SCO/HFP (Hands-Free Profile) — to izmanto Phonak
 *    Naída Lumity (arī L90-PR) un daudzi citi "universal Bluetooth" modeļi,
 *    KAS NEATBALSTA LE Audio. Šeit nepietiek ar ierīces atrašanu — audio
 *    maršruts jāaktivizē EKSPLICĪTI ar startBluetoothSco().
 */
class BluetoothAudioRouter(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var scoReceiverRegistered = false
    private var scoStateLatch: CountDownLatch? = null

    @Volatile var isScoActive = false
        private set

    private val scoReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            val state = intent?.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, -1) ?: return
            isScoActive = state == AudioManager.SCO_AUDIO_STATE_CONNECTED
            if (isScoActive || state == AudioManager.SCO_AUDIO_STATE_ERROR) {
                scoStateLatch?.countDown()
            }
        }
    }

    /**
     * Atgriež dzirdes aparāta ievades ierīci (LE Audio ceļš), ja tāda ir
     * pieejama un savienota, citādi null.
     */
    fun findHearingAidInputDevice(): AudioDeviceInfo? {
        val inputs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        inputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLE_HEADSET }?.let { return it }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            inputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLE_BROADCAST }?.let { return it }
        }
        return null
    }

    /**
     * Pārbauda, vai ir savienota klasiska Bluetooth handsfree ierīce
     * (piem. Phonak Naída Lumity) — šis ir ceļš, kas der TEV.
     */
    fun hasClassicBluetoothHeadset(): Boolean {
        val inputs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        return inputs.any { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
    }

    /**
     * Aktivizē klasisko Bluetooth SCO audio maršrutu (Naída Lumity un
     * līdzīgiem "universal Bluetooth" modeļiem). Jāsauc PIRMS AudioCapture
     * sākšanas. Atgriež true, ja savienojums izveidojies.
     */
    fun startClassicScoAndWait(timeoutMs: Long = 4000): Boolean {
        if (!scoReceiverRegistered) {
            context.registerReceiver(scoReceiver, IntentFilter(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED))
            scoReceiverRegistered = true
        }
        @Suppress("DEPRECATION")
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        scoStateLatch = CountDownLatch(1)
        @Suppress("DEPRECATION")
        audioManager.startBluetoothSco()
        @Suppress("DEPRECATION")
        audioManager.isBluetoothScoOn = true
        scoStateLatch?.await(timeoutMs, TimeUnit.MILLISECONDS)
        return isScoActive
    }

    fun stopClassicSco() {
        @Suppress("DEPRECATION")
        audioManager.isBluetoothScoOn = false
        @Suppress("DEPRECATION")
        audioManager.stopBluetoothSco()
        @Suppress("DEPRECATION")
        audioManager.mode = AudioManager.MODE_NORMAL
        isScoActive = false
    }

    fun release() {
        if (scoReceiverRegistered) {
            runCatching { context.unregisterReceiver(scoReceiver) }
            scoReceiverRegistered = false
        }
        stopClassicSco()
    }

    fun isHearingAidMicAvailable(): Boolean =
        findHearingAidInputDevice() != null || hasClassicBluetoothHeadset()

    fun describeDevice(device: AudioDeviceInfo?): String {
        if (device != null) {
            val name = device.productName?.toString() ?: "Dzirdes aparāts"
            return "$name (LE Audio mikrofons)"
        }
        if (isScoActive) return "Dzirdes aparāts (klasiskais Bluetooth handsfree)"
        return "Telefona mikrofons (dzirdes aparāta mikrofons nav pieejams)"
    }
}

