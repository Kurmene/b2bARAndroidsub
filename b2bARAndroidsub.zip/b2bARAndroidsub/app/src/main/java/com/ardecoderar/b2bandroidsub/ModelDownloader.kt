package com.ardecoderar.b2bandroidsub

import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * Automātiska Vosk modeļu lejupielāde un uzstādīšana — lai klientam
 * NEBŪTU jāiet uz interneta lapu, jāizpako zip un jāmeklē pareizā mape
 * failu pārvaldniekā. Viena pogas piespiešana lietotnē paveic visu.
 *
 * URL ir tieši no oficiālās Vosk lapas (https://alphacephei.com/vosk/models).
 * Ietverti tikai modeļi, kuru precīzu adresi esmu apstiprinājis — pārējām
 * valodām lietotājs joprojām var izmantot manuālo ceļu (skat. README).
 */
object ModelDownloader {

    private const val BASE = "https://alphacephei.com/vosk/models"

    val availableForAutoDownload: Map<String, String> = mapOf(
        // Angļu — izmanto VIDĒJA izmēra "lgraph" modeli (~128MB), nevis mazo
        // (~40MB), jo angļu valoda ir kritiski svarīga (atbildes, balss
        // komandas, hotword), un precizitātes uzlabojums to attaisno.
        "en" to "$BASE/vosk-model-en-us-0.22-lgraph.zip",
        "de" to "$BASE/vosk-model-small-de-0.15.zip",
        "ru" to "$BASE/vosk-model-small-ru-0.22.zip",
        "fr" to "$BASE/vosk-model-small-fr-0.22.zip",
        "es" to "$BASE/vosk-model-small-es-0.42.zip",
        "it" to "$BASE/vosk-model-small-it-0.22.zip",
        "pl" to "$BASE/vosk-model-small-pl-0.22.zip",
        "sv" to "$BASE/vosk-model-small-sv-rhasspy-0.15.zip"
    )

    // Pilnas, DAUDZ precīzākas alternatīvas (ievērojami lielākas — vairāki
    // simti MB līdz pat 1.8+ GB). Piedāvā TIKAI kā izvēles "augstas
    // precizitātes" opciju, ne noklusējumu, jo vairāku valodu vienlaicīga
    // automātiskā lejupielāde ar šiem izmēriem būtu pārāk smaga.
    val highAccuracyModels: Map<String, String> = mapOf(
        "en" to "$BASE/vosk-model-en-us-0.22.zip", // ~1.8 GB
        "de" to "$BASE/vosk-model-de-0.21.zip"       // ~1.9 GB
    )

    fun canAutoDownload(langCode: String): Boolean =
        availableForAutoDownload.containsKey(langCode.lowercase())

    /** Lejupielādē un uzstāda AUGSTAS PRECIZITĀTES modeli (izmanto to pašu mehānismu, kā parasto). */
    fun downloadHighAccuracy(langCode: String, destRootDir: java.io.File, onProgress: (Int) -> Unit): Boolean {
        val url = highAccuracyModels[langCode.lowercase()] ?: return false
        return downloadAndInstallFromUrl(langCode, url, destRootDir, onProgress)
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.MINUTES) // modeļi ir ~40-50MB, lēnākam tīklam vajag laiku
        .build()

    /**
     * Lejupielādē un uzstāda modeli. Atgriež true, ja izdevās.
     * onProgress: 0-100 (procenti), vai -1, ja izmērs nav zināms.
     */
    fun downloadAndInstall(
        langCode: String,
        destRootDir: File,
        onProgress: (Int) -> Unit
    ): Boolean {
        val url = availableForAutoDownload[langCode.lowercase()] ?: return false
        return downloadAndInstallFromUrl(langCode, url, destRootDir, onProgress)
    }

    fun downloadAndInstallFromUrl(
        langCode: String,
        url: String,
        destRootDir: File,
        onProgress: (Int) -> Unit
    ): Boolean {
        val destDir = File(destRootDir, langCode.lowercase())
        val tempZip = File(destRootDir, "_download_${langCode}.zip")
        val tempExtract = File(destRootDir, "_extract_${langCode}")

        return try {
            // 1. Lejupielāde
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return false
                val body = response.body ?: return false
                val totalBytes = body.contentLength()
                var downloaded = 0L

                FileOutputStream(tempZip).use { out ->
                    body.byteStream().use { input ->
                        val buffer = ByteArray(8192)
                        var read: Int
                        var lastReportedPercent = -2 // nodrošina, ka pirmais 0% arī tiek nosūtīts
                        while (input.read(buffer).also { read = it } != -1) {
                            out.write(buffer, 0, read)
                            downloaded += read
                            // SVARĪGI: atjaunina progresu TIKAI tad, kad procenti
                            // reāli mainās (ne katru 8KB porciju) — citādi lielam
                            // failam (~128MB) tas nozīmētu tūkstošiem UI
                            // atjauninājumu sekundē, kas applūdina galveno
                            // pavedienu un liek app šķist "sastingušai".
                            if (totalBytes > 0) {
                                val percent = (downloaded * 100 / totalBytes).toInt()
                                if (percent != lastReportedPercent) {
                                    lastReportedPercent = percent
                                    onProgress(percent)
                                }
                            } else if (downloaded % (256 * 1024) < 8192) {
                                onProgress(-1)
                            }
                        }
                    }
                }
            }

            // 2. Izpakošana
            if (tempExtract.exists()) tempExtract.deleteRecursively()
            tempExtract.mkdirs()
            unzip(tempZip, tempExtract)

            // 3. Vosk zip parasti satur VIENU apakšmapi (piem. "vosk-model-small-de-0.15/")
            //    — pārceļam TĀS saturu uz galīgo mērķa mapi.
            val innerDirs = tempExtract.listFiles { f -> f.isDirectory }
            val sourceDir = if (innerDirs != null && innerDirs.size == 1) innerDirs[0] else tempExtract

            if (destDir.exists()) destDir.deleteRecursively()
            destDir.mkdirs()
            sourceDir.copyRecursively(destDir, overwrite = true)

            // 4. Uzkopšana
            tempZip.delete()
            tempExtract.deleteRecursively()

            true
        } catch (e: Exception) {
            tempZip.delete()
            tempExtract.deleteRecursively()
            false
        }
    }

    private fun unzip(zipFile: File, targetDir: File) {
        ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(targetDir, entry.name)
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { out ->
                        val buffer = ByteArray(8192)
                        var read: Int
                        while (zis.read(buffer).also { read = it } != -1) {
                            out.write(buffer, 0, read)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
}
