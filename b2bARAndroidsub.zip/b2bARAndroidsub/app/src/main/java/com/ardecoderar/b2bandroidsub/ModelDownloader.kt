package com.ardecoderar.b2bandroidsub

import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * Automātiska Vosk modeļu lejupielāde un uzstādīšana — lai klientam
 * NEBŪTU jāiet uz interneta lapu, jāizpako zip un jāmeklē pareizā mape
 * failu pārvaldniekā. Viena pogas piespiešana lietotnē paveic visu.
 *
 * URL ir tieši no oficiālās Vosk lapas (https://alphacephei.com/vosk/models).
 * Ietverti tikai modeļi, kuru precīzu adresi esmu apstiprinājis — pārējām
 * valodām lietotājs joprojām var izmantot manuālo ceļu (skat. README).
 */
object ModelDownloader {

    private const val BASE = "https://alphacephei.com/vosk/models"

    val availableForAutoDownload: Map<String, String> = mapOf(
        "en" to "$BASE/vosk-model-small-en-us-0.15.zip",
        "de" to "$BASE/vosk-model-small-de-0.15.zip",
        "ru" to "$BASE/vosk-model-small-ru-0.22.zip",
        "fr" to "$BASE/vosk-model-small-fr-0.22.zip",
        "es" to "$BASE/vosk-model-small-es-0.42.zip",
        "it" to "$BASE/vosk-model-small-it-0.22.zip",
        "pl" to "$BASE/vosk-model-small-pl-0.22.zip",
        "sv" to "$BASE/vosk-model-small-sv-rhasspy-0.15.zip"
    )

    fun canAutoDownload(langCode: String): Boolean =
        availableForAutoDownload.containsKey(langCode.lowercase())

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.MINUTES) // modeļi ir ~40-50MB, lēnākam tīklam vajag laiku
        .build()

    /**
     * Lejupielādē un uzstāda modeli. Atgriež true, ja izdevās.
     * onProgress: 0-100 (procenti), vai -1, ja izmērs nav zināms.
     */
    fun downloadAndInstall(
        langCode: String,
        destRootDir: File,
        onProgress: (Int) -> Unit
    ): Boolean {
        val url = availableForAutoDownload[langCode.lowercase()] ?: return false
        val destDir = File(destRootDir, langCode.lowercase())
        val tempZip = File(destRootDir, "_download_${langCode}.zip")
        val tempExtract = File(destRootDir, "_extract_${langCode}")

        return try {
            // 1. Lejupielāde
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return false
                val body = response.body ?: return false
                val totalBytes = body.contentLength()
                var downloaded = 0L

                FileOutputStream(tempZip).use { out ->
                    body.byteStream().use { input ->
                        val buffer = ByteArray(8192)
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            out.write(buffer, 0, read)
                            downloaded += read
                            if (totalBytes > 0) {
                                onProgress((downloaded * 100 / totalBytes).toInt())
                            } else {
                                onProgress(-1)
                            }
                        }
                    }
                }
            }

            // 2. Izpakošana
            if (tempExtract.exists()) tempExtract.deleteRecursively()
            tempExtract.mkdirs()
            unzip(tempZip, tempExtract)

            // 3. Vosk zip parasti satur VIENU apakšmapi (piem. "vosk-model-small-de-0.15/")
            //    — pārceļam TĀS saturu uz galīgo mērķa mapi.
            val innerDirs = tempExtract.listFiles { f -> f.isDirectory }
            val sourceDir = if (innerDirs != null && innerDirs.size == 1) innerDirs[0] else tempExtract

            if (destDir.exists()) destDir.deleteRecursively()
            destDir.mkdirs()
            sourceDir.copyRecursively(destDir, overwrite = true)

            // 4. Uzkopšana
            tempZip.delete()
            tempExtract.deleteRecursively()

            true
        } catch (e: Exception) {
            tempZip.delete()
            tempExtract.deleteRecursively()
            false
        }
    }

    private fun unzip(zipFile: File, targetDir: File) {
        ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(targetDir, entry.name)
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { out ->
                        val buffer = ByteArray(8192)
                        var read: Int
                        while (zis.read(buffer).also { read = it } != -1) {
                            out.write(buffer, 0, read)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
}
