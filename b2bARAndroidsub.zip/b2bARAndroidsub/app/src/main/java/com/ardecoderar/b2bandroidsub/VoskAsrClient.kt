package com.ardecoderar.b2bandroidsub

import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.util.concurrent.Executors

/**
 * Bezmaksas offline runas atpazīšana (Vosk) — aizstāj Deepgram. Nav vajadzīga
 * API atslēga un nav vajadzīgs internets darbības laikā — viss notiek tieši
 * telefonā. VIENĪGAIS priekšnoteikums: valodas modelis jau jābūt
 * lejupielādētam un izpakotam telefonā (skat. README "Vosk modeļu uzstādīšana").
 *
 * Modeļi (bezmaksas): https://alphacephei.com/vosk/models
 */
class VoskAsrClient(
    private val modelDir: File,
    private val onInterim: (String) -> Unit,
    private val onFinal: (String) -> Unit,
    private val onError: (String) -> Unit
) {
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var ready = false

    /** Ielādē modeli fonā (var aizņemt 1-3 sekundes). */
    fun connect() {
        executor.execute {
            try {
                if (!modelDir.exists()) {
                    onError("Vosk modelis nav atrasts: ${modelDir.absolutePath}")
                    return@execute
                }
                model = Model(modelDir.absolutePath)
                recognizer = Recognizer(model, AudioCapture.SAMPLE_RATE.toFloat())
                ready = true
            } catch (e: Exception) {
                onError("Neizdevās ielādēt Vosk modeli: ${e.message}")
            }
        }
    }

    /** Padod audio fragmentu (PCM16, tas pats formāts, ko rada AudioCapture). */
    fun sendAudio(bytes: ByteArray) {
        if (!ready) return
        try {
            executor.execute {
                try {
                    val rec = recognizer ?: return@execute
                    val isFinal = rec.acceptWaveForm(bytes, bytes.size)
                    if (isFinal) {
                        val text = extractText(rec.result)
                        if (text.isNotBlank()) onFinal(text)
                    } else {
                        val text = extractText(rec.partialResult, partial = true)
                        if (text.isNotBlank()) onInterim(text)
                    }
                } catch (e: Exception) {
                    onError("Vosk atpazīšanas kļūda: ${e.message}")
                }
            }
        } catch (e: java.util.concurrent.RejectedExecutionException) {
            // Klients tieši tika aizvērts (executor jau shutdown) — audio
            // fragments vienkārši tiek izlaists, nekas nesalūst.
        }
    }

    private fun extractText(json: String, partial: Boolean = false): String {
        return try {
            val obj = JSONObject(json)
            obj.optString(if (partial) "partial" else "text", "")
        } catch (e: Exception) {
            ""
        }
    }

    fun close() {
        executor.execute {
            try {
                recognizer?.let { rec ->
                    val text = extractText(rec.finalResult)
                    if (text.isNotBlank()) onFinal(text)
                }
            } catch (e: Exception) { /* ignorējam */ }
            recognizer?.close()
            model?.close()
            recognizer = null
            model = null
            ready = false
        }
        // KRITISKI SVARĪGI: aizver PAŠU izpildītāju (fona pavedienu), ne
        // tikai modeļa objektus — citādi katrs jauns VoskAsrClient (kas
        // tiek izveidots ik pa 12-20 sekundēm valodas pārbaudei, un pie
        // katras "stop" komandas) atstāj "karājamies" fona pavedienu uz
        // mūžību. Ilgākā sesijā tas uzkrāj simtiem pavedienu un beigās
        // Android vairs neļauj izveidot jaunus — tas izpaudās kā
        // "pakāpeniska sastingšana" ilgākā lietošanā.
        executor.shutdown()
    }
}
