package com.ardecoderar.b2bandroidsub

/**
 * Sarunas stāvokļi. Vārds "stop" pilnībā pārslēdz starp tiem.
 *
 * LISTENING_SOURCE -> klausās otru pusi (AUTOMĀTISKI noteiktu valodu
 *                     starp visām lejupielādētajām Vosk valodām),
 *                     straumējoši tulko un runā latviski. Šis ir
 *                     sākuma/noklusējuma stāvoklis.
 *
 * LISTENING_USER    -> lietotājs pasaka "stop" -> klausās PAŠU LIETOTĀJU,
 *                      kas runā latviski (izmanto Android/Google runas
 *                      atpazīšanu, jo Vosk latviešu valodu neatbalsta),
 *                      iztulko un pasaka ANGLISKI, lai pretējā puse
 *                      saprot. Pasakot "stop" vēlreiz, atgriežas
 *                      LISTENING_SOURCE ar jaunu valodas detekcijas ciklu.
 */
enum class ConversationState {
    LISTENING_SOURCE,
    LISTENING_USER
}
