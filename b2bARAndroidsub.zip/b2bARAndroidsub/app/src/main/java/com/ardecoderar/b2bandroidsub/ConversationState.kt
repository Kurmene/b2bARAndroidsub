package com.ardecoderar.b2bandroidsub

/**
 * Sarunas stāvokļi. Vārds "punkts" pilnībā pārslēdz starp tiem (exclusive switch —
 * kad viens stāvoklis aktīvs, otrs ir pilnībā apturēts, nevis darbojas fonā).
 *
 * LISTENING_SOURCE -> klausās avota valodu (piem. vācu), straumējoši tulko un runā
 *                     mērķa valodā (noklusēti LV). Šis ir sākuma/noklusējuma stāvoklis.
 *
 * LISTENING_USER    -> lietotājs pasaka "punkts" -> DE klausīšanās pilnībā apstājas,
 *                      sākas lietotāja frāzes klausīšanās (LV vai EN, valoda netiek
 *                      prasīta — sistēma vienkārši klausās). Kad lietotājs atkal saka
 *                      "punkts", uztvertā frāze tiek iztulkota un pateikta angliski,
 *                      un sistēma automātiski atgriežas LISTENING_SOURCE stāvoklī.
 */
enum class ConversationState {
    LISTENING_SOURCE,
    LISTENING_USER
}
