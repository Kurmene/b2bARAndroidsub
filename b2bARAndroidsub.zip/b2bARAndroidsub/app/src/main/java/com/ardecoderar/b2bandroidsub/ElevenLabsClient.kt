package com.ardecoderar.b2bandroidsub

import android.media.MediaPlayer
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

/**
 * ElevenLabs teksta-uz-runu klients — ievērojami dabiskāka balss nekā
 * Android iebūvētais TTS. Izmanto "eleven_multilingual_v2" modeli, kas
 * PATS nosaka valodu no teksta (nav jānorāda atsevišķi) — der jebkurai
 * no lietotnes atbalstītajām valodām.
 *
 * Vajag ElevenLabs kontu un API atslēgu (elevenlabs.io -> Settings -> API Keys).
 * Bezmaksas līmenim ir ierobežots rakstzīmju skaits mēnesī.
 */
class ElevenLabsClient(
    private val apiKey: String,
    private val voiceId: String = "21m00Tcm4TlvDq8ikWAM" // ElevenLabs noklusējuma balss "Rachel"
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Ģenerē runu un atskaņo to. Atgriež true, ja izdevās. Fail-soft —
     * ja API izsaukums neizdodas (nav interneta, nederīga atslēga,
     * pārsniegts limits), atgriež false, lai izsaucējs var pāriet uz
     * Android TTS kā rezervi.
     */
    fun synthesizeAndPlay(text: String, tempDir: File, onDone: (Boolean) -> Unit) {
        if (apiKey.isBlank() || text.isBlank()) {
            onDone(false)
            return
        }

        try {
            val body = JSONObject().apply {
                put("text", text)
                put("model_id", "eleven_multilingual_v2")
                put("voice_settings", JSONObject().apply {
                    put("stability", 0.5)
                    put("similarity_boost", 0.75)
                })
            }.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("https://api.elevenlabs.io/v1/text-to-speech/$voiceId")
                .addHeader("xi-api-key", apiKey)
                .addHeader("Content-Type", "application/json")
                .addHeader("Accept", "audio/mpeg")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    onDone(false)
                    return
                }
                val audioBytes = response.body?.bytes()
                if (audioBytes == null || audioBytes.isEmpty()) {
                    onDone(false)
                    return
                }

                val tempFile = File(tempDir, "elevenlabs_utterance.mp3")
                FileOutputStream(tempFile).use { it.write(audioBytes) }

                val player = MediaPlayer()
                player.setDataSource(tempFile.absolutePath)
                player.setOnCompletionListener {
                    it.release()
                    tempFile.delete()
                    onDone(true)
                }
                player.setOnErrorListener { mp, _, _ ->
                    mp.release()
                    tempFile.delete()
                    onDone(false)
                    true
                }
                player.prepare()
                player.start()
            }
        } catch (e: Exception) {
            onDone(false)
        }
    }
}
