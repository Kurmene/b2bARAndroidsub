package com.ardecoderar.b2bandroidsub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * Viegls, VIENMĒR aktīvs klausītājs (atsevišķi no galvenā tulkošanas
 * servisa), kas gaida TIKAI divas frāzes: "translator on" un "translator
 * off". Izmanto to pašu angļu Vosk modeli, kas jau nepieciešams
 * TranslationService LISTENING_USER stāvoklim — nav vajadzīgs papildu
 * modelis.
 *
 * Kad dzird "translator on" -> palaiž TranslationService.
 * Kad dzird "translator off" -> aptur TranslationService.
 *
 * Šis serviss PATS turpina darboties nepārtraukti (arī kamēr galvenais
 * tulkošanas serviss ir izslēgts), lai vienmēr varētu reaģēt uz nākamo
 * balss komandu — tāpēc tas ir ĻOTI viegls (tikai viens neliels Vosk
 * modelis, nevis visa tulkošanas/detekcijas pipeline).
 */
class HotwordListenerService : Service() {

    companion object {
        const val CHANNEL_ID = "b2b_hotword_channel"
        const val NOTIF_ID = 2
        const val ACTION_HOTWORD_STATE = "com.ardecoderar.b2bandroidsub.HOTWORD_STATE"
        const val EXTRA_LISTENING = "listening"
        private const val PHRASE_ON = "translator on"
        private const val PHRASE_OFF = "translator off"
    }

    private lateinit var config: ConfigManager
    private lateinit var micRouter: BluetoothAudioRouter
    private var audioCapture: AudioCapture? = null
    private var asrClient: VoskAsrClient? = null
    @Volatile private var running = false
    @Volatile private var mainServiceActive = false

    override fun onCreate() {
        super.onCreate()
        config = ConfigManager(this)
        micRouter = BluetoothAudioRouter(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification("Gaida: \"translator on\" / \"translator off\""))
        if (!running) {
            running = true
            startListening()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        audioCapture?.stop()
        asrClient?.close()
        super.onDestroy()
    }

    private fun startListening() {
        if (!config.isVoskModelAvailable("en")) {
            updateNotification("TRŪKST angļu Vosk modeļa — balss komandas nestrādās (skat. README)")
            return
        }

        val modelDir = config.voskModelDirFor("en")
        asrClient = VoskAsrClient(
            modelDir = modelDir,
            onInterim = { text -> checkPhrase(text) },
            onFinal = { text -> checkPhrase(text) },
            onError = { /* klusi mēģina turpināt */ }
        )
        asrClient?.connect()

        val device = micRouter.findHearingAidInputDevice()
        val useSco = micRouter.hasClassicBluetoothHeadset() && device == null
        if (useSco) micRouter.startClassicScoAndWait()

        audioCapture = AudioCapture(device, useSco) { bytes ->
            asrClient?.sendAudio(bytes)
        }
        audioCapture?.start()
    }

    private fun checkPhrase(text: String) {
        val lower = text.lowercase(Locale.US)
        if (lower.contains(PHRASE_ON) && !mainServiceActive) {
            mainServiceActive = true
            startForegroundService(Intent(this, TranslationService::class.java))
            updateNotification("Tulks IESLĒGTS balsi (\"translator on\")")
            broadcastHotwordState(true)
        } else if (lower.contains(PHRASE_OFF) && mainServiceActive) {
            mainServiceActive = false
            stopService(Intent(this, TranslationService::class.java))
            updateNotification("Tulks IZSLĒGTS balsi (\"translator off\") — gaida nākamo komandu")
            broadcastHotwordState(false)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "b2bARAndroidsub balss komandas",
                NotificationManager.IMPORTANCE_MIN // klusa, pastāvīga, nemanāma paziņojumu joslā
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("b2bARAndroidsub — balss komandas")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(text))
    }

    private fun broadcastHotwordState(listening: Boolean) {
        val intent = Intent(ACTION_HOTWORD_STATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_LISTENING, listening)
        }
        sendBroadcast(intent)
    }
}
