package com.ardecoderar.b2bandroidsub

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.ardecoderar.b2bandroidsub.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var config: ConfigManager
    private var serviceRunning = false
    private var hotwordRunning = false

    // Tieši tāds pats valodu saraksts kā desktop ARB2Btext (subtitres.py -> VALODU_NOSAUKUMI)
    private val langCodes = listOf("lv", "ru", "en", "lt", "et", "de", "fi", "sv", "no", "fr", "es", "it", "pl")
    private val langLabels = listOf(
        "Latviešu", "Krievu", "Angļu", "Lietuviešu", "Igauņu", "Vācu",
        "Somu", "Zviedru", "Norvēģu", "Franču", "Spāņu", "Itāļu", "Poļu"
    )

    // Avota valodas izvēlnei "latviešu" IZSLĒGTS — Vosk to neatbalsta nemaz
    // (ne automātiski, ne manuāli), tāpēc tā nekad nevar būt derīga avota
    // valoda. Pati "avota valoda" pēc definīcijas ir OTRA puse sarunā, kas
    // runā svešvalodā — latviešu ir tikai TAVA runa (LISTENING_USER), ne avots.
    private val sourceLangCodes = langCodes.filterIndexed { i, code -> code != "lv" }
    private val sourceLangLabels = langLabels.filterIndexed { i, _ -> langCodes[i] != "lv" }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            if (intent.action == HotwordListenerService.ACTION_HOTWORD_STATE) {
                val listening = intent.getBooleanExtra(HotwordListenerService.EXTRA_LISTENING, false)
                serviceRunning = listening
                binding.startStopButton.text = if (listening) "Apturēt klausīšanos" else "Sākt klausīties"
                binding.statusText.text = if (listening)
                    "Statuss: ieslēdza ar balsi (\"translator on\")" else
                    "Statuss: izslēdza ar balsi (\"translator off\")"
                return
            }
            val state = intent.getStringExtra(TranslationService.EXTRA_STATE)
            val lastText = intent.getStringExtra(TranslationService.EXTRA_LAST_TEXT)
            val lastTranslation = intent.getStringExtra(TranslationService.EXTRA_LAST_TRANSLATION)
            val micSource = intent.getStringExtra(TranslationService.EXTRA_MIC_SOURCE)
            state?.let { binding.statusText.text = "Statuss: $it" }
            if (!lastText.isNullOrBlank()) binding.lastHeardText.text = "Dzirdēts: $lastText"
            if (!lastTranslation.isNullOrBlank()) binding.lastTranslationText.text = "Tulkots: $lastTranslation"
            if (!micSource.isNullOrBlank()) binding.micSourceText.text = "Mikrofons: $micSource"
        }
    }

    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val allGranted = grants.values.all { it }
        if (allGranted) {
            pendingPermissionAction?.invoke()
        } else {
            Toast.makeText(this, "Nepieciešamas mikrofona un paziņojumu atļaujas", Toast.LENGTH_LONG).show()
        }
        pendingPermissionAction = null
    }
    private var pendingPermissionAction: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        config = ConfigManager(this)

        // Drošības labojums: ja no vecākas versijas ir saglabāts "lv" kā
        // avota valoda (kas nekad nav derīga, jo Vosk to neatbalsta),
        // automātiski atiestata uz derīgu noklusējumu.
        if (config.sourceLang == "lv") {
            config.sourceLang = "de"
        }

        setupSpinners()
        loadConfigIntoUi()
        refreshModelStatus()

        // Ja modeļu trūkst, sākam lejupielādi AUTOMĀTISKI, tiklīdz lietotne
        // atveras — klientam pat poga nav jāmeklē/jāspiež pirmajā reizē.
        val srcLang = config.sourceLang
        if (!config.isVoskModelAvailable("en") || !config.isVoskModelAvailable(srcLang)) {
            autoDownloadModels()
        }

        binding.checkModelsButton.setOnClickListener { refreshModelStatus() }

        binding.autoDownloadButton.setOnClickListener { autoDownloadModels() }

        binding.startStopButton.setOnClickListener {
            if (serviceRunning) stopService() else startFlow()
        }

        binding.hotwordButton.setOnClickListener {
            if (hotwordRunning) stopHotwordListener() else startHotwordListener()
        }

        binding.helpButton.setOnClickListener {
            startActivity(Intent(this, HelpActivity::class.java))
        }

        binding.appAudioButton.setOnClickListener {
            startActivity(Intent(this, MediaProjectionRequestActivity::class.java))
            Toast.makeText(this, "Apstiprini nākamo dialogu, lai lietotne varētu klausīties citu app skaņu", Toast.LENGTH_LONG).show()
        }

        // Balss komandu klausītājs ("translator on/off") startē AUTOMĀTISKI,
        // ja tas iepriekš bijis ieslēgts (noklusēti IESLĒGTS) — klientam
        // nekas nav jāspiež, tas vienkārši strādā.
        if (config.hotwordEnabled) {
            startHotwordListener(silent = true)
        }
    }

    private fun startHotwordListener(silent: Boolean = false) {
        if (!config.isVoskModelAvailable("en")) {
            if (!silent) Toast.makeText(this, "Vajag angļu Vosk modeli balss komandām — lejupielādē modeļus vispirms", Toast.LENGTH_LONG).show()
            return
        }
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            if (!silent) {
                pendingPermissionAction = { startHotwordListener(silent = false) }
                requestPermissions.launch(missing.toTypedArray())
            }
            // klusajā (automātiskajā) startēšanas mēģinājumā neprasām atļaujas
            // uzreiz uzbāzīgi — lietotājs tās piešķirs, kad pats sāks klausīties
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, HotwordListenerService::class.java))
        hotwordRunning = true
        config.hotwordEnabled = true
        binding.hotwordButton.text = "Izslēgt balss komandas"
        if (!silent) Toast.makeText(this, "Klausās \"translator on\" / \"translator off\"", Toast.LENGTH_SHORT).show()
    }

    private fun stopHotwordListener() {
        stopService(Intent(this, HotwordListenerService::class.java))
        hotwordRunning = false
        config.hotwordEnabled = false
        binding.hotwordButton.text = "Ieslēgt balss komandas (\"translator on/off\")"
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(TranslationService.ACTION_STATE_UPDATE)
            addAction(HotwordListenerService.ACTION_HOTWORD_STATE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(statusReceiver, filter)
        }
        refreshModelStatus()
        binding.hotwordButton.text = if (hotwordRunning) "Izslēgt balss komandas" else "Ieslēgt balss komandas (\"translator on/off\")"
    }

    override fun onPause() {
        super.onPause()
        runCatching { unregisterReceiver(statusReceiver) }
    }

    private fun setupSpinners() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sourceLangLabels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.sourceLangSpinner.adapter = adapter

        val listener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                saveUiIntoConfig()
                refreshModelStatus()
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }
        binding.sourceLangSpinner.onItemSelectedListener = listener
    }

    private fun loadConfigIntoUi() {
        binding.wakeWordInput.setText(config.wakeWord)
        binding.sourceLangSpinner.setSelection(sourceLangCodes.indexOf(config.sourceLang).coerceAtLeast(0))
        binding.mmsServerUrlInput.setText(config.mmsServerUrl)
        binding.mmsApiKeyInput.setText(config.mmsApiKey)
        binding.customLangInput.setText(config.customSourceLangCode)
        binding.hearingAidMicSwitch.isChecked = config.useHearingAidMic
        binding.hearingAidMicSwitch.setOnCheckedChangeListener { _, isChecked ->
            config.useHearingAidMic = isChecked
        }
    }

    private fun saveUiIntoConfig() {
        config.wakeWord = binding.wakeWordInput.text.toString().trim().ifBlank { "stop" }
        config.sourceLang = sourceLangCodes[binding.sourceLangSpinner.selectedItemPosition]
        config.mmsServerUrl = binding.mmsServerUrlInput.text.toString().trim()
        config.mmsApiKey = binding.mmsApiKeyInput.text.toString().trim()
        config.customSourceLangCode = binding.customLangInput.text.toString().trim()
    }

    private fun refreshModelStatus() {
        val srcLang = sourceLangCodes.getOrElse(binding.sourceLangSpinner.selectedItemPosition) { config.sourceLang }
        val srcOk = config.isVoskModelAvailable(srcLang)
        val enOk = config.isVoskModelAvailable("en")
        val rootPath = config.voskModelsRootDir().absolutePath

        val srcMark = if (srcOk) "✓" else "✗ TRŪKST"
        val enMark = if (enOk) "✓" else "✗ TRŪKST"

        binding.modelStatusText.text =
            "Vosk modeļi:\n  $srcLang (avots): $srcMark\n  en (atbildes): $enMark\n\nMape: $rootPath"
    }

    /**
     * Lejupielādē un uzstāda vajadzīgos modeļus (avota valoda + angļu)
     * AUTOMĀTISKI, ar vienu pogas piespiešanu — bez pārlūka, bez failu
     * pārvaldnieka, bez manuālas izpakošanas. Šis ir galvenais ceļš, ko
     * ieteikt klientiem (nevis README manuālo instrukciju).
     */
    private fun autoDownloadModels() {
        val srcLang = sourceLangCodes[binding.sourceLangSpinner.selectedItemPosition]
        val needed = mutableListOf<String>()
        if (!config.isVoskModelAvailable("en")) needed.add("en")
        if (!config.isVoskModelAvailable(srcLang) && srcLang != "en") needed.add(srcLang)

        if (needed.isEmpty()) {
            Toast.makeText(this, "Modeļi jau uzstādīti", Toast.LENGTH_SHORT).show()
            return
        }

        val notSupported = needed.filter { !ModelDownloader.canAutoDownload(it) }
        if (notSupported.isNotEmpty()) {
            Toast.makeText(
                this,
                "Valodām ${notSupported.joinToString()} nav automātiskas lejupielādes — skat. README manuālo ceļu",
                Toast.LENGTH_LONG
            ).show()
        }
        val toDownload = needed.filter { ModelDownloader.canAutoDownload(it) }
        if (toDownload.isEmpty()) return

        binding.autoDownloadButton.isEnabled = false
        binding.autoDownloadButton.text = "Lejupielādē..."

        lifecycleScope.launch {
            for (lang in toDownload) {
                binding.modelStatusText.text = "Lejupielādē '$lang' modeli... 0%"
                val ok = withContext(Dispatchers.IO) {
                    ModelDownloader.downloadAndInstall(lang, config.voskModelsRootDir()) { percent ->
                        runOnUiThread {
                            binding.modelStatusText.text = if (percent >= 0)
                                "Lejupielādē '$lang' modeli... $percent%"
                            else
                                "Lejupielādē '$lang' modeli..."
                        }
                    }
                }
                if (!ok) {
                    Toast.makeText(
                        this@MainActivity,
                        "Neizdevās lejupielādēt '$lang' modeli — pārbaudi interneta savienojumu",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            binding.autoDownloadButton.isEnabled = true
            binding.autoDownloadButton.text = "Lejupielādēt modeļus automātiski"
            refreshModelStatus()
            Toast.makeText(this@MainActivity, "Gatavs!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startFlow() {
        saveUiIntoConfig()
        if (!config.isConfigured()) {
            Toast.makeText(
                this,
                "Trūkst Vosk valodu modeļu — spied 'Lejupielādēt modeļus automātiski'",
                Toast.LENGTH_LONG
            ).show()
            refreshModelStatus()
            return
        }

        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            pendingPermissionAction = { launchService() }
            requestPermissions.launch(missing.toTypedArray())
        } else {
            launchService()
        }
    }

    private fun launchService() {
        val intent = Intent(this, TranslationService::class.java)
        ContextCompat.startForegroundService(this, intent)
        serviceRunning = true
        binding.startStopButton.text = "Apturēt klausīšanos"
        binding.statusText.text = "Statuss: klausās, tulko uz latviešu — \"${config.wakeWord}\" pārslēdz uz tavu atbildi"

        // Atļaujas tagad piešķirtas — izmantojam brīdi, lai klusi startētu
        // arī balss komandu klausītāju, ja tas vēl nav aktīvs.
        if (config.hotwordEnabled && !hotwordRunning) {
            startHotwordListener(silent = true)
        }
    }

    private fun stopService() {
        stopService(Intent(this, TranslationService::class.java))
        serviceRunning = false
        binding.startStopButton.text = "Sākt klausīties"
        binding.statusText.text = "Statuss: apturēts"
    }
}
