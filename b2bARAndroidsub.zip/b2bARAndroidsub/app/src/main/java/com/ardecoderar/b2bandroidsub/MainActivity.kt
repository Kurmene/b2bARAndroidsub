package com.ardecoderar.b2bandroidsub

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.ardecoderar.b2bandroidsub.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var config: ConfigManager
    private var serviceRunning = false
    private var hotwordRunning = false

    // Tieši tāds pats valodu saraksts kā desktop ARB2Btext (subtitres.py -> VALODU_NOSAUKUMI)
    private val langCodes = listOf("lv", "ru", "en", "lt", "et", "de", "fi", "sv", "no", "fr", "es", "it", "pl")
    private val langLabels = listOf(
        "Latviešu", "Krievu", "Angļu", "Lietuviešu", "Igauņu", "Vācu",
        "Somu", "Zviedru", "Norvēģu", "Franču", "Spāņu", "Itāļu", "Poļu"
    )

    // Avota valodas izvēlnei "latviešu" IZSLĒGTS — Vosk to neatbalsta nemaz
    // (ne automātiski, ne manuāli), tāpēc tā nekad nevar būt derīga avota
    // valoda. Pati "avota valoda" pēc definīcijas ir OTRA puse sarunā, kas
    // runā svešvalodā — latviešu ir tikai TAVA runa (LISTENING_USER), ne avots.
    private val sourceLangCodes = langCodes.filterIndexed { i, code -> code != "lv" }
    private val sourceLangLabels = langLabels.filterIndexed { i, _ -> langCodes[i] != "lv" }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            if (intent.action == HotwordListenerService.ACTION_HOTWORD_STATE) {
                val listening = intent.getBooleanExtra(HotwordListenerService.EXTRA_LISTENING, false)
                serviceRunning = listening
                binding.startStopButton.text = if (listening) "Apturēt klausīšanos" else "Sākt klausīties"
                setListeningIndicator(listening)
                binding.statusText.text = if (listening)
                    "Statuss: ieslēdza ar balsi (\"translator on\")" else
                    "Statuss: izslēdza ar balsi (\"translator off\")"
                return
            }
            val state = intent.getStringExtra(TranslationService.EXTRA_STATE)
            val lastText = intent.getStringExtra(TranslationService.EXTRA_LAST_TEXT)
            val lastTranslation = intent.getStringExtra(TranslationService.EXTRA_LAST_TRANSLATION)
            val micSource = intent.getStringExtra(TranslationService.EXTRA_MIC_SOURCE)
            state?.let { binding.statusText.text = "Statuss: $it" }
            if (!lastText.isNullOrBlank()) binding.lastHeardText.text = "Dzirdēts: $lastText"
            if (!lastTranslation.isNullOrBlank()) binding.lastTranslationText.text = "Tulkots: $lastTranslation"
            if (!micSource.isNullOrBlank()) binding.micSourceText.text = "Mikrofons: $micSource"
        }
    }

    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val allGranted = grants.values.all { it }
        if (allGranted) {
            pendingPermissionAction?.invoke()
        } else {
            Toast.makeText(this, "Nepieciešamas mikrofona un paziņojumu atļaujas", Toast.LENGTH_LONG).show()
        }
        pendingPermissionAction = null
    }
    private var pendingPermissionAction: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        config = ConfigManager(this)

        // Drošības labojums: ja no vecākas versijas ir saglabāts "lv" kā
        // avota valoda (kas nekad nav derīga, jo Vosk to neatbalsta),
        // automātiski atiestata uz derīgu noklusējumu.
        if (config.sourceLang == "lv") {
            config.sourceLang = "de"
        }

        setupSpinners()
        loadConfigIntoUi()
        refreshModelStatus()

        binding.checkModelsButton.setOnClickListener { refreshModelStatus() }
        binding.autoDownloadButton.setOnClickListener { autoDownloadRegionLanguages() }
        binding.highAccuracyButton.setOnClickListener { downloadHighAccuracyModels() }
        binding.startStopButton.setOnClickListener {
            if (serviceRunning) stopService() else startFlow()
        }
        binding.hotwordButton.setOnClickListener {
            if (hotwordRunning) stopHotwordListener() else startHotwordListener()
        }
        binding.helpButton.setOnClickListener {
            startActivity(Intent(this, HelpActivity::class.java))
        }
        binding.appAudioButton.setOnClickListener {
            startActivity(Intent(this, MediaProjectionRequestActivity::class.java))
            Toast.makeText(this, "Apstiprini nākamo dialogu, lai lietotne varētu klausīties citu app skaņu", Toast.LENGTH_LONG).show()
        }

        // VIENS, SKAIDRS inicializācijas process — VIENA secīga plūsma,
        // NEVIS divi paralēli ceļi, kas skrēja vienlaicīgi (iepriekšējā
        // versijā tas izraisīja nenoteiktu uzvedību tieši palaišanas
        // brīdī). Vispirms pārbauda REĀLO servisu stāvokli; JA tie jau
        // darbojas, tikai atjaunina UI un NEKO nerestartē; JA NE, tad —
        // un tikai tad — sāk modeļu pārbaudi/lejupielādi FONĀ, un TIKAI
        // PĒC TAM (kad tā pabeigta) izlemj par klausīšanās sākšanu.
        val hotwordAlreadyRunning = isServiceRunning(HotwordListenerService::class.java)
        val translationAlreadyRunning = isServiceRunning(TranslationService::class.java)
        serviceRunning = translationAlreadyRunning
        hotwordRunning = hotwordAlreadyRunning

        if (translationAlreadyRunning) {
            setListeningIndicator(true)
        }
        if (hotwordAlreadyRunning) {
            binding.hotwordButton.text = "Izslēgt balss komandas"
        }

        lifecycleScope.launch {
            // 1. Iebūvētie modeļi (ja tādi ir APK iekšā) — fonā, lai
            //    nesaldētu palaišanas ekrānu.
            val bundled = withContext(Dispatchers.IO) {
                AssetModelInstaller.installBundledModelsIfPresent(this@MainActivity, config.voskModelsRootDir())
            }
            if (bundled.isNotEmpty()) {
                Toast.makeText(this@MainActivity, "Iebūvētie modeļi gatavi: ${bundled.joinToString()}", Toast.LENGTH_SHORT).show()
                refreshModelStatus()
            }

            // 2. Reģiona valodu automātiskā lejupielāde (ja vajadzīgs) —
            //    šī funkcija PATI izsauc maybeAutoStartListening() savā
            //    beigās, kad viss ir gatavs.
            autoDownloadRegionLanguages()

            // 3. Balss komandu klausītājs — sāk TIKAI TAGAD (pēc modeļu
            //    pārbaudes), un TIKAI ja tas jau nav aktīvs.
            if (!hotwordAlreadyRunning && config.hotwordEnabled) {
                startHotwordListener(silent = true)
            }
        }
    }

    private fun startHotwordListener(silent: Boolean = false) {
        if (!config.isVoskModelAvailable("en")) {
            if (!silent) Toast.makeText(this, "Vajag angļu Vosk modeli balss komandām — lejupielādē modeļus vispirms", Toast.LENGTH_LONG).show()
            return
        }
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            if (!silent) {
                pendingPermissionAction = { startHotwordListener(silent = false) }
                requestPermissions.launch(missing.toTypedArray())
            }
            // klusajā (automātiskajā) startēšanas mēģinājumā neprasām atļaujas
            // uzreiz uzbāzīgi — lietotājs tās piešķirs, kad pats sāks klausīties
            return
        }
        try {
            ContextCompat.startForegroundService(this, Intent(this, HotwordListenerService::class.java))
            hotwordRunning = true
            config.hotwordEnabled = true
            binding.hotwordButton.text = "Izslēgt balss komandas"
            if (!silent) Toast.makeText(this, "Klausās \"translator on\" / \"translator off\"", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // Tas pats Android ierobežojums, kas aprakstīts launchService() —
            // NEDRĪKST avarēt app, ja tas notiek fonā/pēc lejupielādes.
            if (!silent) {
                Toast.makeText(this, "Neizdevās sākt balss komandas automātiski — nospied pogu pats", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun stopHotwordListener() {
        stopService(Intent(this, HotwordListenerService::class.java))
        hotwordRunning = false
        config.hotwordEnabled = false
        binding.hotwordButton.text = "Ieslēgt balss komandas (\"translator on/off\")"
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(TranslationService.ACTION_STATE_UPDATE)
            addAction(HotwordListenerService.ACTION_HOTWORD_STATE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(statusReceiver, filter)
        }
        refreshModelStatus()
        binding.hotwordButton.text = if (hotwordRunning) "Izslēgt balss komandas" else "Ieslēgt balss komandas (\"translator on/off\")"

        // Pārbauda REĀLO servisa stāvokli (nevis paļaujas uz iepriekšējo
        // ekrāna tekstu, kas var būt novecojis, ja serviss darbojās fonā
        // arī tad, kad lietotne bija aizvērta).
        val actuallyRunning = isServiceRunning(TranslationService::class.java)
        serviceRunning = actuallyRunning
        binding.startStopButton.text = if (actuallyRunning) "Apturēt klausīšanos" else "Sākt klausīties"
        setListeningIndicator(actuallyRunning)
        binding.statusText.text = if (actuallyRunning)
            "Statuss: klausās (jau bija aktīvs)" else "Statuss: apturēts"
    }

    @Suppress("DEPRECATION")
    private fun isServiceRunning(serviceClass: Class<*>): Boolean {
        val manager = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        return manager.getRunningServices(Int.MAX_VALUE).any { it.service.className == serviceClass.name }
    }

    override fun onPause() {
        super.onPause()
        runCatching { unregisterReceiver(statusReceiver) }
    }

    private fun setupSpinners() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sourceLangLabels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.sourceLangSpinner.adapter = adapter

        val listener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                saveUiIntoConfig()
                refreshModelStatus()
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }
        binding.sourceLangSpinner.onItemSelectedListener = listener
    }

    private fun loadConfigIntoUi() {
        binding.wakeWordInput.setText(config.wakeWord)
        binding.sourceLangSpinner.setSelection(sourceLangCodes.indexOf(config.sourceLang).coerceAtLeast(0))
        binding.mmsServerUrlInput.setText(config.mmsServerUrl)
        binding.mmsApiKeyInput.setText(config.mmsApiKey)
        binding.customLangInput.setText(config.customSourceLangCode)
        binding.elevenLabsKeyInput.setText(config.elevenLabsApiKey)
        binding.hearingAidMicSwitch.isChecked = config.useHearingAidMic
        binding.hearingAidMicSwitch.setOnCheckedChangeListener { _, isChecked ->
            config.useHearingAidMic = isChecked
        }
    }

    private fun saveUiIntoConfig() {
        config.wakeWord = binding.wakeWordInput.text.toString().trim().ifBlank { "stop" }
        config.sourceLang = sourceLangCodes[binding.sourceLangSpinner.selectedItemPosition]
        config.mmsServerUrl = binding.mmsServerUrlInput.text.toString().trim()
        config.mmsApiKey = binding.mmsApiKeyInput.text.toString().trim()
        config.customSourceLangCode = binding.customLangInput.text.toString().trim()
        config.elevenLabsApiKey = binding.elevenLabsKeyInput.text.toString().trim()
    }

    private fun refreshModelStatus() {
        val srcLang = sourceLangCodes.getOrElse(binding.sourceLangSpinner.selectedItemPosition) { config.sourceLang }
        val srcOk = config.isVoskModelAvailable(srcLang)
        val enOk = config.isVoskModelAvailable("en")
        val rootPath = config.voskModelsRootDir().absolutePath

        val srcMark = if (srcOk) "✓" else "✗ TRŪKST"
        val enMark = if (enOk) "✓" else "✗ TRŪKST"

        binding.modelStatusText.text =
            "Vosk modeļi:\n  $srcLang (avots): $srcMark\n  en (atbildes): $enMark\n\nMape: $rootPath"
    }

    /**
     * Lejupielādē un uzstāda vajadzīgos modeļus (avota valoda + angļu)
     * AUTOMĀTISKI, ar vienu pogas piespiešanu — bez pārlūka, bez failu
     * pārvaldnieka, bez manuālas izpakošanas. Šis ir galvenais ceļš, ko
     * ieteikt klientiem (nevis README manuālo instrukciju).
     */
    /**
     * Nosaka telefona reģionu (tīkla valsts — parāda, KUR fiziski atrodies,
     * nevis tikai telefona valodas iestatījumu) un AUTOMĀTISKI lejupielādē
     * VISAS jēgpilnās "kaimiņu" valodas šim reģionam, lai auto-detekcija
     * strādātu bez manuālas izvēles.
     */
    private fun autoDownloadRegionLanguages() {
        val regionCode = detectRegionCode()
        val regionLangs = RegionLanguagePresets.languagesFor(regionCode)

        // "en" vienmēr vajadzīgs (atbildēm/balss komandām), plus visas
        // reģiona valodas, kas vēl nav lejupielādētas.
        val wanted = (listOf("en") + regionLangs).distinct()
        val needed = wanted.filter { !config.isVoskModelAvailable(it) }

        if (needed.isEmpty()) {
            refreshModelStatus()
            maybeAutoStartListening()
            return
        }

        val notSupported = needed.filter { !ModelDownloader.canAutoDownload(it) }
        val toDownload = needed.filter { ModelDownloader.canAutoDownload(it) }

        if (toDownload.isEmpty()) {
            if (notSupported.isNotEmpty()) {
                binding.modelStatusText.text =
                    "Reģions: ${regionCode ?: "nav noteikts"}\nValodām ${notSupported.joinToString()} nav Vosk atbalsta (zināms ierobežojums)."
            }
            maybeAutoStartListening()
            return
        }

        binding.autoDownloadButton.isEnabled = false
        binding.autoDownloadButton.text = "Lejupielādē reģiona valodas..."

        lifecycleScope.launch {
            try {
                // Drošības pārbaude: vai telefonā ir pietiekami daudz brīvas
                // vietas VISĀM lejupielādēm kopā (aptuveni, ar rezervi) —
                // ja nav, labāk pateikt to skaidri, nevis ļaut lejupielādei
                // izraisīt neparedzamu kļūmi vidū.
                val estimatedBytesNeeded = toDownload.size * 150L * 1024 * 1024 // ~150MB uz valodu, ar rezervi
                val freeBytes = config.voskModelsRootDir().usableSpace
                if (freeBytes < estimatedBytesNeeded) {
                    binding.modelStatusText.text =
                        "UZMANĪBU: var nepietikt brīvas vietas (~${estimatedBytesNeeded / 1024 / 1024}MB vajadzīgi, ${freeBytes / 1024 / 1024}MB brīvi). Mēģinu tik un tā..."
                }

                for (lang in toDownload) {
                    binding.modelStatusText.text = "Reģions: ${regionCode ?: "?"} — lejupielādē '$lang'... 0%"
                    val ok = try {
                        withContext(Dispatchers.IO) {
                            ModelDownloader.downloadAndInstall(lang, config.voskModelsRootDir()) { percent ->
                                runOnUiThread {
                                    if (!isFinishing && !isDestroyed) {
                                        binding.modelStatusText.text = if (percent >= 0)
                                            "Reģions: ${regionCode ?: "?"} — lejupielādē '$lang'... $percent%"
                                        else
                                            "Reģions: ${regionCode ?: "?"} — lejupielādē '$lang'..."
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        // Šī VIENA valoda neizdevās (nav vietas, pārtraukts
                        // savienojums, u.c.) — NEPĀRTRAUCAM visu procesu,
                        // vienkārši turpinām ar nākamo valodu sarakstā.
                        false
                    }
                    if (!ok) {
                        Toast.makeText(this@MainActivity, "Neizdevās lejupielādēt '$lang' modeli", Toast.LENGTH_SHORT).show()
                    }
                }
                binding.autoDownloadButton.isEnabled = true
                binding.autoDownloadButton.text = "Lejupielādēt modeļus automātiski"
                refreshModelStatus()
                val skippedNote = if (notSupported.isNotEmpty()) " (${notSupported.joinToString()} nav Vosk atbalstīts)" else ""
                Toast.makeText(this@MainActivity, "Reģiona valodas gatavas!$skippedNote", Toast.LENGTH_LONG).show()

                // TIEŠI TAGAD, kad lejupielāde pabeigta (100%), automātiski sāk
                // klausīties — lai nebūtu jāgaida, ka lietotājs pats pamana un
                // nospiež pogu manuāli. Tas aizver "automatizācijas robu".
                maybeAutoStartListening()
            } catch (e: Exception) {
                // PĒDĒJAIS drošības tīkls — jebkas neparedzēts šajā visā
                // procesā NEDRĪKST avarēt visu app, tikai parādīt ziņojumu.
                binding.autoDownloadButton.isEnabled = true
                binding.autoDownloadButton.text = "Lejupielādēt modeļus automātiski"
                binding.modelStatusText.text = "Lejupielādes kļūda: ${e.message ?: "nezināma"}"
                Toast.makeText(this@MainActivity, "Lejupielāde neizdevās — pamēģini vēlreiz", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Sāk klausīties automātiski, ja vēl nedarbojas un modeļi jau ir gatavi. */
    private fun maybeAutoStartListening() {
        val actuallyRunning = isServiceRunning(TranslationService::class.java)
        if (!actuallyRunning && config.isConfigured()) {
            startFlow()
        }
    }

    /** Tīkla operatora valsts kods (precīzāk par telefona valodas iestatījumu, jo atspoguļo faktisko atrašanās vietu). */
    @Suppress("DEPRECATION")
    private fun detectRegionCode(): String? {
        return try {
            val telephonyManager = getSystemService(TELEPHONY_SERVICE) as android.telephony.TelephonyManager
            val networkCountry = telephonyManager.networkCountryIso
            if (!networkCountry.isNullOrBlank()) {
                networkCountry.uppercase()
            } else {
                java.util.Locale.getDefault().country.ifBlank { null }
            }
        } catch (e: Exception) {
            java.util.Locale.getDefault().country.ifBlank { null }
        }
    }

    /**
     * Lejupielādē PILNOS, daudz precīzākus modeļus angļu un vācu valodai
     * (~1.8GB katrs) — piedāvāts kā IZVĒLES uzlabojums, jo mazie modeļi
     * (~40-50MB) dažiem lietotājiem dod nepietiekamu atpazīšanas precizitāti.
     * Tavam telefonam (spēcīgs procesors, 12GB RAM) šis izmērs nav problēma.
     */
    private fun downloadHighAccuracyModels() {
        binding.highAccuracyButton.isEnabled = false
        binding.highAccuracyButton.text = "Lejupielādē (var aizņemt vairākas minūtes)..."

        lifecycleScope.launch {
            for ((lang, _) in ModelDownloader.highAccuracyModels) {
                binding.modelStatusText.text = "Augstas precizitātes '$lang' modelis... 0% (~1.8GB, ilgāk)"
                val ok = withContext(Dispatchers.IO) {
                    ModelDownloader.downloadHighAccuracy(lang, config.voskModelsRootDir()) { percent ->
                        runOnUiThread {
                            binding.modelStatusText.text = "Augstas precizitātes '$lang' modelis... $percent%"
                        }
                    }
                }
                if (!ok) {
                    Toast.makeText(this@MainActivity, "Neizdevās lejupielādēt '$lang' (pārbaudi vietu/internetu)", Toast.LENGTH_LONG).show()
                }
            }
            binding.highAccuracyButton.isEnabled = true
            binding.highAccuracyButton.text = "Augsta precizitāte (angļu/vācu, ~1.8GB katra)"
            refreshModelStatus()
            Toast.makeText(this@MainActivity, "Augstas precizitātes modeļi gatavi!", Toast.LENGTH_LONG).show()
        }
    }

    private fun autoDownloadModels() {
        val srcLang = sourceLangCodes[binding.sourceLangSpinner.selectedItemPosition]
        val needed = mutableListOf<String>()
        if (!config.isVoskModelAvailable("en")) needed.add("en")
        if (!config.isVoskModelAvailable(srcLang) && srcLang != "en") needed.add(srcLang)

        if (needed.isEmpty()) {
            Toast.makeText(this, "Modeļi jau uzstādīti", Toast.LENGTH_SHORT).show()
            return
        }

        val notSupported = needed.filter { !ModelDownloader.canAutoDownload(it) }
        if (notSupported.isNotEmpty()) {
            Toast.makeText(
                this,
                "Valodām ${notSupported.joinToString()} nav automātiskas lejupielādes — skat. README manuālo ceļu",
                Toast.LENGTH_LONG
            ).show()
        }
        val toDownload = needed.filter { ModelDownloader.canAutoDownload(it) }
        if (toDownload.isEmpty()) return

        binding.autoDownloadButton.isEnabled = false
        binding.autoDownloadButton.text = "Lejupielādē..."

        lifecycleScope.launch {
            for (lang in toDownload) {
                binding.modelStatusText.text = "Lejupielādē '$lang' modeli... 0%"
                val ok = withContext(Dispatchers.IO) {
                    ModelDownloader.downloadAndInstall(lang, config.voskModelsRootDir()) { percent ->
                        runOnUiThread {
                            binding.modelStatusText.text = if (percent >= 0)
                                "Lejupielādē '$lang' modeli... $percent%"
                            else
                                "Lejupielādē '$lang' modeli..."
                        }
                    }
                }
                if (!ok) {
                    Toast.makeText(
                        this@MainActivity,
                        "Neizdevās lejupielādēt '$lang' modeli — pārbaudi interneta savienojumu",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            binding.autoDownloadButton.isEnabled = true
            binding.autoDownloadButton.text = "Lejupielādēt modeļus automātiski"
            refreshModelStatus()
            Toast.makeText(this@MainActivity, "Gatavs!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startFlow() {
        saveUiIntoConfig()
        if (!config.isConfigured()) {
            Toast.makeText(
                this,
                "Trūkst Vosk valodu modeļu — spied 'Lejupielādēt modeļus automātiski'",
                Toast.LENGTH_LONG
            ).show()
            refreshModelStatus()
            return
        }

        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            pendingPermissionAction = { launchService() }
            requestPermissions.launch(missing.toTypedArray())
        } else {
            launchService()
        }
    }

    private fun launchService() {
        try {
            val intent = Intent(this, TranslationService::class.java)
            ContextCompat.startForegroundService(this, intent)
            serviceRunning = true
            binding.startStopButton.text = "Apturēt klausīšanos"
            setListeningIndicator(true)
            binding.statusText.text = "Statuss: klausās, tulko uz latviešu — \"${config.wakeWord}\" pārslēdz uz tavu atbildi"

            // Atļaujas tagad piešķirtas — izmantojam brīdi, lai klusi startētu
            // arī balss komandu klausītāju, ja tas vēl nav aktīvs.
            if (config.hotwordEnabled && !hotwordRunning) {
                startHotwordListener(silent = true)
            }
        } catch (e: Exception) {
            // KRITISKI SVARĪGI: Android (12+) NEĻAUJ palaist jaunu foreground
            // servisu, ja app TIEŠI TAJĀ BRĪDĪ nav priekšplānā (piem., ekrāns
            // izslēdzies vai lietotājs pārslēdzies uz citu app, kamēr gaidīja
            // lejupielādi). Tas izmet izņēmumu, kas BEZ šī try-catch avarētu
            // VISU app. Tagad tā vietā vienkārši parāda ziņojumu — lietotājam
            // jāatgriežas app un jānospiež "Sākt klausīties" manuāli.
            binding.statusText.text = "Statuss: neizdevās sākt automātiski — atgriezies app un nospied 'Sākt klausīties'"
            Toast.makeText(
                this,
                "Neizdevās sākt klausīšanos automātiski (Android drošības ierobežojums) — nospied 'Sākt klausīties' pats",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    /** Vienotā vieta, kas maina pogas KRĀSU un TEKSTU atkarībā no reālā stāvokļa. */
    private fun setListeningIndicator(active: Boolean) {
        binding.startStopButton.text = if (active) "Klausās (aptur)" else "Sāk klausīties..."
        binding.startStopButton.backgroundTintList =
            android.content.res.ColorStateList.valueOf(
                if (active) android.graphics.Color.parseColor("#2E7D32") else android.graphics.Color.parseColor("#C62828")
            )
    }

    private fun stopService() {
        stopService(Intent(this, TranslationService::class.java))
        serviceRunning = false
        binding.startStopButton.text = "Sākt klausīties"
        setListeningIndicator(false)
        binding.statusText.text = "Statuss: apturēts"
    }
}
