package com.ardecoderar.b2bandroidsub

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.ardecoderar.b2bandroidsub.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var config: ConfigManager
    private var serviceRunning = false
    private var hotwordRunning = false

    // Tieši tāds pats valodu saraksts kā desktop ARB2Btext (subtitres.py -> VALODU_NOSAUKUMI)
    private val langCodes = listOf("lv", "ru", "en", "lt", "et", "de", "fi", "sv", "no", "fr", "es", "it", "pl")
    private val langLabels = listOf(
        "Latviešu", "Krievu", "Angļu", "Lietuviešu", "Igauņu", "Vācu",
        "Somu", "Zviedru", "Norvēģu", "Franču", "Spāņu", "Itāļu", "Poļu"
    )

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            if (intent.action == HotwordListenerService.ACTION_HOTWORD_STATE) {
                val listening = intent.getBooleanExtra(HotwordListenerService.EXTRA_LISTENING, false)
                serviceRunning = listening
                binding.startStopButton.text = if (listening) "Apturēt klausīšanos" else "Sākt klausīties"
                binding.statusText.text = if (listening)
                    "Statuss: ieslēdza ar balsi (\"translator on\")" else
                    "Statuss: izslēdza ar balsi (\"translator off\")"
                return
            }
            val state = intent.getStringExtra(TranslationService.EXTRA_STATE)
            val lastText = intent.getStringExtra(TranslationService.EXTRA_LAST_TEXT)
            val lastTranslation = intent.getStringExtra(TranslationService.EXTRA_LAST_TRANSLATION)
            val micSource = intent.getStringExtra(TranslationService.EXTRA_MIC_SOURCE)
            state?.let { binding.statusText.text = "Statuss: $it" }
            if (!lastText.isNullOrBlank()) binding.lastHeardText.text = "Dzirdēts: $lastText"
            if (!lastTranslation.isNullOrBlank()) binding.lastTranslationText.text = "Tulkots: $lastTranslation"
            if (!micSource.isNullOrBlank()) binding.micSourceText.text = "Mikrofons: $micSource"
        }
    }

    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val allGranted = grants.values.all { it }
        if (allGranted) {
            launchService()
        } else {
            Toast.makeText(this, "Nepieciešamas mikrofona un paziņojumu atļaujas", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        config = ConfigManager(this)
        setupSpinners()
        loadConfigIntoUi()
        refreshModelStatus()

        binding.checkModelsButton.setOnClickListener { refreshModelStatus() }

        binding.startStopButton.setOnClickListener {
            if (serviceRunning) stopService() else startFlow()
        }

        binding.hotwordButton.setOnClickListener {
            if (hotwordRunning) stopHotwordListener() else startHotwordListener()
        }
    }

    private fun startHotwordListener() {
        if (!config.isVoskModelAvailable("en")) {
            Toast.makeText(this, "Vajag angļu Vosk modeli balss komandām — skat. README", Toast.LENGTH_LONG).show()
            return
        }
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions.launch(missing.toTypedArray())
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, HotwordListenerService::class.java))
        hotwordRunning = true
        binding.hotwordButton.text = "Izslēgt balss komandas"
        Toast.makeText(this, "Klausās \"translator on\" / \"translator off\"", Toast.LENGTH_SHORT).show()
    }

    private fun stopHotwordListener() {
        stopService(Intent(this, HotwordListenerService::class.java))
        hotwordRunning = false
        binding.hotwordButton.text = "Ieslēgt balss komandas (\"translator on/off\")"
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(TranslationService.ACTION_STATE_UPDATE)
            addAction(HotwordListenerService.ACTION_HOTWORD_STATE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(statusReceiver, filter)
        }
        refreshModelStatus()
    }

    override fun onPause() {
        super.onPause()
        runCatching { unregisterReceiver(statusReceiver) }
    }

    private fun setupSpinners() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, langLabels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.sourceLangSpinner.adapter = adapter
        binding.targetLangSpinner.adapter = adapter
        binding.replyLangSpinner.adapter = adapter

        val listener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                saveUiIntoConfig()
                refreshModelStatus()
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }
        binding.sourceLangSpinner.onItemSelectedListener = listener
    }

    private fun loadConfigIntoUi() {
        binding.wakeWordInput.setText(config.wakeWord)
        binding.sourceLangSpinner.setSelection(langCodes.indexOf(config.sourceLang).coerceAtLeast(0))
        binding.targetLangSpinner.setSelection(langCodes.indexOf(config.targetLang).coerceAtLeast(1))
        binding.replyLangSpinner.setSelection(langCodes.indexOf(config.replyOutputLang).coerceAtLeast(2))
        binding.mmsServerUrlInput.setText(config.mmsServerUrl)
        binding.mmsApiKeyInput.setText(config.mmsApiKey)
        binding.customLangInput.setText(config.customSourceLangCode)
    }

    private fun saveUiIntoConfig() {
        config.wakeWord = binding.wakeWordInput.text.toString().trim().ifBlank { "punkts" }
        config.sourceLang = langCodes[binding.sourceLangSpinner.selectedItemPosition]
        config.targetLang = langCodes[binding.targetLangSpinner.selectedItemPosition]
        config.replyOutputLang = langCodes[binding.replyLangSpinner.selectedItemPosition]
        config.mmsServerUrl = binding.mmsServerUrlInput.text.toString().trim()
        config.mmsApiKey = binding.mmsApiKeyInput.text.toString().trim()
        config.customSourceLangCode = binding.customLangInput.text.toString().trim()
    }

    private fun refreshModelStatus() {
        val srcLang = langCodes.getOrElse(binding.sourceLangSpinner.selectedItemPosition) { config.sourceLang }
        val srcOk = config.isVoskModelAvailable(srcLang)
        val enOk = config.isVoskModelAvailable("en")
        val rootPath = config.voskModelsRootDir().absolutePath

        val srcMark = if (srcOk) "✓" else "✗ TRŪKST"
        val enMark = if (enOk) "✓" else "✗ TRŪKST"

        binding.modelStatusText.text =
            "Vosk modeļi:\n  $srcLang (avots): $srcMark\n  en (atbildes): $enMark\n\nMape: $rootPath"
    }

    private fun startFlow() {
        saveUiIntoConfig()
        if (!config.isConfigured()) {
            Toast.makeText(
                this,
                "Trūkst Vosk valodu modeļu — skat. README sadaļu 'Vosk modeļu uzstādīšana'",
                Toast.LENGTH_LONG
            ).show()
            refreshModelStatus()
            return
        }

        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions.launch(missing.toTypedArray())
        } else {
            launchService()
        }
    }

    private fun launchService() {
        val intent = Intent(this, TranslationService::class.java)
        ContextCompat.startForegroundService(this, intent)
        serviceRunning = true
        binding.startStopButton.text = "Apturēt klausīšanos"
        binding.statusText.text = "Statuss: klausās (${config.sourceLang} -> ${config.targetLang}), \"${config.wakeWord}\" pārslēdz uz tevi"
    }

    private fun stopService() {
        stopService(Intent(this, TranslationService::class.java))
        serviceRunning = false
        binding.startStopButton.text = "Sākt klausīties"
        binding.statusText.text = "Statuss: apturēts"
    }
}
