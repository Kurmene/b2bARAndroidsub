# Limits — vienkāršais variants

Pēc dienas limita (piem. 4 h) visas aplikācijas "guļ" līdz rītam.
Zvani, SMS, iestatījumi un sākuma ekrāns strādā vienmēr.
Kontus noņemt nevajag, dators nav vajadzīgs, serveris nav vajadzīgs.

## Uzstādīšana
1. Android Studio → atver mapi `Limits` → Build → Build APK.
2. Pārsūti APK uz telefonu un instalē.
3. Atver **Limits** → uzstādi paroli.
4. Spied **"Ieslēgt / pārbaudīt servisu"** → Limits → Ieslēgt.

**Ja Android 13+ neļauj ieslēgt** ("Restricted setting"):
Iestatījumi → Aplikācijas → Limits → ⋮ (augšā labajā stūrī) → **Atļaut ierobežotos iestatījumus**.
Tad mēģini 4. soli vēlreiz.

## Lietošana
- **Iestatījumi 🔒** (ar paroli): limits minūtēs, plkst. kad sākas jauna diena,
  aplikācijas, kuras nekad neguļ (piem. kartes, banka).
- Kad limits beidzies, atveras ekrāns ar paroles lauku: **atbloķēt uz 15 vai 60 min**.

## Ja kaut kas nestrādā vai aizmirsi paroli
Vienkārši atinstalē: Iestatījumi → Aplikācijas → Limits → Atinstalēt.
Iestatījumi vienmēr ir pieejami, tāpēc tas strādā arī tad, kad aplikācijas guļ.
